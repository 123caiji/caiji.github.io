#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "beep.h"
#include "key.h"
#include "lcd.h"
#include "touch.h"  // 触摸屏支持
#include "rtc.h"
#include "dht11.h"
#include "24cxx.h"
#include "timer.h"
#include "warehouse_monitor.h"

// 仓库环境监测与报警系统
// 课程三级项目
// 功能：
// 1. TFTLCD显示温湿度数据、阈值、姓名学号
// 2. 按键处理：增减温湿度阈值
// 3. RTC实时显示时间，按键和串口设置时间
// 4. DHT11实时采集温湿度
// 5. 24C02存储阈值，断电不丢失
// 6. 定时器每秒输出数据，串口协议控制阈值
// 7. 超限报警：温度超限蜂鸣器1s间隔响1s红灯闪烁，湿度超限2s间隔响2s绿灯闪烁

// TIM6中断服务函数已在timer.c中定义，这里不需要重复定义
// 如果需要独立的中断处理，可以取消下面的注释并注释掉timer.c中的定义
/*
void TIM6_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
    {
        warehouse_timer6_process(); // 调用仓库监测定时器处理
        TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
    }
}
*/

int main(void)
{ 	
    u8 rtc_init_result;  // 变量声明必须在函数开始处（C89/C90兼容）
    u8 dht11_init_retry = 0;
    u8 dht11_init_success = 0;
    
    // 系统初始化
    delay_init(72);            // 延时函数初始化，72MHz系统时钟
    uart_init(115200);         // 串口1初始化：115200波特率
    LED_Init();                // LED初始化
    BEEP_Init();               // 蜂鸣器初始化
    KEY_Init();                // 按键初始化
    LCD_Init();                // LCD初始化
    tp_dev.init();             // 触摸屏初始化
    AT24CXX_Init();            // 24C02初始化
    
    // RTC初始化
    rtc_init_result = RTC_Init();
    if(rtc_init_result)
    {
        // RTC初始化失败，设置默认时间
        RTC_Set(2024, 1, 1, 12, 0, 0);
        // 注意：device_status.rtc_status将在warehouse_monitor_init中设置
    }
    
    // DHT11初始化（尝试3次，失败也继续执行，确保能进入页面）
    for(dht11_init_retry = 0; dht11_init_retry < 3; dht11_init_retry++)
    {
        if(DHT11_Init() == 0)
        {
            dht11_init_success = 1;
            break;  // 初始化成功，退出循环
        }
        delay_ms(200);  // 等待200ms后重试
    }
    // 如果初始化失败，显示错误信息但继续执行
    if(dht11_init_success == 0)
    {
        LCD_Clear(BLACK);
        POINT_COLOR = RED;
        BACK_COLOR = BLACK;
        LCD_ShowString(10, 10, lcddev.width, lcddev.height, 16, "DHT11 Init Failed!");
        LCD_ShowString(10, 30, lcddev.width, lcddev.height, 16, "Continue anyway...");
        delay_ms(1000);  // 显示1秒后继续
    }
    
    // 初始化定时器6（10ms中断一次）
    TIM6_Int_Init(9999, 7199); // 10ms = 10000 * (7200/72M) ≈ 10ms
    
    // 清屏并显示启动信息
    LCD_Clear(BLACK);
    POINT_COLOR = WHITE;
    BACK_COLOR = BLACK;
    LCD_ShowString(10, 10, lcddev.width, lcddev.height, 20, "Warehouse Monitor");
    LCD_ShowString(10, 35, lcddev.width, lcddev.height, 16, "Initializing...");
		delay_ms(1000);	 
    
    // 初始化仓库监测系统
    warehouse_monitor_init();
    
    // 主循环
	while(1)
	{			  
        // 执行仓库监测主任务
        warehouse_monitor_task();
        
        // 延时，避免CPU占用过高
		delay_ms(10);
	}
}

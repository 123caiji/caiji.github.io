#include "guix.h"
#include "malloc.h"
#include "stdio.h"
//#include "font.h" 
extern const unsigned char asc2_1206[95][12];
extern const unsigned char asc2_1608[95][16];
extern const unsigned char asc2_2412[95][36];

// GUI字体定义（仓库监测系统stub定义，不使用GUI字体）
u8* asc2_2814 = 0;	//普通字体28*14点阵数据
u8* asc2_3618 = 0;	//普通字体36*18点阵数据
u8* asc2_5427 = 0;	//普通字体54*27点阵数据
u8* asc2_s6030 = 0;	//数字字体60*30点阵数据

// GUI输入对象定义（仓库监测系统stub定义，C89兼容初始化）
_in_obj in_obj;
static void stub_get_key(void* obj, u8 type) { }

// GUI物理接口定义（仓库监测系统stub定义，C89兼容初始化）
_gui_phy gui_phy;

////////////////////////////GUI通用字符串表//////////////////////////////
//确认
u8*const GUI_OK_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"OK",			//English (simplified)
	(u8*)"OK",			//English (traditional)
	(u8*)"OK",			//English
};
//取消
u8*const GUI_CANCEL_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"CANCEL",		//English (simplified)
	(u8*)"CANCEL",		//English (traditional)
	(u8*)"CANCEL",		//English
};
//是
u8*const GUI_YES_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"YES",			//English (simplified)
	(u8*)"YES",			//English (traditional)
	(u8*)"YES",			//English
};
//否
u8*const GUI_NO_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"NO",			//English (simplified)
	(u8*)"NO",			//English (traditional)
	(u8*)"NO",			//English
};
//选项（stub定义）
u8*const GUI_OPTION_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"OPTION",
	(u8*)"OPTION",
	(u8*)"OPTION",
};
//返回（stub定义）
u8*const GUI_BACK_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"BACK",
	(u8*)"BACK",
	(u8*)"BACK",
};
//退出（stub定义）
u8*const GUI_QUIT_CAPTION_TBL[GUI_LANGUAGE_NUM]=
{
	(u8*)"QUIT",
	(u8*)"QUIT",
	(u8*)"QUIT",
};

// GUI初始化函数（最小实现，仓库监测系统可能不需要完整GUI功能）
void gui_init(void)
{
	// 初始化stub变量
	in_obj.get_key = stub_get_key;
	in_obj.x = 0;
	in_obj.y = 0;
	in_obj.keyval = 0;
	in_obj.intype = 0;
	in_obj.ksta = 0;
	
	gui_phy.language = 0;
	gui_phy.memdevflag = 0;
	gui_phy.tbfsize = 0;
	gui_phy.tbheight = 0;
	gui_phy.listfsize = 0;
	gui_phy.listheight = 0;
	gui_phy.back_color = 0;
	gui_phy.read_point = 0;
	gui_phy.draw_point = 0;
	gui_phy.fill = 0;
	gui_phy.colorfill = 0;
	gui_phy.lcdwidth = 0;
	gui_phy.lcdheight = 0;
}

// GUI函数stub实现（仓库监测系统不使用完整GUI功能）
u16 gui_alpha_blend565(u16 src, u16 dst, u8 alpha) { return dst; }
u16 gui_color_chg(u32 rgb) { return (u16)(rgb & 0xFFFF); }
u16 gui_rgb332torgb565(u16 rgb332) { return rgb332; }
long long gui_pow(u8 m, u8 n) { long long res = 1; while(n--) res *= m; return res; }
u8* gui_path_name(u8 *pname, u8* path, u8 *name) { return name; }

void gui_memset(void *p, u8 c, u32 len) { u8* ptr = (u8*)p; while(len--) *ptr++ = c; }
void *gui_memin_malloc(u32 size) { return malloc(size); }
void gui_memin_free(void* ptr) { free(ptr); }
void *gui_memex_malloc(u32 size) { return malloc(size); }
void gui_memex_free(void* ptr) { free(ptr); }
void *gui_memin_realloc(void *ptr, u32 size) { return realloc(ptr, size); }

void gui_get_key(void* obj, u8 type) { }
u32 gui_disabs(u32 x1, u32 x2) { return (x1 > x2) ? (x1 - x2) : (x2 - x1); }
void gui_alphablend_area(u16 x, u16 y, u16 width, u16 height, u16 color, u8 aval) { }
void gui_draw_bigpoint(u16 x0, u16 y0, u16 color) { }
void gui_draw_line(u16 x0, u16 y0, u16 x1, u16 y1, u16 color) { }
void gui_draw_bline(u16 x1, u16 y1, u16 x2, u16 y2, u8 size, u16 color) { }
void gui_draw_bline1(u16 x0, u16 y0, u16 x1, u16 y1, u8 size, u16 color) { }
void gui_draw_rectangle(u16 x0, u16 y0, u16 width, u16 height, u16 color) { }
void gui_draw_arcrectangle(u16 x, u16 y, u16 width, u16 height, u8 r, u8 mode, u16 upcolor, u16 downcolor) { }
void gui_draw_vline(u16 x0, u16 y0, u16 len, u16 color) { }
void gui_draw_hline(u16 x0, u16 y0, u16 len, u16 color) { }
void gui_fill_colorblock(u16 x0, u16 y0, u16 width, u16 height, u16* ctbl, u8 mode) { }
void gui_smooth_color(u32 srgb, u32 ergb, u16*cbuf, u16 len) { }
void gui_draw_smooth_rectangle(u16 x, u16 y, u16 width, u16 height, u32 srgb, u32 ergb) { }
void gui_fill_rectangle(u16 x0, u16 y0, u16 width, u16 height, u16 color) { }
void gui_fill_circle(u16 x0, u16 y0, u16 r, u16 color) { }
void gui_draw_ellipse(u16 x0, u16 y0, u16 rx, u16 ry, u16 color) { }
void gui_fill_ellipse(u16 x0, u16 y0, u16 rx, u16 ry, u16 color) { }
void gui_draw_argrec(u16 x0, u16 y0, u16 width, u16 height, u16 color) { }
void gui_show_strmid(u16 x, u16 y, u16 width, u16 height, u16 color, u8 size, u8 *str) { }
void gui_show_ptchar(u16 x, u16 y, u16 xend, u16 yend, u16 offset, u16 color, u16 size, u8 chr, u8 mode) { }
void gui_show_ptfont(u16 x, u16 y, u16 xend, u16 yend, u16 offset, u16 color, u16 size, u8* chr, u8 mode) { }
void gui_show_ptstr(u16 x, u16 y, u16 xend, u16 yend, u16 offset, u16 color, u8 size, u8 *str, u8 mode) { }
void gui_show_ptstrwhiterim(u16 x, u16 y, u16 xend, u16 yend, u16 offset, u16 color, u16 rimcolor, u8 size, u8 *str) { }
void gui_draw_icos(u16 x, u16 y, u8 size, u8 index) { }
void gui_draw_icosalpha(u16 x, u16 y, u8 size, u8 index) { }
void gui_show_num(u16 x, u16 y, u8 len, u16 color, u8 size, long long num, u8 mode) { }
u8* gui_num2str(u8*str, u32 num) { sprintf((char*)str, "%u", num); return str; }
void gui_draw_arc(u16 sx, u16 sy, u16 ex, u16 ey, u16 rx, u16 ry, u16 r, u16 color, u8 mode) { }

u32 gui_get_stringline(u8*str, u16 linelenth, u8 font) { return 1; }
void gui_show_string(u8*str, u16 x, u16 y, u16 width, u16 height, u8 font, u16 fcolor) { }
u16 gui_string_forwardgbk_count(u8 *str, u16 pos) { return 1; }

﻿#include "dm9000.h"
#include "delay.h"
#include "led.h"
#include "usart.h"
// #include "lwip_comm.h"  // LWIP已删除，DM9000网络功能不使用
#if SYSTEM_SUPPORT_OS
#include "ucos_ii.h"  // OS_EVENT定义
#endif
//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK战舰STM32开发板V3
//DM9000驱动代码	   
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2015/3/15
//版本：V1.0
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2009-2019
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 

struct dm9000_config dm9000cfg;				//DM9000配置结构体

#if SYSTEM_SUPPORT_OS
// DM9000信号量定义（仓库监测系统不使用网络功能，提供stub定义避免链接错误）
OS_EVENT* dm9000input = 0;				//DM9000输入消息邮箱信号量
OS_EVENT* dm9000lock = 0;				//DM9000读写锁信号量
#else
// Stub定义（仓库监测系统不使用DM9000网络功能，避免链接错误）
typedef void* OS_EVENT_STUB;
OS_EVENT_STUB* dm9000input = 0;
OS_EVENT_STUB* dm9000lock = 0;
#endif				//DM9000读写锁信号量信号量

//初始化DM9000
//mode:0,仅读取DM9000的ID,无法读取ID.
//     1,完全初始化,可以正常使用
//返回值:
//0,初始化成功
//1,初始化失败
u8 DM9000_Init(u8 mode)
{
	// 最小实现（仓库监测系统不使用DM9000）
	(void)mode;  // 避免未使用参数警告
	return 0;
}

//读DM9000寄存器
//reg:寄存器地址
//返回值:读到的值
u16 DM9000_ReadReg(u16 reg)
{
	u16 val;
	DM9000->REG = reg;
	val = DM9000->DATA;
	return val;
}

//写DM9000寄存器
//reg:寄存器地址
//data:要写入的值
void DM9000_WriteReg(u16 reg, u16 data)
{
	DM9000->REG = reg;
	DM9000->DATA = data;
}

//读DM9000 PHY寄存器
//reg:PHY寄存器地址
//返回值:读到的值
u16 DM9000_PHY_ReadReg(u16 reg)
{
	u16 val;
	DM9000_WriteReg(DM9000_EPAR, DM9000_PHY | reg);
	DM9000_WriteReg(DM9000_EPCR, 0XC);	//EPCR_ERPRR=1, EPCR_EPOS=1
	delay_us(300);
	DM9000_WriteReg(DM9000_EPCR, 0X0C);	//EPCR_ERPRR=1
	val = (DM9000_ReadReg(DM9000_EPDRH) << 8) | DM9000_ReadReg(DM9000_EPDRL);
	DM9000_WriteReg(DM9000_EPCR, 0X00);
	return val;
}

//写DM9000 PHY寄存器
//reg:PHY寄存器地址
//data:要写入的值
void DM9000_PHY_WriteReg(u16 reg, u16 data)
{
	DM9000_WriteReg(DM9000_EPAR, DM9000_PHY | reg);
	DM9000_WriteReg(DM9000_EPDRL, data);
	DM9000_WriteReg(DM9000_EPDRH, data >> 8);
	DM9000_WriteReg(DM9000_EPCR, 0XA);	//EPCR_ERPRW=1, EPCR_EPOS=1
	delay_us(300);
	DM9000_WriteReg(DM9000_EPCR, 0X00);
}

//获取DM9000设备ID
//返回值:设备ID
u32 DM9000_Get_DeiviceID(void)
{
	u32 id;
	id = DM9000_ReadReg(DM9000_VIDH);
	id <<= 16;
	id |= DM9000_ReadReg(DM9000_VIDL);
	id <<= 16;
	id |= DM9000_ReadReg(DM9000_PIDH);
	id <<= 8;
	id |= DM9000_ReadReg(DM9000_PIDL);
	return id;
}

//获取DM9000速度和双工模式
//返回值:速度和双工模式
u8 DM9000_Get_SpeedAndDuplex(void)
{
	u16 val;
	val = DM9000_PHY_ReadReg(DM9000_PHY_DSCR);
	if(val & (1<<13)) return 1;  // 100M
	else return 0;  // 10M
}

//设置DM9000 PHY模式
//mode:PHY模式
void DM9000_Set_PHYMode(u8 mode)
{
	u16 val;
	dm9000cfg.mode = mode;
	val = DM9000_PHY_ReadReg(DM9000_PHY_BMCR);
	val &= ~0X2100;
	if(mode == DM9000_10MHD) val |= 0X00;
	else if(mode == DM9000_100MHD) val |= 0X2000;
	else if(mode == DM9000_10MFD) val |= 0X100;
	else if(mode == DM9000_100MFD) val |= 0X2100;
	else if(mode == DM9000_AUTO) val |= 0X1000;
	DM9000_PHY_WriteReg(DM9000_PHY_BMCR, val);
}

//设置DM9000 MAC地址
//macaddr:MAC地址(6字节)
void DM9000_Set_MACAddress(u8 *macaddr)
{
	u8 i;
	for(i = 0; i < 6; i++)
	{
		dm9000cfg.mac_addr[i] = macaddr[i];
		DM9000_WriteReg(DM9000_PAR + i, macaddr[i]);
	}
}

//设置DM9000多播地址
//multicastaddr:多播地址(8字节)
void DM9000_Set_Multicast(u8 *multicastaddr)
{
	u8 i;
	for(i = 0; i < 8; i++)
	{
		dm9000cfg.multicase_addr[i] = multicastaddr[i];
		DM9000_WriteReg(DM9000_MAR + i, multicastaddr[i]);
	}
}

//复位DM9000
void DM9000_Reset(void)
{
	DM9000_RST = 0;
	delay_ms(10);
	DM9000_RST = 1;
	delay_ms(10);
}

#if 0  // LWIP已删除，DM9000网络功能不使用
void DM9000_SendPacket(struct pbuf *p)
{
	// 空实现
}

struct pbuf *DM9000_Receive_Packet(void)
{
	// 空实现
	return 0;
}
#endif

//DM9000中断处理函数
void DMA9000_ISRHandler(void)
{
	u16 int_status;
	u16 last_io;
	
	last_io = DM9000->REG;
	int_status = DM9000_ReadReg(DM9000_ISR);
	DM9000_WriteReg(DM9000_ISR, int_status);
	
	if(int_status & ISR_PRS)		//接收中断
	{  
		#if SYSTEM_SUPPORT_OS
		OSSemPost(dm9000input);
		#endif		//发送接收到数据帧 
	} 
	if(int_status&ISR_PTS)			//发送中断
	{ 
		//发送中断处理,这里没有用到
	}
	DM9000->REG=last_io;	
}

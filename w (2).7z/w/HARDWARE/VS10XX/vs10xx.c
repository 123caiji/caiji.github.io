#include "vs10xx.h"	
#include "delay.h"
#include "sdio_sdcard.h"
#include "spi.h"
#include "usart.h"	    
#include "vs10xx_fix.h"  // VS10XX修复定义
#include "24cxx.h"  // AT24CXX_Read, AT24CXX_Write
#if SYSTEM_SUPPORT_OS
#include "os_cpu.h"  // OS_CPU_SR, OS_ENTER_CRITICAL, OS_EXIT_CRITICAL
#endif
//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK战舰STM32开发板V3
//VS10XX 驱动代码	   
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2015/1/20
//版本：V1.0
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2009-2019
//All rights reserved													    								  
//////////////////////////////////////////////////////////////////////////////////

//VS10XX默认配置参数
_vs10xx_obj vsset=
{
	220,	//音量:220
	6,		//低频限制 60Hz
	15,		//低频增强 15dB	
	10,		//高频限制 10Khz	
	15,		//高频增强 10.5dB
	0,		//空间效果	0
	1,		//开机默认音效模式.
};

vu8 nes_spped_para=0;			//NES游戏加速时,需要该值补偿,默认为0.

////////////////////////////////////////////////////////////////////////////////
//移植时需要实现的接口
//data:要写入的数据
//返回值:读取到的数据
u8 VS_SPI_ReadWriteByte(u8 data)
{			  	 
	return SPI1_ReadWriteByte(data);	  
}

//SD卡初始化时，需要降低
void VS_SPI_SpeedLow(void)
{								 
	SPI1_SetSpeed(SPI_BaudRatePrescaler_32 + (nes_spped_para<<3) );	//设置低速模式 
}

//SD卡初始化后，可以高速
void VS_SPI_SpeedHigh(void)
{						  
	SPI1_SetSpeed(SPI_BaudRatePrescaler_8 +(nes_spped_para<<3));	//设置高速模式		 
}

//初始化VS10XX的IO口	 
void VS_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOE|RCC_APB2Periph_GPIOF, ENABLE);	 //使能PC,PE,PF端口时钟
	  
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;				 //PC13
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		 //上拉输入
 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
 	GPIO_Init(GPIOC, &GPIO_InitStructure);

 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;	 //PE6
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
							  
 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;//PF6,PF7
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStructure);	
	SPI1_Init();	 
}	  

//读取VS1053参数
//vs10xxdev:vs1053参数
void vs10xx_read_para(_vs10xx_obj * vs10xxdev)
{
	AT24CXX_Read(VS10XX_SAVE_BASE_ADDR, (u8*)vs10xxdev, sizeof(_vs10xx_obj));
}

//写入VS1053参数
//vs10xxdev:vs1053参数
void vs10xx_save_para(_vs10xx_obj * vs10xxdev)
{
	#if SYSTEM_SUPPORT_OS
    OS_CPU_SR cpu_sr=0;
	OS_ENTER_CRITICAL();	//进入临界区(无法被中断打断) 
	#endif
	AT24CXX_Write(VS10XX_SAVE_BASE_ADDR, (u8*)vs10xxdev, sizeof(_vs10xx_obj));
	#if SYSTEM_SUPPORT_OS
	OS_EXIT_CRITICAL();		//退出临界区(可以被中断打断)
	#endif
}

////////////////////////////////////////////////////////////////////////////////	 	  
//复位VS10XX
void VS_Soft_Reset(void)
{	 
	u8 retry=0;  				   
	VS_WR_Cmd(SPI_MODE,SM_RESET|SM_SDINEW);	//复位VS1053
	while(VS_RD_Reg(SPI_MODE) & SM_RESET)	//等待复位完成
	{
		delay_ms(10);
		retry++;
		if(retry>50)break;					//复位超时
	}
	delay_ms(100);							//延时，等待初始化完成
}

//读取VS10XX寄存器
u16 VS_RD_Reg(u8 address)
{
	u16 data=0;
	VS_XCS=0;								//选中VS10XX
	VS_SPI_ReadWriteByte(VS_READ_COMMAND);	//发送读命令
	VS_SPI_ReadWriteByte(address);			//发送寄存器地址
	data=VS_SPI_ReadWriteByte(0XFF);		//读取高字节
	data=data<<8;
	data|=VS_SPI_ReadWriteByte(0XFF);		//读取低字节
	VS_XCS=1;								//释放VS10XX
	return data;
}

//写入VS10XX寄存器
void VS_WR_Cmd(u8 address,u16 data)
{
	VS_XCS=0;								//选中VS10XX
	VS_SPI_ReadWriteByte(VS_WRITE_COMMAND);	//发送写命令
	VS_SPI_ReadWriteByte(address);			//发送寄存器地址
	VS_SPI_ReadWriteByte(data>>8);			//发送高字节
	VS_SPI_ReadWriteByte(data&0XFF);		//发送低字节
	while(VS_DQ==0);						//等待VS10XX处理完成
	VS_XCS=1;								//释放VS10XX
}

//向VS10XX写入数据
void VS_WR_Data(u8 data)
{
	VS_XDCS=0;								//选中VS10XX的数据接口
	VS_SPI_ReadWriteByte(data);			//发送数据
	VS_XDCS=1;								//释放VS10XX的数据接口
}

//读取VS10XX的RAM
u16 VS_WRAM_Read(u16 addr)
{
	u16 temp;
	VS_WR_Cmd(SPI_WRAMADDR,addr);			//设置RAM地址
	temp=VS_RD_Reg(SPI_WRAM);				//读取RAM数据
	return temp;
}

//写入VS10XX的RAM
void VS_WRAM_Write(u16 addr,u16 val)
{
	VS_WR_Cmd(SPI_WRAMADDR,addr);			//设置RAM地址
	VS_WR_Cmd(SPI_WRAM,val);				//写入RAM数据
}

//硬件复位VS10XX
u8 VS_HD_Reset(void)
{
	u8 retry=0;
	VS_RST=0;								//复位VS10XX
	delay_ms(20);
	VS_RST=1;								//释放复位
	delay_ms(20);
	while(VS_RD_Reg(SPI_MODE) != 0x0800)	//等待VS10XX初始化完成
	{
		delay_ms(10);
		retry++;
		if(retry>50)return 1;				//复位超时
	}
	return 0;
}

//RAM测试
u16 VS_Ram_Test(void)
{
	u16 i;
	u16 temp;
	for(i=0;i<0x2000;i++)
	{
		temp=VS_WRAM_Read(i);				//读取RAM数据
		VS_WRAM_Write(i,0x5AA5);			//写入测试数据
		if(VS_WRAM_Read(i)!=0x5AA5)return i;//测试失败
		VS_WRAM_Write(i,temp);				//恢复原始数据
	}
	return 0xFFFF;							//测试通过
}

//正弦波测试
void VS_Sine_Test(void)
{
	VS_WR_Cmd(SPI_MODE,SM_SDINEW|SM_TESTS|SM_STREAM);
	delay_ms(100);
	VS_WR_Data(0x53);
	VS_WR_Data(0xEF);
	VS_WR_Data(0x6E);
	VS_WR_Data(0x44);
	VS_WR_Data(0x00);
	VS_WR_Data(0x00);
	VS_WR_Data(0x00);
	VS_WR_Data(0x00);
	delay_ms(200);
	VS_WR_Cmd(SPI_MODE,SM_SDINEW|SM_STREAM);
}

//设置音量
void VS_Set_Vol(u8 volx)
{
	u16 temp;
	if(volx>254)volx=254;
	temp=volx;
	temp<<=8;
	temp|=volx;
	VS_WR_Cmd(SPI_VOL,temp);
}

//设置高低音
void VS_Set_Bass(u8 bfreq,u8 bass,u8 tfreq,u8 treble)
{
	u16 temp;
	temp=(bfreq<<12)|(bass<<8)|(tfreq<<4)|treble;
	VS_WR_Cmd(SPI_BASS,temp);
}

//设置音效
void VS_Set_Effect(u8 eft)
{
	VS_WRAM_Write(0x1E06,eft);
}

//设置扬声器
void VS_SPK_Set(u8 sw)
{
	if(sw)VS_WRAM_Write(0x1E07,0x00);		//开启
	else VS_WRAM_Write(0x1E07,0x02);		//关闭
}

//设置所有参数
void VS_Set_All(void)
{
	VS_Set_Vol(vsset.mvol);
	VS_Set_Bass(vsset.bflimit,vsset.bass,vsset.tflimit,vsset.treble);
	VS_Set_Effect(vsset.effect);
	VS_SPK_Set(vsset.speakersw);
}

//设置播放速度
void VS_Set_Speed(u8 t)
{
	VS_WRAM_Write(0x1E05,t);
}

//获取头信息
u16 VS_Get_HeadInfo(void)
{
	return VS_RD_Reg(SPI_HDAT0);
}

//获取字节率
u32 VS_Get_ByteRate(void)
{
	u32 rate;
	rate=VS_RD_Reg(SPI_HDAT1);
	rate=rate<<16;
	rate|=VS_RD_Reg(SPI_HDAT0);
	return rate;
}

//获取结束填充字节
u16 VS_Get_EndFillByte(void)
{
	return VS_RD_Reg(SPI_WRAMADDR);
}

//发送音乐数据
u8 VS_Send_MusicData(u8* buf)
{
	u8 i;
	for(i=0;i<32;i++)
	{
		if(VS_DQ)							//检查VS10XX是否准备好
		{
			VS_WR_Data(buf[i]);				//发送数据
		}
		else
		{
			return i;						//VS10XX未准备好，返回已发送的字节数
		}
	}
	return 32;								//发送完成
}

//重新开始播放
void VS_Restart_Play(void)
{
	VS_WR_Cmd(SPI_MODE,SM_SDINEW|SM_STREAM);
	delay_ms(10);
	VS_WR_Cmd(SPI_MODE,SM_SDINEW|SM_STREAM);
}

//复位解码时间
void VS_Reset_DecodeTime(void)
{
	VS_WR_Cmd(SPI_DECODE_TIME,0);
}

//获取解码时间
u16 VS_Get_DecodeTime(void)
{
	return VS_RD_Reg(SPI_DECODE_TIME);
}

//加载用户patch
void VS_Load_Patch(u16 *patch,u16 len)
{
	u16 i;
	VS_WR_Cmd(SPI_MODE,SM_SDINEW|SM_STREAM);
	for(i=0;i<len;i++)
	{
		VS_WRAM_Write(patch[i*2],patch[i*2+1]);
	}
}

//获取规格
u8 VS_Get_Spec(u16 *p)
{
	p[0]=VS_RD_Reg(SPI_HDAT0);
	p[1]=VS_RD_Reg(SPI_HDAT1);
	return 0;
}

//设置频段
void VS_Set_Bands(u16 *buf,u8 bands)
{
	u8 i;
	for(i=0;i<bands;i++)
	{
		VS_WRAM_Write(0x1E00+i,buf[i]);
	}
}

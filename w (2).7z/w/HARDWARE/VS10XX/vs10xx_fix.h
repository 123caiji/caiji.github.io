#ifndef __VS10XX_FIX_H
#define __VS10XX_FIX_H

// settings.h已删除，提供VS10XX保存地址定义
// 如果仓库监测系统不使用VS10XX功能，建议从工程中移除此文件
#define VS10XX_SAVE_BASE_ADDR  0x50  // VS10XX参数保存基地址（24C02地址0x00-0xFF）

#endif


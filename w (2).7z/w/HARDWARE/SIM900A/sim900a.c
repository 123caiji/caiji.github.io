#include "sim900a.h" 
#include "delay.h"	
#include "led.h"     
#include "w25qxx.h"  
#include "malloc.h"
#include "string.h"    
#include "text.h"		
#include "usart3.h" 
#include "ff.h" 
#if SYSTEM_SUPPORT_OS
#include "ucos_ii.h" 
#endif

//////////////////////////////////////////////////////////////////////////////////	   
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK战舰STM32开发板V3
//SIM900A 初始化 
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2015/3/5
//版本：V1.0
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2014-2024
//All rights reserved
//********************************************************************************
//修改说明
//
////////////////////////////////////////////////////////////////////////////////// 	

__sim900dev sim900dev;	//sim900设备结构

//sim900a检查命令,检查收到的响应.
//str:期待响应字符
//返回值:0,没有收到期待响应字符
//    其他,期待响应字符的位置(str偏移位置)
u8* sim900a_check_cmd(u8 *str)
{
	char *strx=0;
	if(USART3_RX_STA&0X8000)		//收到了一帧数据
	{ 
		USART3_RX_BUF[USART3_RX_STA&0X7FFF]=0;//添加结束符
		strx=strstr((const char*)USART3_RX_BUF,(const char*)str);
	} 
	return (u8*)strx;
}
//向sim900a发送命令
//cmd:要发送的命令字符串(注意要添加回车),当cmd<0XFF时,发送单个字节(比如发送0X1A),用于退出字符串.
//ack:期待响应字符,如果为空,则表示不需要等待响应
//waittime:等待时间(单位:10ms)
//返回值:0,发送成功(得到期待响应字符)
//       1,收到预期结果
//       2,没有收到任何回复
u8 sim900a_send_cmd(u8 *cmd,u8 *ack,u16 waittime)
{
	u8 res=0;  
	USART3_RX_STA=0;
	sim900dev.cmdon=1;//发送指令等待状态
	if((u32)cmd<=0XFF)
	{   
		while((USART3->SR&0X40)==0);//等待上一次数据发送完成  
		USART3->DR=(u32)cmd;
	}else u3_printf("%s\r\n",cmd);//发送命令
	if(ack&&waittime)		//需要等待响应
	{
		while(--waittime)	//等待超时
		{
			delay_ms(10);
			if(USART3_RX_STA&0X8000)//是否收到期待响应字符
			{
				if(sim900a_check_cmd(ack))res=0;//收到期待的回复
				else res=1;//收到非期待的回复
				break; 
			} 
		}
		if(waittime==0)res=2; 
	}
	return res;
}
//命令处理超时后,由sim900a_send_cmd可多使用/取消sim900a_send_cmd产生的.
void sim900a_cmd_over(void)
{
	USART3_RX_STA=0;
	sim900dev.cmdon=0;//退出指令等待状态
}
//将1个字符转换为16进制数
//chr:字符,0~9/A~F/a~F
//返回值:chr对应的16进制数值
u8 sim900a_chr2hex(u8 chr)
{
	if(chr>='0'&&chr<='9')return chr-'0';
	if(chr>='A'&&chr<='F')return (chr-'A'+10);
	if(chr>='a'&&chr<='f')return (chr-'a'+10); 
	return 0;
}
//将1个16进制数转换为字符
//hex:16进制数,0~15;
//返回值:字符
u8 sim900a_hex2chr(u8 hex)
{
	if(hex<=9)return hex+'0';
	if(hex>=10&&hex<=15)return (hex-10+'A'); 
	return '0';
}
//unicode gbk 转换函数
//src:源字符串
//dst:目标(uni2gbk时为gbk字符串,gbk2uni时,为unicode字符串)
//mode:0,unicode到gbk转换;
//     1,gbk到unicode转换;
void sim900a_unigbk_exchange(u8 *src,u8 *dst,u8 mode)
{
#if SYSTEM_SUPPORT_OS
    OS_CPU_SR cpu_sr=0;
#endif
	u16 temp; 
	u8 buf[2];
#if SYSTEM_SUPPORT_OS
	OS_ENTER_CRITICAL();//进入临界区(无法被中断打断)  
#endif
	if(mode)//gbk 2 unicode
	{
		while(*src!=0)
		{
			if(*src<0X81)	//非汉字
			{
				temp=(u16)ff_convert((WCHAR)*src,1);
				src++;
			}else 			//汉字,占2个字节
			{
				buf[1]=*src++;
				buf[0]=*src++;    
				temp=(u16)ff_convert((WCHAR)*(u16*)buf,1); 
			}
			*dst++=sim900a_hex2chr((temp>>12)&0X0F);
			*dst++=sim900a_hex2chr((temp>>8)&0X0F);
			*dst++=sim900a_hex2chr((temp>>4)&0X0F);
			*dst++=sim900a_hex2chr(temp&0X0F);
		}
	}else	//unicode 2 gbk
	{ 
		while(*src!=0)
		{
			buf[1]=sim900a_chr2hex(*src++)*16;
			buf[1]+=sim900a_chr2hex(*src++);
			buf[0]=sim900a_chr2hex(*src++)*16;
			buf[0]+=sim900a_chr2hex(*src++);
 			temp=(u16)ff_convert((WCHAR)*(u16*)buf,0);
			if(temp<0X80){*dst=temp;dst++;}
			else {*(u16*)dst=swap16(temp);dst+=2;}
		} 
	}
	*dst=0;//添加结束符
#if SYSTEM_SUPPORT_OS
	OS_EXIT_CRITICAL();	//退出临界区(可以被中断打断)	
#endif
} 

// Stub函数实现（仓库监测系统不使用电话和短信功能）
void sms_remind_msg(u8 mode)
{
	// 空实现 - 仓库监测系统不使用短信功能
	(void)mode;  // 避免未使用参数警告
}

void phone_incall_task_creat(void)
{
	// 空实现 - 仓库监测系统不使用电话功能
}

//电话来电/收到短信 处理
void sim900a_cmsgin_check(void)
{
	u8 *p1,*p2; 
	u8 num;
	if(sim900dev.cmdon==0&&sim900dev.mode==0)//没指令等待状态,.空闲/接收模式,才检查
	{
		if(USART3_RX_STA&0X8000)//收到新消息
		{
			if(sim900a_check_cmd("+CLIP:"))//有收到来电?
			{
				p1=sim900a_check_cmd("+CLIP:");
				p1+=8;
				p2=(u8*)strstr((const char *)p1,"\"");
				p2[0]=0;//添加结束符 
				strcpy((char*)sim900dev.incallnum,(char*)p1);//保存来电号码
				sim900dev.mode=3;			//来电响应模式
				phone_incall_task_creat();	//创建来电处理任务
			}
			if(sim900a_check_cmd("+CMGS:"))//短信发送成功
			{
				sms_remind_msg(1);//显示发送短信成功
			}
			if(sim900a_check_cmd("+CMTI:"))//收到新短信
			{
				if(sim900dev.newmsg<SIM900_MAX_NEWMSG)
				{
					p1=(u8*)strstr((const char*)(USART3_RX_BUF),",");   
					p2=(u8*)strstr((const char*)(p1+1),"\r\n");
					if((p2-p1)==2)num=p1[1]-'0';//1位
					else if((p2-p1)==3)num=(p1[1]-'0')*10+p1[2]-'0';//2位
					else if((p2-p1)==4)num=(p1[1]-'0')*100+(p1[2]-'0')*10+p1[2]-'0';//3位 
					sim900dev.newmsgindex[sim900dev.newmsg]=num;
					sim900dev.newmsg++;
				}
				sms_remind_msg(0);//显示收到新短信
			}			
			USART3_RX_STA=0;
			printf("rev:%s\r\n",USART3_RX_BUF);	
		}
	}
}
//sim900a状态检查
void sim900a_status_check(void)
{
	u8 *p1; 
	if(sim900dev.cmdon==0&&sim900dev.mode==0&&USART3_RX_STA==0)//没指令等待状态.空闲/接收模式/还没收到任何数据,才进行查询
	{
		if(sim900a_send_cmd("AT+CSQ","OK",25)==0)//查询信号强度,顺便查询GSM模块状态
		{
			p1=(u8*)strstr((const char*)(USART3_RX_BUF),":"); 
			p1+=2;
			sim900dev.csq=(p1[0]-'0')*10+p1[1]-'0';//信号强度
			if(sim900dev.csq>30)sim900dev.csq=30;		
			sim900dev.status|=1<<7;	//查询GSM模块是否在位?
		}else 
		{ 
			sim900dev.csq=0;	
			sim900dev.status=0;	//重新检测
		} 
		if((sim900dev.status&0XC0)==0X80)//CPIN状态,未获取?
		{ 
			sim900a_send_cmd("ATE0","OK",100);//关闭回显(回显关闭,不影响接收数据异常)
			if(sim900a_send_cmd("AT+CPIN?","OK",25)==0)sim900dev.status|=1<<6;//SIM卡在位
			else sim900dev.status&=~(1<<6);//SIM卡不在位 
		} 
		if((sim900dev.status&0XE0)==0XC0)//运营商网络,未获取?
		{ 
			if(sim900a_send_cmd("AT+COPS?","OK",25)==0)//查询运营商网络
			{ 
				p1=(u8*)strstr((const char*)(USART3_RX_BUF),"MOBILE");//查找MOBILE,判断是不是中国移动?
				if(p1)sim900dev.status&=~(1<<4); //中国移动 
				else 
				{
					p1=(u8*)strstr((const char*)(USART3_RX_BUF),"UNICOM");//查找UNICOM,判断是不是中国联通?
					if(p1)sim900dev.status|=1<<4;	//中国联通 
				}
				if(p1)
				{
					sim900dev.status|=1<<5;	//得到运营商网络 
					//phone相关功能配置
					sim900a_send_cmd("AT+CLIP=1","OK",100);	//来电号码显示 
					sim900a_send_cmd("AT+COLP=1","OK",100);	//设置被叫号码显示
					//sms相关功能配置
					sim900a_send_cmd("AT+CMGF=1","OK",100);			//设置文本模式 
					sim900a_send_cmd("AT+CSCS=\"UCS2\"","OK",100);	//设置TE字符集为UCS2 
					sim900a_send_cmd("AT+CSMP=17,0,2,25","OK",100);	//设置短信文本模式参数 
				}
			}else sim900dev.status&=~(1<<5);	//未连接到运营商网络
		} 
		sim900a_cmd_over();//命令处理
	}
}

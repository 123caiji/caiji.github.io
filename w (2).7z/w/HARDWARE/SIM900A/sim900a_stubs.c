// SIM900A Stub函数 - 仓库监测系统不使用电话和短信功能
#include "sys.h"

void phone_incall_task_creat(void)
{
	// 空实现 - 仓库监测系统不使用电话功能
}

void sms_remind_msg(u8 type)
{
	// 空实现 - 仓库监测系统不使用短信功能
}


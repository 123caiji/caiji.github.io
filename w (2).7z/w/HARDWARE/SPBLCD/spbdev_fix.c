#include "spbdev_fix.h"

// spbdev全局变量定义（默认值）
_spb_dev spbdev = {
	.spbwidth = 240,
	.spbheight = 320,
	.frame = 0,
	.stabarheight = 0
};


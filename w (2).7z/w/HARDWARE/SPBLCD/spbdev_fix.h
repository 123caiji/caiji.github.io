#ifndef __SPBDEV_FIX_H
#define __SPBDEV_FIX_H
#include "sys.h"

// spb.h已删除，提供spbdev的简化定义
// 如果仓库监测系统不使用SPBLCD功能，建议从Keil工程中移除此文件
typedef struct {
	u16 spbwidth;
	u16 spbheight;
	u8 frame;
	u16 stabarheight;
} _spb_dev;

extern _spb_dev spbdev;  // 需要在使用SPBLCD的地方定义

#endif


#ifndef __WAREHOUSE_MONITOR_H
#define __WAREHOUSE_MONITOR_H
#include "sys.h"
#include "lcd.h"
#include "key.h"
#include "touch.h"  // 触摸屏支持
#include "rtc.h"
#include "dht11.h"
#include "24cxx.h"
#include "beep.h"
#include "led.h"
#include "usart.h"
#include "timer.h"
#include "delay.h"
#include "string.h"
#include "stdio.h"
#if !defined(__ARMCC_VERSION) && !defined(__ICCARM__)
#include "stdlib.h"  // 如果编译器支持stdlib.h，包含它以使用atoi和sscanf
#endif
#include "text.h"  // 中文字符显示支持
#include "piclib.h"  // 图片显示支持（创新功能：背景图片）

// 阈值存储地址（24C02中）
#define THRESHOLD_EEPROM_ADDR  0x00  // 温度上限地址
#define THRESHOLD_EEPROM_ADDR1 0x01  // 温度下限地址
#define THRESHOLD_EEPROM_ADDR2 0x02  // 湿度上限地址
#define THRESHOLD_EEPROM_ADDR3 0x03  // 湿度下限地址

// 学生信息（需要根据实际情况修改）
#define STUDENT_NAME  "张三"  // 学生姓名
#define STUDENT_ID    "20210001"  // 学号

// 报警状态标志
typedef struct {
    u8 temp_alarm;      // 温度报警：0-正常，1-超出上限，2-超出下限
    u8 humi_alarm;      // 湿度报警：0-正常，1-超出上限，2-超出下限
    u8 beep_temp_cnt;   // 温度报警蜂鸣器计数
    u8 beep_humi_cnt;   // 湿度报警蜂鸣器计数
    u8 led_temp_cnt;    // 温度报警LED计数
    u8 led_humi_cnt;    // 湿度报警LED计数
} alarm_status_t;

// 系统参数结构
typedef struct {
    u8 temp_high;       // 温度上限
    u8 temp_low;        // 温度下限
    u8 humi_high;       // 湿度上限
    u8 humi_low;        // 湿度下限
    u8 current_temp;    // 当前温度
    u8 current_humi;    // 当前湿度
    u8 time_set_mode;   // 时间设置模式：0-正常，1-设置年，2-设置月，3-设置日，4-设置时，5-设置分
    u8 select_item;     // 菜单选择项：0-温度上限，1-温度下限，2-湿度上限，3-湿度下限
} system_param_t;

// 设备状态结构
typedef struct {
    u8 dht11_status;      // DHT11状态：0-正常，1-未连接或读取失败
    u8 eeprom_status;      // 24C02状态：0-正常，1-未连接
    u8 rtc_status;         // RTC状态：0-正常，1-未初始化
    u8 dht11_read_cnt;     // DHT11连续读取失败计数
    u8 eeprom_check_cnt;   // EEPROM检测计数器
} device_status_t;

extern system_param_t sys_param;
extern alarm_status_t alarm_status;
extern device_status_t device_status;

// 函数声明
void warehouse_monitor_init(void);
void warehouse_monitor_task(void);
void warehouse_display_update(void);
void warehouse_key_process(void);
void warehouse_init_bg_image(void);  // 初始化背景图片（创新功能）
void warehouse_read_threshold(void);
void warehouse_save_threshold(void);
void warehouse_read_dht11(void);
void warehouse_alarm_process(void);
void warehouse_uart_send_data(void);
void warehouse_uart_protocol_process(void);
void warehouse_rtc_set_time_process(void);
void warehouse_timer6_process(void);
u8 warehouse_touch_to_key(void);  // 触摸屏转换为按键功能
void warehouse_check_devices(void);  // 检测设备状态

#endif


#include "warehouse_monitor.h"

// 简单的字符串转整数函数（替代atoi）
static u8 str_to_u8(const char *str)
{
    u8 val = 0;
    while(*str >= '0' && *str <= '9')
    {
        val = val * 10 + (*str - '0');
        str++;
    }
    return val;
}

// 全局变量
system_param_t sys_param;
alarm_status_t alarm_status;
device_status_t device_status;

// 定时器计数器已在warehouse_timer6_process中定义为静态变量

// 串口接收缓冲区索引（暂时未使用，保留用于未来扩展）
// static u8 uart_rx_index = 0;

// 初始化仓库监测系统
void warehouse_monitor_init(void)
{
    // 初始化默认阈值
    sys_param.temp_high = 35;
    sys_param.temp_low = 5;
    sys_param.humi_high = 80;
    sys_param.humi_low = 20;
    
    // 从EEPROM读取阈值
    warehouse_read_threshold();
    
    // 初始化报警状态
    alarm_status.temp_alarm = 0;
    alarm_status.humi_alarm = 0;
    alarm_status.beep_temp_cnt = 0;
    alarm_status.beep_humi_cnt = 0;
    alarm_status.led_temp_cnt = 0;
    alarm_status.led_humi_cnt = 0;
    
    // 初始化设备状态
    device_status.dht11_status = 1;  // 初始化为错误状态，等待检测
    device_status.eeprom_status = 1;  // 初始化为错误状态，等待检测
    device_status.rtc_status = 0;      // RTC在main.c中已初始化，默认正常
    device_status.dht11_read_cnt = 0;
    device_status.eeprom_check_cnt = 0;
    
    // 立即检测一次设备状态
    // 检测24C02 EEPROM
    if(AT24CXX_Check() == 0)
    {
        device_status.eeprom_status = 0;
    }
    
    // 尝试检测DHT11（如果main.c中初始化失败，这里再次尝试）
    // 注意：即使检测失败，也继续执行，确保能进入页面
    if(DHT11_Init() == 0)
    {
        device_status.dht11_status = 0;  // DHT11正常
    }
    else
    {
        device_status.dht11_status = 1;  // DHT11异常，但继续执行
    }
    
    // 初始化时间设置模式
    sys_param.time_set_mode = 0;
    
    // 初始化菜单选择项
    sys_param.select_item = 0;
    
    // 初始化背景图片（创新功能）
    warehouse_init_bg_image();
    
    // 初始化LCD显示
    LCD_Clear(BLACK);
    warehouse_display_update();
    
    // 注意：定时器6已在main.c中初始化，这里不需要重复初始化
    // TIM6_Int_Init(9999, 7199); // 10ms中断一次，100次为1秒
}

// 主任务循环
void warehouse_monitor_task(void)
{
    static u16 display_cnt = 0;  // 显示更新计数器
    
    // 处理按键（物理按键和触摸屏，已整合到warehouse_key_process中）
    warehouse_key_process();
    
    // 处理串口协议
    warehouse_uart_protocol_process();
    
    // 检测设备状态（定期检测）
    warehouse_check_devices();
    
    // 处理报警
    warehouse_alarm_process();
    
    // 更新显示（如果需要实时刷新，可以降低频率）
    display_cnt++;
    if(display_cnt >= 50) // 每500ms更新一次显示
    {
        display_cnt = 0;
        warehouse_read_dht11(); // 读取温湿度（同时检测DHT11状态）
        warehouse_display_update(); // 更新显示（包含设备状态）
    }
    
    // 定时器中断中每1秒发送数据
}

// 背景图片显示标志（创新功能）
static u8 bg_image_enabled = 0;  // 0-关闭，1-开启

// 初始化背景图片（创新功能）
void warehouse_init_bg_image(void)
{
    // 初始化图片库
    piclib_init();
    ai_draw_init();
    
    // 启用背景图片（需要在SD卡根目录放置bg.bmp或bg.jpg文件）
    // 注意：需要SD卡和文件系统支持
    // 图片放置位置：SD卡根目录，文件名：bg.bmp 或 bg.jpg
    // 支持格式：BMP、JPG
    // 推荐尺寸：与LCD分辨率匹配（如320x240或480x320等）
    bg_image_enabled = 1;  // 启用背景图片功能
}

// 更新LCD显示
void warehouse_display_update(void)
{
    u16 x = 10, y = 10;
    u8 fsize = 16;
    u16 btn_width = lcddev.width / 4;  // 触摸按键宽度
    
    // 如果启用背景图片，先显示背景（创新功能）
    if(bg_image_enabled)
    {
        // 尝试加载背景图片（BMP格式优先）
        // 如果加载失败，则使用纯色背景
        u8 ret = ai_load_picfile("0:/bg.bmp", 0, 0, lcddev.width, lcddev.height, 0);
        if(ret != 0)
        {
            // BMP加载失败，尝试JPG格式
            ret = ai_load_picfile("0:/bg.jpg", 0, 0, lcddev.width, lcddev.height, 0);
            if(ret != 0)
            {
                // 图片加载失败，使用纯色背景作为替代
                u16 bg_color = GRAYBLUE;
                LCD_Fill(0, 0, lcddev.width, lcddev.height, bg_color);
            }
        }
    }
    else
    {
        LCD_Clear(BLACK);  // 黑色背景
    }
    
    // 显示标题（使用中文字符显示函数）
    POINT_COLOR = WHITE;
    BACK_COLOR = bg_image_enabled ? GRAYBLUE : BLACK;
    Show_Str(x, y, lcddev.width, fsize + 20, (u8*)"Warehouse Monitor System", fsize + 4, 0);
    
    // 显示当前时间（RTC）- 即使RTC未初始化也显示
    y += fsize + 20;
    POINT_COLOR = YELLOW;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Current Time:", fsize, 0);
    // 尝试获取RTC时间，如果失败则显示默认值
    if(device_status.rtc_status == 0)
    {
    RTC_Get();
    sprintf((char*)USART_RX_BUF, "%04d-%02d-%02d %02d:%02d:%02d", 
            calendar.w_year, calendar.w_month, calendar.w_date,
            calendar.hour, calendar.min, calendar.sec);
    }
    else
    {
        sprintf((char*)USART_RX_BUF, "---- -- -- --:--:--");
    }
    LCD_ShowString(x + 80, y, lcddev.width, lcddev.height, fsize, (u8*)USART_RX_BUF);
    
    // 如果处于时间设置模式，显示设置提示和高亮当前设置项
    if(sys_param.time_set_mode != 0)
    {
        y += fsize + 10;
        POINT_COLOR = RED;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Time Setting Mode:", fsize, 0);
        y += fsize + 5;
        
        // 显示时间设置项，高亮当前正在设置的部分
        RTC_Get();
        POINT_COLOR = WHITE;
        sprintf((char*)USART_RX_BUF, "%04d", calendar.w_year);
        if(sys_param.time_set_mode == 1)
        {
            POINT_COLOR = YELLOW;
            LCD_Fill(x, y - 1, x + 40, y + fsize + 4, DARKBLUE);  // 高亮背景
        }
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
        
        POINT_COLOR = WHITE;
        Show_Str(x + 45, y, lcddev.width, fsize + 5, (u8*)"-", fsize, 0);
        
        sprintf((char*)USART_RX_BUF, "%02d", calendar.w_month);
        if(sys_param.time_set_mode == 2)
        {
            POINT_COLOR = YELLOW;
            LCD_Fill(x + 50, y - 1, x + 70, y + fsize + 4, DARKBLUE);  // 高亮背景
        }
        Show_Str(x + 50, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
        
        POINT_COLOR = WHITE;
        Show_Str(x + 75, y, lcddev.width, fsize + 5, (u8*)"-", fsize, 0);
        
        sprintf((char*)USART_RX_BUF, "%02d", calendar.w_date);
        if(sys_param.time_set_mode == 3)
        {
            POINT_COLOR = YELLOW;
            LCD_Fill(x + 80, y - 1, x + 100, y + fsize + 4, DARKBLUE);  // 高亮背景
        }
        Show_Str(x + 80, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
        
        POINT_COLOR = WHITE;
        Show_Str(x + 105, y, lcddev.width, fsize + 5, (u8*)" ", fsize, 0);
        
        sprintf((char*)USART_RX_BUF, "%02d", calendar.hour);
        if(sys_param.time_set_mode == 4)
        {
            POINT_COLOR = YELLOW;
            LCD_Fill(x + 110, y - 1, x + 130, y + fsize + 4, DARKBLUE);  // 高亮背景
        }
        Show_Str(x + 110, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
        
        POINT_COLOR = WHITE;
        Show_Str(x + 135, y, lcddev.width, fsize + 5, (u8*)":", fsize, 0);
        
        sprintf((char*)USART_RX_BUF, "%02d", calendar.min);
        if(sys_param.time_set_mode == 5)
        {
            POINT_COLOR = YELLOW;
            LCD_Fill(x + 140, y - 1, x + 160, y + fsize + 4, DARKBLUE);  // 高亮背景
        }
        Show_Str(x + 140, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
        
        y += fsize + 10;
        POINT_COLOR = CYAN;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"KEY0:+, KEY1:-, KEY2:Next, OK:Confirm", fsize - 2, 0);
    }
    
    // 显示实时温湿度（即使未初始化也显示，显示默认值或错误提示）
    y += fsize + 15;
    POINT_COLOR = CYAN;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Real-Time Data:", fsize, 0);
    y += fsize + 5;
    if(device_status.dht11_status == 0)
    {
    sprintf((char*)USART_RX_BUF, "Temp: %d C", sys_param.current_temp);
    }
    else
    {
        sprintf((char*)USART_RX_BUF, "Temp: -- C");
    }
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    y += fsize + 5;
    if(device_status.dht11_status == 0)
    {
    sprintf((char*)USART_RX_BUF, "Humi: %d %%", sys_param.current_humi);
    }
    else
    {
        sprintf((char*)USART_RX_BUF, "Humi: -- %%");
    }
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    
    // 显示阈值（带光标指示）
    y += fsize + 15;
    POINT_COLOR = GREEN;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Alarm Threshold:", fsize, 0);
    y += fsize + 5;
    
    // 显示温度上限（带光标和背景高亮）
    if(sys_param.select_item == 0)
    {
        // 绘制选中项的背景高亮矩形
        LCD_Fill(x - 2, y - 1, lcddev.width - 2, y + fsize + 5, DARKBLUE);  // 深蓝色背景
        POINT_COLOR = YELLOW;  // 选中项用黄色高亮
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)">>", fsize, 0);  // 光标指示（双箭头更明显）
    }
    else
    {
        POINT_COLOR = GREEN;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"  ", fsize, 0);  // 空白占位（两个空格）
    }
    if(sys_param.select_item == 0)
    {
        POINT_COLOR = YELLOW;  // 选中项数值用黄色
    }
    else
    {
        POINT_COLOR = GREEN;  // 未选中项用绿色
    }
    sprintf((char*)USART_RX_BUF, "Temp High: %d C", sys_param.temp_high);
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    y += fsize + 5;
    
    // 显示温度下限（带光标和背景高亮）
    if(sys_param.select_item == 1)
    {
        // 绘制选中项的背景高亮矩形
        LCD_Fill(x - 2, y - 1, lcddev.width - 2, y + fsize + 5, DARKBLUE);  // 深蓝色背景
        POINT_COLOR = YELLOW;  // 选中项用黄色高亮
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)">>", fsize, 0);  // 光标指示（双箭头更明显）
    }
    else
    {
        POINT_COLOR = GREEN;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"  ", fsize, 0);  // 空白占位（两个空格）
    }
    if(sys_param.select_item == 1)
    {
        POINT_COLOR = YELLOW;  // 选中项数值用黄色
    }
    else
    {
        POINT_COLOR = GREEN;  // 未选中项用绿色
    }
    sprintf((char*)USART_RX_BUF, "Temp Low:  %d C", sys_param.temp_low);
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    y += fsize + 5;
    
    // 显示湿度上限（带光标和背景高亮）
    if(sys_param.select_item == 2)
    {
        // 绘制选中项的背景高亮矩形
        LCD_Fill(x - 2, y - 1, lcddev.width - 2, y + fsize + 5, DARKBLUE);  // 深蓝色背景
        POINT_COLOR = YELLOW;  // 选中项用黄色高亮
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)">>", fsize, 0);  // 光标指示（双箭头更明显）
    }
    else
    {
        POINT_COLOR = GREEN;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"  ", fsize, 0);  // 空白占位（两个空格）
    }
    if(sys_param.select_item == 2)
    {
        POINT_COLOR = YELLOW;  // 选中项数值用黄色
    }
    else
    {
        POINT_COLOR = GREEN;  // 未选中项用绿色
    }
    sprintf((char*)USART_RX_BUF, "Humi High: %d %%", sys_param.humi_high);
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    y += fsize + 5;
    
    // 显示湿度下限（带光标和背景高亮）
    if(sys_param.select_item == 3)
    {
        // 绘制选中项的背景高亮矩形
        LCD_Fill(x - 2, y - 1, lcddev.width - 2, y + fsize + 5, DARKBLUE);  // 深蓝色背景
        POINT_COLOR = YELLOW;  // 选中项用黄色高亮
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)">>", fsize, 0);  // 光标指示（双箭头更明显）
    }
    else
    {
        POINT_COLOR = GREEN;
        Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"  ", fsize, 0);  // 空白占位（两个空格）
    }
    if(sys_param.select_item == 3)
    {
        POINT_COLOR = YELLOW;  // 选中项数值用黄色
    }
    else
    {
        POINT_COLOR = GREEN;  // 未选中项用绿色
    }
    sprintf((char*)USART_RX_BUF, "Humi Low:  %d %%", sys_param.humi_low);
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    
    // 显示设备状态（新增）
    y += fsize + 15;
    POINT_COLOR = MAGENTA;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Device Status:", fsize, 0);
    y += fsize + 5;
    
    // DHT11状态
    sprintf((char*)USART_RX_BUF, "DHT11: %s", device_status.dht11_status == 0 ? "OK" : "ERROR");
    if(device_status.dht11_status == 0)
    {
        POINT_COLOR = GREEN;
    }
    else
    {
        POINT_COLOR = RED;
    }
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    if(device_status.dht11_status == 0)
    {
        sprintf((char*)USART_RX_BUF, " [T:%d H:%d]", sys_param.current_temp, sys_param.current_humi);
        Show_Str(x + 80, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize - 2, 0);
    }
    y += fsize + 5;
    
    // 24C02 EEPROM状态
    sprintf((char*)USART_RX_BUF, "EEPROM: %s", device_status.eeprom_status == 0 ? "OK" : "ERROR");
    if(device_status.eeprom_status == 0)
    {
        POINT_COLOR = GREEN;
    }
    else
    {
        POINT_COLOR = RED;
    }
    Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    if(device_status.eeprom_status == 0)
    {
        sprintf((char*)USART_RX_BUF, " [Saved]");
        Show_Str(x + 100, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize - 2, 0);
    }
    y += fsize + 5;
    
    // RTC状态
    sprintf((char*)USART_RX_BUF, "RTC: %s", device_status.rtc_status == 0 ? "OK" : "ERROR");
    if(device_status.rtc_status == 0)
    {
        POINT_COLOR = GREEN;
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    }
    else
    {
        POINT_COLOR = RED;
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)USART_RX_BUF, fsize, 0);
    }
    y += fsize + 10;
    
    // 显示报警状态
    POINT_COLOR = RED;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)"Alarm Status:", fsize, 0);
    y += fsize + 5;
    if(alarm_status.temp_alarm)
    {
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)"Temp Alert!", fsize, 0);
    }
    else
    {
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)"Temp OK", fsize, 0);
    }
    y += fsize + 5;
    if(alarm_status.humi_alarm)
    {
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)"Humi Alert!", fsize, 0);
    }
    else
    {
        Show_Str(x + 20, y, lcddev.width, fsize + 5, (u8*)"Humi OK", fsize, 0);
    }
    
    // 显示学生信息（左下角，使用中文显示）
    y = lcddev.height - (fsize + 10);
    x = 5;
    POINT_COLOR = WHITE;
    BACK_COLOR = bg_image_enabled ? GRAYBLUE : BLACK;
    Show_Str(x, y, lcddev.width, fsize + 5, (u8*)STUDENT_NAME, fsize - 2, 0);
    x += strlen((char*)STUDENT_NAME) * (fsize - 2) + 10;
    LCD_ShowString(x, y, lcddev.width, lcddev.height, fsize - 2, (u8*)STUDENT_ID);
    
    // 显示触摸屏按键提示（底部）
    y = lcddev.height - 50;
    POINT_COLOR = YELLOW;
    BACK_COLOR = BLUE;
    LCD_Fill(0, y, btn_width, lcddev.height, BLUE);
    Show_Str(btn_width/4, y + 15, btn_width, lcddev.height, (u8*)"Inc", fsize - 4, 0);
    
    LCD_Fill(btn_width, y, btn_width * 2, lcddev.height, BLUE);
    Show_Str(btn_width + btn_width/4, y + 15, btn_width, lcddev.height, (u8*)"Dec", fsize - 4, 0);
    
    LCD_Fill(btn_width * 2, y, btn_width * 3, lcddev.height, BLUE);
    Show_Str(btn_width * 2 + btn_width/4, y + 15, btn_width, lcddev.height, (u8*)"Set", fsize - 4, 0);
    
    LCD_Fill(btn_width * 3, y, btn_width * 4, lcddev.height, BLUE);
    Show_Str(btn_width * 3 + btn_width/4, y + 15, btn_width, lcddev.height, (u8*)"OK", fsize - 4, 0);
    BACK_COLOR = bg_image_enabled ? GRAYBLUE : BLACK;
}

// 按键处理（支持物理按键和触摸屏）
void warehouse_key_process(void)
{
    static u8 last_key = 0;
    u8 key = 0;
    u16 year_temp;
    u8 month_temp, day_temp, hour_temp, min_temp;
    u8 max_day;
    
    // 先检查物理按键
    key = KEY_Scan(0);
    
    // 如果物理按键没有按下，检查触摸屏
    if(key == 0)
    {
        if(tp_dev.scan(0) && (tp_dev.sta & TP_PRES_DOWN))
        {
            key = warehouse_touch_to_key();
        }
    }
    
    // 按键消抖处理
    if(key == last_key && key != 0)
    {
        last_key = 0;  // 清除上次按键，允许下次按下
        return;  // 相同按键连续按下，忽略（消抖）
    }
    last_key = key;
    
    if(key == 0) return;
    
    // KEY0: 增加当前选择的阈值或时间
    if(key == KEY0_PRES)
    {
        if(sys_param.time_set_mode == 0) // 正常模式，调整阈值
        {
            switch(sys_param.select_item)
            {
                case 0: // 温度上限
                    if(sys_param.temp_high < 99) sys_param.temp_high++;
                    break;
                case 1: // 温度下限
                    if(sys_param.temp_low < sys_param.temp_high - 1) sys_param.temp_low++;
                    break;
                case 2: // 湿度上限
                    if(sys_param.humi_high < 99) sys_param.humi_high++;
                    break;
                case 3: // 湿度下限
                    if(sys_param.humi_low < sys_param.humi_high - 1) sys_param.humi_low++;
                    break;
            }
            
            warehouse_save_threshold(); // 保存到EEPROM
            warehouse_display_update();
        }
        else // 时间设置模式
        {
            // 直接读取当前RTC时间并修改
            RTC_Get();
            year_temp = calendar.w_year;
            month_temp = calendar.w_month;
            day_temp = calendar.w_date;
            hour_temp = calendar.hour;
            min_temp = calendar.min;
            
            // 根据当前设置模式增加对应值
            switch(sys_param.time_set_mode)
            {
                case 1: // 设置年
                    if(year_temp < 2099) year_temp++;
                    break;
                case 2: // 设置月
                    if(month_temp < 12) month_temp++;
                    break;
                case 3: // 设置日
                    max_day = 31;
                    if(month_temp == 2)
                    {
                        if((year_temp % 4 == 0 && year_temp % 100 != 0) || (year_temp % 400 == 0))
                            max_day = 29;
                        else
                            max_day = 28;
                    }
                    else if(month_temp == 4 || month_temp == 6 || month_temp == 9 || month_temp == 11)
                    {
                        max_day = 30;
                    }
                    if(day_temp < max_day) day_temp++;
                    break;
                case 4: // 设置时
                    if(hour_temp < 23) hour_temp++;
                    break;
                case 5: // 设置分
                    if(min_temp < 59) min_temp++;
                    break;
            }
            
            // 实时更新RTC
            RTC_Set(year_temp, month_temp, day_temp, hour_temp, min_temp, 0);
            warehouse_display_update();
        }
    }
    // KEY1: 减少当前选择的阈值或时间
    else if(key == KEY1_PRES)
    {
        if(sys_param.time_set_mode == 0) // 正常模式
        {
            switch(sys_param.select_item)
            {
                case 0: // 温度上限
                    if(sys_param.temp_high > sys_param.temp_low + 1) sys_param.temp_high--;
                    break;
                case 1: // 温度下限
                    if(sys_param.temp_low > 0) sys_param.temp_low--;
                    break;
                case 2: // 湿度上限
                    if(sys_param.humi_high > sys_param.humi_low + 1) sys_param.humi_high--;
                    break;
                case 3: // 湿度下限
                    if(sys_param.humi_low > 0) sys_param.humi_low--;
                    break;
            }
            
            warehouse_save_threshold();
            warehouse_display_update();
        }
        else // 时间设置模式
        {
            // 直接读取当前RTC时间并修改
            RTC_Get();
            year_temp = calendar.w_year;
            month_temp = calendar.w_month;
            day_temp = calendar.w_date;
            hour_temp = calendar.hour;
            min_temp = calendar.min;
            
            // 根据当前设置模式减少对应值
            switch(sys_param.time_set_mode)
            {
                case 1: // 设置年
                    if(year_temp > 2000) year_temp--;
                    break;
                case 2: // 设置月
                    if(month_temp > 1) month_temp--;
                    break;
                case 3: // 设置日
                    if(day_temp > 1) day_temp--;
                    break;
                case 4: // 设置时
                    if(hour_temp > 0) hour_temp--;
                    break;
                case 5: // 设置分
                    if(min_temp > 0) min_temp--;
                    break;
            }
            
            // 实时更新RTC
            RTC_Set(year_temp, month_temp, day_temp, hour_temp, min_temp, 0);
            warehouse_display_update();
        }
    }
    // KEY2: 切换菜单选择项或时间设置项
    else if(key == KEY2_PRES)
    {
        if(sys_param.time_set_mode == 0)
        {
            // 在正常模式下，KEY2用于切换菜单选择项
            sys_param.select_item = (sys_param.select_item + 1) % 4; // 循环选择：0->1->2->3->0
            warehouse_display_update();
        }
        else
        {
            // 在时间设置模式下，KEY2用于切换到下一个设置项
            sys_param.time_set_mode++;
            if(sys_param.time_set_mode > 5) sys_param.time_set_mode = 1; // 循环：年->月->日->时->分->年
        warehouse_display_update();
    }
    }
    // KEY_UP: 进入/退出时间设置模式
    else if(key == WKUP_PRES)
    {
        if(sys_param.time_set_mode == 0)
        {
            // 进入时间设置模式（从设置年开始）
            sys_param.time_set_mode = 1;
            RTC_Get(); // 获取当前时间
            // 重置首次进入标志（需要在warehouse_rtc_set_time_process中处理）
            warehouse_display_update();
        }
        else
        {
            // 退出时间设置模式，确认当前设置
            sys_param.time_set_mode = 0;
            warehouse_display_update();
        }
    }
}

// 从EEPROM读取阈值
void warehouse_read_threshold(void)
{
    u8 temp;
    
    temp = AT24CXX_ReadOneByte(THRESHOLD_EEPROM_ADDR);
    if(temp != 0xFF) sys_param.temp_high = temp;
    
    temp = AT24CXX_ReadOneByte(THRESHOLD_EEPROM_ADDR1);
    if(temp != 0xFF) sys_param.temp_low = temp;
    
    temp = AT24CXX_ReadOneByte(THRESHOLD_EEPROM_ADDR2);
    if(temp != 0xFF) sys_param.humi_high = temp;
    
    temp = AT24CXX_ReadOneByte(THRESHOLD_EEPROM_ADDR3);
    if(temp != 0xFF) sys_param.humi_low = temp;
}

// 保存阈值到EEPROM
void warehouse_save_threshold(void)
{
    AT24CXX_WriteOneByte(THRESHOLD_EEPROM_ADDR, sys_param.temp_high);
    AT24CXX_WriteOneByte(THRESHOLD_EEPROM_ADDR1, sys_param.temp_low);
    AT24CXX_WriteOneByte(THRESHOLD_EEPROM_ADDR2, sys_param.humi_high);
    AT24CXX_WriteOneByte(THRESHOLD_EEPROM_ADDR3, sys_param.humi_low);
    delay_ms(10); // EEPROM写入需要时间
}

// 读取DHT11温湿度
void warehouse_read_dht11(void)
{
    u8 temp, humi;
    if(DHT11_Read_Data(&temp, &humi) == 0)
    {
        sys_param.current_temp = temp;
        sys_param.current_humi = humi;
        device_status.dht11_status = 0;  // 读取成功，设备正常
        device_status.dht11_read_cnt = 0;
        
        // 检查是否超出阈值
        if(sys_param.current_temp > sys_param.temp_high)
        {
            alarm_status.temp_alarm = 1; // 超出上限
        }
        else if(sys_param.current_temp < sys_param.temp_low)
        {
            alarm_status.temp_alarm = 2; // 超出下限
        }
        else
        {
            alarm_status.temp_alarm = 0; // 正常
        }
        
        if(sys_param.current_humi > sys_param.humi_high)
        {
            alarm_status.humi_alarm = 1; // 超出上限
        }
        else if(sys_param.current_humi < sys_param.humi_low)
        {
            alarm_status.humi_alarm = 2; // 超出下限
        }
        else
        {
            alarm_status.humi_alarm = 0; // 正常
        }
    }
    else
    {
        // 读取失败
        device_status.dht11_read_cnt++;
        if(device_status.dht11_read_cnt > 10)  // 连续10次失败才标记为错误
        {
            device_status.dht11_status = 1;  // 设备异常
        }
    }
}

// 检测设备状态
void warehouse_check_devices(void)
{
    // DHT11状态检测已在warehouse_read_dht11中处理
    
    // 检测24C02 EEPROM（每5秒检测一次，避免频繁检测）
    device_status.eeprom_check_cnt++;
    if(device_status.eeprom_check_cnt >= 500)  // 500次*10ms = 5秒
    {
        device_status.eeprom_check_cnt = 0;
        if(AT24CXX_Check() == 0)  // 0表示检测成功
        {
            device_status.eeprom_status = 0;
        }
        else
        {
            device_status.eeprom_status = 1;
        }
    }
    
    // RTC状态在初始化时已检测，这里不需要重复检测
}

// 报警处理
void warehouse_alarm_process(void)
{
    // 温度报警处理
    if(alarm_status.temp_alarm != 0)
    {
        alarm_status.beep_temp_cnt++;
        alarm_status.led_temp_cnt++;
        
        // 蜂鸣器：间隔1s，响1s
        if((alarm_status.beep_temp_cnt % 200) < 100) // 100次*10ms = 1s
        {
            BEEP = 1; // 响
        }
        else
        {
            BEEP = 0; // 停
        }
        
        // 红灯闪烁（LED0）
        if((alarm_status.led_temp_cnt % 200) < 100)
        {
            LED0 = 0; // 亮
        }
        else
        {
            LED0 = 1; // 灭
        }
        
        if(alarm_status.beep_temp_cnt >= 200) alarm_status.beep_temp_cnt = 0;
        if(alarm_status.led_temp_cnt >= 200) alarm_status.led_temp_cnt = 0;
    }
    else
    {
        LED0 = 1; // 温度正常，红灯灭
        alarm_status.beep_temp_cnt = 0;
        alarm_status.led_temp_cnt = 0;
    }
    
    // 湿度报警处理
    if(alarm_status.humi_alarm != 0)
    {
        alarm_status.beep_humi_cnt++;
        alarm_status.led_humi_cnt++;
        
        // 蜂鸣器：间隔2s，响2s
        if((alarm_status.beep_humi_cnt % 400) < 200) // 200次*10ms = 2s
        {
            if(alarm_status.temp_alarm == 0) // 如果温度不报警，才控制蜂鸣器
            {
                BEEP = 1; // 响
            }
        }
        else
        {
            if(alarm_status.temp_alarm == 0) // 如果温度不报警，才控制蜂鸣器
            {
                BEEP = 0; // 停
            }
        }
        
        // 绿灯闪烁（LED1）
        if((alarm_status.led_humi_cnt % 400) < 200)
        {
            LED1 = 0; // 亮
        }
        else
        {
            LED1 = 1; // 灭
        }
        
        if(alarm_status.beep_humi_cnt >= 400) alarm_status.beep_humi_cnt = 0;
        if(alarm_status.led_humi_cnt >= 400) alarm_status.led_humi_cnt = 0;
    }
    else
    {
        LED1 = 1; // 湿度正常，绿灯灭
        alarm_status.beep_humi_cnt = 0;
        alarm_status.led_humi_cnt = 0;
    }
}

// 串口发送数据（每秒调用一次）
void warehouse_uart_send_data(void)
{
    RTC_Get();
    
    // 格式化输出，便于串口调试助手实时接收和显示
    printf("\r\n[%04d-%02d-%02d %02d:%02d:%02d] Warehouse Monitor Data\r\n", 
           calendar.w_year, calendar.w_month, calendar.w_date,
           calendar.hour, calendar.min, calendar.sec);
    
    // 实时温湿度数据
    if(device_status.dht11_status == 0)
    {
        printf("Temperature: %d C  |  Humidity: %d %%\r\n", 
               sys_param.current_temp, sys_param.current_humi);
    }
    else
    {
        printf("Temperature: -- C  |  Humidity: -- %%  [DHT11 ERROR]\r\n");
    }
    
    // 报警阈值
    printf("Temp Threshold: %d ~ %d C\r\n", sys_param.temp_low, sys_param.temp_high);
    printf("Humi Threshold: %d ~ %d %%\r\n", sys_param.humi_low, sys_param.humi_high);
    
    // 报警状态
    if(alarm_status.temp_alarm != 0)
    {
        if(alarm_status.temp_alarm == 1)
            printf("*** TEMP ALARM: Over High Limit! ***\r\n");
        else
            printf("*** TEMP ALARM: Over Low Limit! ***\r\n");
    }
    if(alarm_status.humi_alarm != 0)
    {
        if(alarm_status.humi_alarm == 1)
            printf("*** HUMI ALARM: Over High Limit! ***\r\n");
        else
            printf("*** HUMI ALARM: Over Low Limit! ***\r\n");
    }
    
    // 设备状态
    printf("Device Status: DHT11=%s, EEPROM=%s, RTC=%s\r\n",
           device_status.dht11_status == 0 ? "OK" : "ERROR",
           device_status.eeprom_status == 0 ? "OK" : "ERROR",
           device_status.rtc_status == 0 ? "OK" : "ERROR");
    
    printf("----------------------------------------\r\n");
}

// 串口协议处理
// 协议格式: 
// SET_TEMP_H:xx  - 设置温度上限
// SET_TEMP_L:xx  - 设置温度下限
// SET_HUMI_H:xx  - 设置湿度上限
// SET_HUMI_L:xx  - 设置湿度下限
// SET_TIME:YYYY-MM-DD HH:MM:SS - 设置时间
// QUERY - 查询当前状态（实时返回数据）
// HELP - 显示帮助信息
void warehouse_uart_protocol_process(void)
{
    if(USART_RX_STA & 0x8000) // 接收到数据
    {
        USART_RX_BUF[USART_RX_STA & 0x7FFF] = 0; // 添加结束符
        
        // 解析命令
        if(strncmp((char*)USART_RX_BUF, "SET_TEMP_H:", 11) == 0)
        {
            u8 val = str_to_u8((char*)&USART_RX_BUF[11]);
            if(val <= 99)
            {
                sys_param.temp_high = val;
                warehouse_save_threshold();
                printf("Set Temp High: %d\r\n", val);
            }
        }
        else if(strncmp((char*)USART_RX_BUF, "SET_TEMP_L:", 11) == 0)
        {
            u8 val = str_to_u8((char*)&USART_RX_BUF[11]);
            if(val <= 99)
            {
                sys_param.temp_low = val;
                warehouse_save_threshold();
                printf("Set Temp Low: %d\r\n", val);
            }
        }
        else if(strncmp((char*)USART_RX_BUF, "SET_HUMI_H:", 11) == 0)
        {
            u8 val = str_to_u8((char*)&USART_RX_BUF[11]);
            if(val <= 99)
            {
                sys_param.humi_high = val;
                warehouse_save_threshold();
                printf("Set Humi High: %d\r\n", val);
            }
        }
        else if(strncmp((char*)USART_RX_BUF, "SET_HUMI_L:", 11) == 0)
        {
            u8 val = str_to_u8((char*)&USART_RX_BUF[11]);
            if(val <= 99)
            {
                sys_param.humi_low = val;
                warehouse_save_threshold();
                printf("Set Humi Low: %d\r\n", val);
            }
        }
        else if(strncmp((char*)USART_RX_BUF, "SET_TIME:", 9) == 0)
        {
            // 简化时间解析：格式 "SET_TIME:YYYYMMDDHHMMSS" 或 "SET_TIME:YYYY-MM-DD HH:MM:SS"
            u8 *p = (u8*)&USART_RX_BUF[9];
            u16 year, month, day, hour, min, sec;
            int year_int, month_int, day_int, hour_int, min_int, sec_int;
            
            // 尝试解析带分隔符的格式
            #ifdef __ARMCC_VERSION
            // Keil编译器支持sscanf，使用临时int变量
            if(sscanf((char*)p, "%04d-%02d-%02d %02d:%02d:%02d", 
                     &year_int, &month_int, &day_int, &hour_int, &min_int, &sec_int) == 6)
            {
                year = (u16)year_int;
                month = (u16)month_int;
                day = (u16)day_int;
                hour = (u16)hour_int;
                min = (u16)min_int;
                sec = (u16)sec_int;
            }
            else if(sscanf((char*)p, "%04d%02d%02d%02d%02d%02d", 
                     &year_int, &month_int, &day_int, &hour_int, &min_int, &sec_int) == 6)
            {
                year = (u16)year_int;
                month = (u16)month_int;
                day = (u16)day_int;
                hour = (u16)hour_int;
                min = (u16)min_int;
                sec = (u16)sec_int;
            }
            else
            {
                year = month = day = hour = min = sec = 0;
            }
            #else
            // 如果不支持sscanf，使用简单的解析（需要手动实现）
            // 这里简化处理：假设输入格式正确
            year = month = day = hour = min = sec = 0;
            if(strlen((char*)p) >= 19) // 至少19个字符 "YYYY-MM-DD HH:MM:SS"
            {
                // 简单的手动解析时间字符串 "YYYY-MM-DD HH:MM:SS"
                year = (p[0]-'0')*1000 + (p[1]-'0')*100 + (p[2]-'0')*10 + (p[3]-'0');
                month = (p[5]-'0')*10 + (p[6]-'0');
                day = (p[8]-'0')*10 + (p[9]-'0');
                hour = (p[11]-'0')*10 + (p[12]-'0');
                min = (p[14]-'0')*10 + (p[15]-'0');
                sec = (p[17]-'0')*10 + (p[18]-'0');
                if(year > 2000 && year < 2100 && month > 0 && month <= 12 && 
                   day > 0 && day <= 31 && hour < 24 && min < 60 && sec < 60)
                {
            #endif
                    if(RTC_Set(year, month, day, hour, min, sec) == 0)
                    {
                        printf("Set Time OK\r\n");
                    }
                    else
                    {
                        printf("Set Time Failed\r\n");
                    }
            #ifndef __ARMCC_VERSION
                }
            #endif
            // 如果没有sscanf，使用简单的数字解析
            // 注意：这里简化处理，实际项目中建议实现完整的时间字符串解析
        }
        else if(strncmp((char*)USART_RX_BUF, "QUERY", 5) == 0)
        {
            // 查询命令：立即返回当前状态
            warehouse_uart_send_data();
            printf("Query OK\r\n");
        }
        else if(strncmp((char*)USART_RX_BUF, "HELP", 4) == 0)
        {
            // 帮助命令：显示所有可用命令
            printf("\r\n=== Warehouse Monitor Commands ===\r\n");
            printf("SET_TEMP_H:xx    - Set temperature high limit (0-99)\r\n");
            printf("SET_TEMP_L:xx    - Set temperature low limit (0-99)\r\n");
            printf("SET_HUMI_H:xx    - Set humidity high limit (0-99)\r\n");
            printf("SET_HUMI_L:xx    - Set humidity low limit (0-99)\r\n");
            printf("SET_TIME:YYYY-MM-DD HH:MM:SS - Set RTC time\r\n");
            printf("QUERY            - Query current status\r\n");
            printf("HELP             - Show this help message\r\n");
            printf("=====================================\r\n");
        }
        else
        {
            // 未知命令
            printf("Unknown command. Send 'HELP' for help.\r\n");
        }
        
        USART_RX_STA = 0; // 清除接收标志
    }
}

// RTC时间设置处理（按键方式）
void warehouse_rtc_set_time_process(void)
{
    static u16 year_temp = 0, month_temp = 0, day_temp = 0, hour_temp = 0, min_temp = 0;
    static u8 first_enter = 1;  // 首次进入标志
    
    // 首次进入时间设置模式时，保存当前时间
    if(first_enter)
    {
    RTC_Get();
        year_temp = calendar.w_year;
        month_temp = calendar.w_month;
        day_temp = calendar.w_date;
        hour_temp = calendar.hour;
        min_temp = calendar.min;
        first_enter = 0;
    }
    
    // 根据当前设置模式调整对应的时间值
    switch(sys_param.time_set_mode)
    {
        case 1: // 设置年
            if(year_temp < 2000) year_temp = 2000;
            if(year_temp > 2099) year_temp = 2099;
            break;
        case 2: // 设置月
            if(month_temp < 1) month_temp = 1;
            if(month_temp > 12) month_temp = 12;
            break;
        case 3: // 设置日
            if(day_temp < 1) day_temp = 1;
            // 根据月份和年份计算最大天数
            {
                u8 max_day = 31;
                if(month_temp == 2)
                {
                    // 判断是否为闰年
                    if((year_temp % 4 == 0 && year_temp % 100 != 0) || (year_temp % 400 == 0))
                        max_day = 29;
                    else
                        max_day = 28;
                }
                else if(month_temp == 4 || month_temp == 6 || month_temp == 9 || month_temp == 11)
                {
                    max_day = 30;
                }
                if(day_temp > max_day) day_temp = max_day;
            }
            break;
        case 4: // 设置时
            if(hour_temp > 23) hour_temp = 23;
            break;
        case 5: // 设置分
            if(min_temp > 59) min_temp = 59;
            break;
    }
    
    // 将临时值写入RTC（实时更新显示）
    RTC_Set(year_temp, month_temp, day_temp, hour_temp, min_temp, 0);
    RTC_Get();  // 更新calendar结构体
    
    // 更新显示
    warehouse_display_update();
}

// 定时器6中断处理计数器（在main.c的TIM6_IRQHandler中调用）
void warehouse_timer6_process(void)
{
    static u16 timer_counter = 0;
    timer_counter++;
    if(timer_counter >= 100) // 1秒（100 * 10ms）
    {
        timer_counter = 0;
        warehouse_uart_send_data(); // 每秒发送数据
    }
}

// 触摸屏转换为按键功能
// 返回值：0-无按键，KEY0_PRES-KEY0，KEY1_PRES-KEY1，KEY2_PRES-KEY2，WKUP_PRES-KEY_UP
u8 warehouse_touch_to_key(void)
{
    u16 tx, ty;
    u16 btn_width = lcddev.width / 4;  // 触摸按键宽度
    u16 btn_height = 50;  // 触摸按键高度
    u16 btn_y = lcddev.height - btn_height;  // 触摸按键Y坐标
    
    if((tp_dev.sta & TP_PRES_DOWN) == 0) return 0;  // 没有触摸
    
    tx = tp_dev.x[0];
    ty = tp_dev.y[0];
    
    // 根据LCD尺寸定义触摸区域（需要根据实际LCD尺寸调整）
    // 假设在LCD底部创建4个触摸按键区域
    
    // KEY0区域（左起第1个按键）：增加
    if(tx < btn_width && ty > btn_y)
    {
        return KEY0_PRES;
    }
    // KEY1区域（左起第2个按键）：减少
    else if(tx < btn_width * 2 && ty > btn_y)
    {
        return KEY1_PRES;
    }
    // KEY2区域（左起第3个按键）：时间设置
    else if(tx < btn_width * 3 && ty > btn_y)
    {
        return KEY2_PRES;
    }
    // KEY_UP区域（左起第4个按键）：确认/退出
    else if(tx < btn_width * 4 && ty > btn_y)
    {
        return WKUP_PRES;
    }
    
    return 0;
}


#ifndef __AUDIODEV_FIX_H
#define __AUDIODEV_FIX_H
#include "sys.h"
#include "ff.h"

// audioplay.h已删除，提供audiodev的简化定义
// 如果仓库监测系统不使用音频播放功能，建议从Keil工程中移除此文件
typedef struct {
	FIL* file;
	u32 (*file_seek)(u32 pos);
	u32 totsec;
	u32 cursec;
	u32 bitrate;
	u32 samplerate;
	u8 bps;
	u8 status;
} _audio_dev;

extern _audio_dev audiodev;

#define AP_ERR  0x80
#define AP_OK   0x00
#define AP_NEXT 0x01

void audio_start(void);
void audio_stop(void);

#endif


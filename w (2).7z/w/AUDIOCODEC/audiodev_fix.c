#include "audiodev_fix.h"

// audiodev全局变量定义
_audio_dev audiodev;

// 音频控制函数（空实现，如果不需要音频功能）
void audio_start(void)
{
	// 空实现
}

void audio_stop(void)
{
	// 空实现
}


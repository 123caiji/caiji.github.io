// system_stub.c - 系统相关的全局变量定义
#include "sys.h"

// system_task_return定义（仓库监测系统不使用，但需要定义以避免链接错误）
volatile u8 system_task_return = 0;


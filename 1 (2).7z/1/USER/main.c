#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"
#include "dht11.h"
#include "rtc.h"            // Device header
#include "beep.h"           // 蜂鸣器头文件
#include "stdio.h"
#include "string.h"
// 网络模块头文件
#include "../HARDWARE/onenet/inc/onenet.h"
#include "../HARDWARE/device/inc/esp8266.h"
 
/************************************************
 学生信息显示和传感器数据采集系统
 功能：
 1. 姓名学号显示
 2. RTC实时时钟显示
 3. DHT11温湿度实时显示
 4. MQ2和MQ135传感器数据显示（从onenet.c获取）
 5. 车辆状态显示
 6. 阈值设置和报警功能
 7. 网络连接状态显示（ESP8266和OneNET）
************************************************/
 	
// 外部变量声明（从onenet.c中获取传感器数据）
extern u8 temp;        // 温度
extern u8 humi;        // 湿度
extern u8 mq2;         // MQ2传感器
extern u8 mq135;       // MQ135传感器
extern u8 car_state;   // 车辆状态
extern u8 bufang;      // 开关状态
extern u8 temph;       // 温度阈值
extern u8 humih;       // 湿度阈值
extern u8 mq2h;        // MQ2阈值
extern u8 mq135h;      // MQ135阈值

// 全局变量
u8 dht11_temp = 0;      // DHT11温度
u8 dht11_humi = 0;      // DHT11湿度
u32 print_counter = 0;  // 串口打印计数器
u32 display_counter = 0; // 显示更新计数器
u32 network_check_counter = 0; // 网络状态检查计数器
u32 dht11_read_counter = 0;   // DHT11读取计数器
u32 alarm_cnt = 0;      // 报警计数器

// 网络连接相关定义
#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

// 网络连接状态变量（OneNET相关，已注释）
// _Bool esp8266_connected = 0;    // ESP8266连接状态
// _Bool onenet_connected = 0;      // OneNET平台连接状态
_Bool esp8266_connected = 0;    // ESP8266连接状态（保留用于兼容）
_Bool onenet_connected = 0;      // OneNET平台连接状态（保留用于兼容）

// 网络数据发送计数器
u32 network_send_counter = 0;   // 网络数据发送计数器（每5秒发送一次）

// 显示模式：0-正常显示，1-阈值设置
u8 display_mode = 0;
u8 set_type = 0;  // 设置类型：0-温度阈值，1-湿度阈值，2-MQ2阈值，3-MQ135阈值

// 串口命令处理变量
u8 uart_cmd_buffer[50];  // 串口命令缓冲区
u8 uart_cmd_received = 0; // 命令接收标志
u8 uart_cmd_index = 0;   // 命令索引

// 星期名称数组
const u8* week_names[] = {(u8*)"Sun", (u8*)"Mon", (u8*)"Tue", (u8*)"Wed", (u8*)"Thu", (u8*)"Fri", (u8*)"Sat"};

// 显示学生信息
void DisplayStudentInfo(void)
{
    // 显示姓名：龙天彪 (使用font.h中的中文字符)
    LCD_ShowString(10, 10, 200, 16, 16, (u8*)"Name:");
    LCD_ShowChinese(60, 10, 15, 16);  // 龙
    LCD_ShowChinese(80, 10, 16, 16);  // 天  
    LCD_ShowChinese(100, 10, 17, 16); // 彪
    
    // 显示学号：23001040517
    LCD_ShowString(10, 30, 200, 16, 16, (u8*)"Student:");
    LCD_ShowString(80, 30, 200, 16, 16, (u8*)"23001040517");
}

// 显示RTC时间
void DisplayRTCTime(void)
{
    u8 time_str[50];
    u8 date_str[50];
    
    // 显示日期
    sprintf((char*)date_str, "Date: %04d-%02d-%02d", 
            calendar.w_year, calendar.w_month, calendar.w_date);
    LCD_ShowString(10, 50, 200, 16, 16, date_str);
    
    // 显示时间
    sprintf((char*)time_str, "Time: %02d:%02d:%02d", 
            calendar.hour, calendar.min, calendar.sec);
    LCD_ShowString(10, 70, 200, 16, 16, time_str);
    
    // 显示星期
    sprintf((char*)time_str, "Week: %s", week_names[calendar.week]);
    LCD_ShowString(10, 90, 200, 16, 16, time_str);
}

// 实时显示传感器数据（新版onenet风格）
void DisplaySensorData(void)
{
    u8 str[50];
    
    // 显示温度
    LCD_ShowString(10, 120, 200, 16, 16, (u8*)"Temp:");
    sprintf((char*)str, "%d", temp);
    LCD_ShowString(60, 120, 200, 16, 16, str);
    LCD_ShowString(90, 120, 200, 16, 16, (u8*)"C");
    
    // 如果超过阈值，显示红色
    if(temp > temph)
    {
        POINT_COLOR = RED;
        LCD_ShowString(60, 120, 200, 16, 16, str);
        POINT_COLOR = BLACK;
    }
    
    // 显示湿度
    LCD_ShowString(10, 140, 200, 16, 16, (u8*)"Humi:");
    sprintf((char*)str, "%d", humi);
    LCD_ShowString(60, 140, 200, 16, 16, str);
    LCD_ShowString(90, 140, 200, 16, 16, (u8*)"%%");
    
    // 如果超过阈值，显示红色
    if(humi > humih)
    {
        POINT_COLOR = RED;
        LCD_ShowString(60, 140, 200, 16, 16, str);
        POINT_COLOR = BLACK;
    }
    
    // 显示MQ2传感器
    LCD_ShowString(10, 160, 200, 16, 16, (u8*)"MQ2:");
    sprintf((char*)str, "%d", mq2);
    LCD_ShowString(60, 160, 200, 16, 16, str);
    LCD_ShowString(90, 160, 200, 16, 16, (u8*)"%%");
    
    // 如果超过阈值，显示红色
    if(mq2 > mq2h)
    {
        POINT_COLOR = RED;
        LCD_ShowString(60, 160, 200, 16, 16, str);
        POINT_COLOR = BLACK;
    }
    
    // 显示MQ135传感器
    LCD_ShowString(10, 180, 200, 16, 16, (u8*)"MQ135:");
    sprintf((char*)str, "%d", mq135);
    LCD_ShowString(70, 180, 200, 16, 16, str);
    LCD_ShowString(100, 180, 200, 16, 16, (u8*)"%%");
    
    // 如果超过阈值，显示红色
    if(mq135 > mq135h)
    {
        POINT_COLOR = RED;
        LCD_ShowString(70, 180, 200, 16, 16, str);
        POINT_COLOR = BLACK;
    }
    
    // 显示车辆状态
    LCD_ShowString(10, 200, 200, 16, 16, (u8*)"Car:");
    if(car_state)
    {
        POINT_COLOR = RED;
        LCD_ShowString(50, 200, 200, 16, 16, (u8*)"Detected");
        POINT_COLOR = BLACK;
    }
    else
    {
        LCD_ShowString(50, 200, 200, 16, 16, (u8*)"Normal");
    }
}

// 显示阈值设置界面
void DisplayThresholdSetting(void)
{
    u8 str[50];
    
    // 清空设置区域
    LCD_Fill(10, 120, 240, 220, WHITE);
    
    // 显示标题
    LCD_ShowString(10, 120, 200, 16, 16, (u8*)"Threshold Setting");
    
    // 显示温度阈值
    LCD_ShowString(10, 140, 200, 16, 16, (u8*)"Temp:");
    sprintf((char*)str, "%d", temph);
    LCD_ShowString(60, 140, 200, 16, 16, str);
    LCD_ShowString(90, 140, 200, 16, 16, (u8*)"C");
    if(set_type == 0) LCD_ShowString(120, 140, 200, 16, 16, (u8*)"<");
    
    // 显示湿度阈值
    LCD_ShowString(10, 160, 200, 16, 16, (u8*)"Humi:");
    sprintf((char*)str, "%d", humih);
    LCD_ShowString(60, 160, 200, 16, 16, str);
    LCD_ShowString(90, 160, 200, 16, 16, (u8*)"%%");
    if(set_type == 1) LCD_ShowString(120, 160, 200, 16, 16, (u8*)"<");
    
    // 显示MQ2阈值
    LCD_ShowString(10, 180, 200, 16, 16, (u8*)"MQ2:");
    sprintf((char*)str, "%d", mq2h);
    LCD_ShowString(60, 180, 200, 16, 16, str);
    LCD_ShowString(90, 180, 200, 16, 16, (u8*)"%%");
    if(set_type == 2) LCD_ShowString(120, 180, 200, 16, 16, (u8*)"<");
    
    // 显示MQ135阈值
    LCD_ShowString(10, 200, 200, 16, 16, (u8*)"MQ135:");
    sprintf((char*)str, "%d", mq135h);
    LCD_ShowString(70, 200, 200, 16, 16, str);
    LCD_ShowString(100, 200, 200, 16, 16, (u8*)"%%");
    if(set_type == 3) LCD_ShowString(120, 200, 200, 16, 16, (u8*)"<");
}

// 检查网络连接状态
void CheckNetworkStatus(void)
{
    static u32 check_counter = 0;
    
    // 每5秒检查一次，避免频繁检查
    check_counter++;
    if(check_counter < 50)  // 100ms * 50 = 5秒
    {
        return;
    }
    check_counter = 0;
    
    // 检查ESP8266连接状态
    // 通过发送AT命令检查ESP8266是否响应
    if(ESP8266_SendCmd("AT\r\n", "OK") == 0)
    {
        // ESP8266响应正常，进一步检查WiFi连接状态
        // STATUS:2 表示已连接到WiFi但未建立TCP连接
        // STATUS:3 表示已连接到WiFi且已建立TCP连接
        // STATUS:4 表示TCP连接已断开但WiFi仍连接
        if(ESP8266_SendCmd("AT+CIPSTATUS\r\n", "STATUS:2") == 0 || 
           ESP8266_SendCmd("AT+CIPSTATUS\r\n", "STATUS:3") == 0 ||
           ESP8266_SendCmd("AT+CIPSTATUS\r\n", "STATUS:4") == 0)
        {
            esp8266_connected = 1;  // WiFi已连接
        }
        else
        {
            esp8266_connected = 0;  // WiFi未连接
        }
    }
    else
    {
        esp8266_connected = 0;  // ESP8266无响应
    }
    
    // 检查OneNET平台连接状态
    // 如果ESP8266已连接且TCP连接已建立，标记OneNET可能已连接
    if(esp8266_connected)
    {
        // 检查TCP连接状态（STATUS:3表示TCP已连接）
        if(ESP8266_SendCmd("AT+CIPSTATUS\r\n", "STATUS:3") == 0)
        {
            onenet_connected = 1;  // OneNET TCP连接已建立
        }
        else
        {
            onenet_connected = 0;  // OneNET TCP连接未建立
        }
    }
    else
    {
        onenet_connected = 0;  // ESP8266未连接，OneNET肯定未连接
    }
}

// 显示网络连接状态
void DisplayNetworkStatus(void)
{
    // 清除显示区域，避免重叠
    LCD_Fill(10, 220, 240, 260, WHITE);
    
    // 显示ESP8266连接状态
    LCD_ShowString(10, 220, 200, 16, 16, (u8*)"WiFi:");
    if(esp8266_connected)
    {
        POINT_COLOR = GREEN;
        LCD_ShowString(50, 220, 200, 16, 16, (u8*)"Connected");
    }
    else
    {
        POINT_COLOR = RED;
        LCD_ShowString(50, 220, 200, 16, 16, (u8*)"Disconnected");
    }
    
    // 显示OneNET平台连接状态
    LCD_ShowString(10, 240, 200, 16, 16, (u8*)"OneNET:");
    if(onenet_connected)
    {
        POINT_COLOR = GREEN;
        LCD_ShowString(70, 240, 200, 16, 16, (u8*)"Online");
    }
    else
    {
        POINT_COLOR = RED;
        LCD_ShowString(70, 240, 200, 16, 16, (u8*)"Offline");
    }
    
    // 恢复默认颜色
    POINT_COLOR = BLACK;
}

// 串口打印传感器数据
void PrintDataToUART(void)
{
    printf("=====================================\r\n");
    printf("Date: %04d-%02d-%02d %02d:%02d:%02d\r\n", 
           calendar.w_year, calendar.w_month, calendar.w_date,
           calendar.hour, calendar.min, calendar.sec);
    printf("Temperature: %d C (Threshold: %d C)\r\n", temp, temph);
    printf("Humidity: %d%% (Threshold: %d%%)\r\n", humi, humih);
    printf("MQ2: %d%% (Threshold: %d%%)\r\n", mq2, mq2h);
    printf("MQ135: %d%% (Threshold: %d%%)\r\n", mq135, mq135h);
    printf("Car State: %s\r\n", car_state ? "Detected" : "Normal");
    printf("Alarm Status: %s\r\n", 
           ((bufang == 1 && car_state == 1) || temp > temph || humi > humih || mq135 > mq135h || mq2 > mq2h) ? "ALARMING" : "Normal");
    printf("=====================================\r\n\r\n");
}

// 读取DHT11数据并更新到onenet变量
u8 ReadDHT11Data(void)
{
    u8 result = DHT11_Read_Data(&dht11_temp, &dht11_humi);
    if(result == 0)
    {
        // 读取成功，更新到onenet变量
        temp = dht11_temp;
        humi = dht11_humi;
        return 0; // 成功
    }
    else
    {
        // 读取失败，使用默认值
        dht11_temp = 25;
        dht11_humi = 60;
        return 1; // 失败
    }
}

// 报警检查和处理
void CheckAlarm(void)
{
    if((bufang == 1 && car_state == 1) || temp > temph || humi > humih || mq135 > mq135h || mq2 > mq2h)
    {
        // 报警条件满足
        if(alarm_cnt++ >= 20)
        {
            BEEP = !BEEP;
            LED0 = !LED0;
            alarm_cnt = 0;
        }
    }
    else
    {
        // 报警条件不满足，关闭报警
                    LED0 = 1;
        BEEP = 0;
        alarm_cnt = 0;
    }
}

// 串口命令接收函数（轮询方式）
void ReceiveUartCommand(void)
{
    u8 res;
    if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
    {
        res = USART_ReceiveData(USART1);
        
        if(res == 'T')  // 命令开始
        {
            uart_cmd_index = 0;
            uart_cmd_received = 0;
            uart_cmd_buffer[uart_cmd_index++] = res;
        }
        else if(res == '!')  // 命令结束
        {
            uart_cmd_buffer[uart_cmd_index] = '\0';
            uart_cmd_received = 1;
        }
        else if(uart_cmd_index > 0 && uart_cmd_index < 49)  // 命令内容
        {
            uart_cmd_buffer[uart_cmd_index++] = res;
        }
    }
}

// 处理串口时间设置命令
void ProcessTimeCommand(void)
{
    if(uart_cmd_received)
    {
        uart_cmd_received = 0;
        
        // 解析命令格式: TYYYYMMDDHHMMSS!
        if(uart_cmd_index >= 15)  // 至少15个字符
        {
            u16 year = (uart_cmd_buffer[1] - '0') * 1000 + 
                      (uart_cmd_buffer[2] - '0') * 100 + 
                      (uart_cmd_buffer[3] - '0') * 10 + 
                      (uart_cmd_buffer[4] - '0');
            
            u8 month = (uart_cmd_buffer[5] - '0') * 10 + (uart_cmd_buffer[6] - '0');
            u8 date = (uart_cmd_buffer[7] - '0') * 10 + (uart_cmd_buffer[8] - '0');
            u8 hour = (uart_cmd_buffer[9] - '0') * 10 + (uart_cmd_buffer[10] - '0');
            u8 min = (uart_cmd_buffer[11] - '0') * 10 + (uart_cmd_buffer[12] - '0');
            u8 sec = (uart_cmd_buffer[13] - '0') * 10 + (uart_cmd_buffer[14] - '0');
            
            // 设置RTC时间
            RTC_Set(year, month, date, hour, min, sec);
            
            printf("Time updated via UART: %04d-%02d-%02d %02d:%02d:%02d\r\n", 
                   year, month, date, hour, min, sec);
        }
        else
        {
            printf("Invalid time format! Use: TYYYYMMDDHHMMSS!\r\n");
        }
        
        uart_cmd_index = 0;
    }
}

// 按键处理
void ProcessKey(void)
{
    u8 key_val = KEY_Scan(0);
    if(key_val != 0)
    {
        switch(key_val)
        {
            case 1:  // KEY1 - 切换显示模式
                display_mode = !display_mode;
                if(display_mode == 0)
                {
                    // 退出设置模式，重新显示传感器数据
                    LCD_Fill(10, 120, 240, 220, WHITE);
                    DisplaySensorData();
                }
                else
                {
                    // 进入设置模式
                    DisplayThresholdSetting();
                }
                break;
                
            case 2:  // KEY2 - 切换设置项
                if(display_mode == 1)
                {
                    set_type++;
                    if(set_type > 3) set_type = 0;
                    DisplayThresholdSetting();
                }
                    break;
                
            case 3:  // KEY3 - 增加阈值
                if(display_mode == 1)
                {
                    if(set_type == 0 && temph < 99) temph++;
                    else if(set_type == 1 && humih < 99) humih++;
                    else if(set_type == 2 && mq2h < 99) mq2h++;
                    else if(set_type == 3 && mq135h < 99) mq135h++;
                    DisplayThresholdSetting();
                }
                    break;
                
            case 4:  // KEY4 - 减少阈值
                if(display_mode == 1)
                {
                    if(set_type == 0 && temph > 0) temph--;
                    else if(set_type == 1 && humih > 0) humih--;
                    else if(set_type == 2 && mq2h > 0) mq2h--;
                    else if(set_type == 3 && mq135h > 0) mq135h--;
                    DisplayThresholdSetting();
                }
                    break;
                
            default:
                    break;
            }
    }
}

int main(void)
{	 
    unsigned char *dataPtr = NULL;
    
    delay_init();	    	 // 延时函数初始化	  
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	 // 设置NVIC中断分组2:2位抢占优先级，2位响应优先级
    uart_init(115200);	 	// 串口1初始化为115200（调试用）
    Usart2_Init(115200);   // 串口2初始化为115200（ESP8266通信用）
    
    KEY_Init();			     // 按键初始化
    LCD_Init();             // LCD初始化
    DHT11_Init();           // DHT11初始化
    RTC_Init();             // RTC初始化
    BEEP_Init();            // 蜂鸣器初始化
    
    POINT_COLOR = BLACK;
    BACK_COLOR = WHITE;
    
    // 清屏并显示标题
    LCD_Clear(WHITE);
    
    // 设置当前时间（年，月，日，时，分，秒）
    // 注意：只有第一次运行时才会设置时间，之后会保持运行
    RTC_Set(2025, 11, 3, 8, 0, 0);
    
    // 发送欢迎信息
    printf("System started at: %04d-%02d-%02d %02d:%02d:%02d\r\n", 
           calendar.w_year, calendar.w_month, calendar.w_date,
           calendar.hour, calendar.min, calendar.sec);
    printf("UART Time Control: TYYYYMMDDHHMMSS!\r\n");
    printf("Example: T20251103080000! (2025-11-03 08:00:00)\r\n");
    printf("=====================================\r\n");
    printf("Alarm Thresholds:\r\n");
    printf("  Temperature: %d C\r\n", temph);
    printf("  Humidity: %d%%\r\n", humih);
    printf("  MQ2: %d%%\r\n", mq2h);
    printf("  MQ135: %d%%\r\n", mq135h);
    printf("Alarm will trigger when:\r\n");
    printf("  - Temperature > %d C\r\n", temph);
    printf("  - Humidity > %d%%\r\n", humih);
    printf("  - MQ2 > %d%%\r\n", mq2h);
    printf("  - MQ135 > %d%%\r\n", mq135h);
    printf("  - Car detected AND switch ON\r\n");
    printf("=====================================\r\n\r\n");
    
    // 网络连接初始化（完全参考新版onenet流程）
    #if 1
    // 显示"Networking"
    LCD_ShowString(10, 220, 200, 16, 16, (u8*)"Networking");
    
    // 初始化ESP8266（连接WiFi）
    ESP8266_Init();
    
    // 清除显示区域，显示连接状态
    LCD_Fill(10, 220, 240, 260, WHITE);
    LCD_ShowString(10, 220, 200, 16, 16, (u8*)"Connected to");
    LCD_ShowString(10, 240, 200, 16, 16, (u8*)"ONENET");
    
    printf("Connect MQTTs Server...\r\n");
    // 连接TCP服务器（参考新版onenet，简单循环重试）
    while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
        delay_ms(500);
    printf("NET_OK\r\n");
    
    // 连接OneNET平台（MQTT连接，参考新版onenet）
    while(OneNet_DevLink())
        delay_ms(500);
    
    // 订阅OneNET主题
    OneNET_Subscribe();
    printf("OneNET subscribe OK\r\n");
    
    // 标记连接成功
    onenet_connected = 1;
    esp8266_connected = 1;
    
    // 延迟一下，让用户看到连接信息
    delay_ms(1000);
    
    // 清除连接状态显示区域（准备显示主界面）
    LCD_Fill(10, 220, 240, 260, WHITE);
    #endif
    
    // 初始显示（确保在主界面显示）
    DisplayStudentInfo();
    DisplayRTCTime();
    DisplaySensorData();
    // 立即显示网络连接状态（确保能看到连接状态）
    CheckNetworkStatus();  // 更新网络状态
    DisplayNetworkStatus(); // 显示网络状态
    
    while(1) 
    {		 
        // 每100ms更新一次显示
        display_counter++;
        if(display_counter >= 10)  // 100ms * 10 = 1秒
        {
            DisplayRTCTime();
            if(display_mode == 0)
            {
                DisplaySensorData();
            }
            else
            {
                DisplayThresholdSetting();
            }
            display_counter = 0;
        }
        
        // 每5秒检查一次网络状态
        network_check_counter++;
        if(network_check_counter >= 50)  // 100ms * 50 = 5秒
        {
            CheckNetworkStatus();
            DisplayNetworkStatus();
            network_check_counter = 0;
        }
        
        // 每1秒读取一次DHT11数据
        dht11_read_counter++;
        if(dht11_read_counter >= 10)  // 100ms * 10 = 1秒
        {
            ReadDHT11Data();
            dht11_read_counter = 0;
        }
        
        // 每1秒通过串口打印一次数据（实时打印）
        print_counter++;
        if(print_counter >= 10)  // 100ms * 10 = 1秒
        {
            PrintDataToUART();
            print_counter = 0;
        }
        
        // 每5秒发送一次数据到OneNET平台（参考新版onenet）
        network_send_counter++;
        if(network_send_counter >= 50)  // 100ms * 50 = 5秒
        {
            if(onenet_connected)
            {
                OneNet_SendData();  // 发送传感器数据到OneNET平台
                ESP8266_Clear();    // 清除ESP8266缓冲区
            }
            network_send_counter = 0;
        }
        
        // 接收OneNET平台下发的数据（参考新版onenet）
        dataPtr = ESP8266_GetIPD(0);  // 非阻塞方式获取数据
        if(dataPtr != NULL)
        {
            OneNet_RevPro(dataPtr);   // 处理OneNET平台下发的命令
        }
        
        // 接收串口命令
        ReceiveUartCommand();
        
        // 处理串口时间设置命令
        ProcessTimeCommand();
        
        // 按键处理
        ProcessKey();
        
        // 报警检查
        CheckAlarm();
        
        delay_ms(100);  // 100ms延时
    } 
}

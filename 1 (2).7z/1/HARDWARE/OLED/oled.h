#ifndef __OLED_H
#define __OLED_H

#include "sys.h"

// OLED显示相关函数声明（如果不需要OLED功能，可以留空）
// 这个头文件是为了解决编译错误而创建的占位文件

// 如果实际需要OLED功能，可以在这里添加函数声明
// void OLED_Init(void);
// void OLED_ShowString(u8 x, u8 y, u8 *str, u8 size);

#endif


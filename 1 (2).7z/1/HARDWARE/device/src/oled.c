// OLED空实现文件（占位文件，不使用OLED显示）
#include "oled.h"

// 空的OLED函数实现
void OLED_ShowCHinese(u8 x, u8 y, u8 num)
{
    // 空实现，不使用OLED显示
    (void)x; 
    (void)y; 
    (void)num;
}


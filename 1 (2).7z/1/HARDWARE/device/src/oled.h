#ifndef __OLED_H
#define __OLED_H

#include "sys.h"

// OLED显示相关函数声明（占位文件，暂时不使用OLED，只使用TFT LCD）
// 这些函数声明是为了避免编译错误，实际函数为空实现

// 空的函数声明（占位）
void OLED_ShowCHinese(u8 x, u8 y, u8 num);

// 如果将来需要OLED功能，可以在这里添加其他函数声明
// void OLED_Init(void);
// void OLED_ShowString(u8 x, u8 y, u8 *str, u8 size);
// void OLED_Clear(void);

#endif




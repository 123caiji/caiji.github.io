#ifndef __ACTUATOR_H
#define __ACTUATOR_H

void Actuator_Init(void);
void FS_ON_Func(void);
void FS_OFF_Func(void);
void KT_ON_Func(void);
void KT_OFF_Func(void);

#endif


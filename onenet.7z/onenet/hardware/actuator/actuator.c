#include "stm32f10x.h"
#include "pin_config.h"

/**
  * 函    数：执行器初始化（风扇FS和空调KT）
  * 参    数：无
  * 返 回 值：无
  */
void Actuator_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	/*GPIO初始化*/
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	// 风扇FS引脚 PB13
	GPIO_InitStructure.GPIO_Pin = FS_PIN;
	GPIO_Init(FS_PORT, &GPIO_InitStructure);
	GPIO_ResetBits(FS_PORT, FS_PIN);		//默认关闭
	
	// 空调KT引脚 PB14
	GPIO_InitStructure.GPIO_Pin = KT_PIN;
	GPIO_Init(KT_PORT, &GPIO_InitStructure);
	GPIO_ResetBits(KT_PORT, KT_PIN);		//默认关闭
}

/**
  * 函    数：风扇开启
  */
void FS_ON_Func(void)
{
	GPIO_SetBits(FS_PORT, FS_PIN);
}

/**
  * 函    数：风扇关闭
  */
void FS_OFF_Func(void)
{
	GPIO_ResetBits(FS_PORT, FS_PIN);
}

/**
  * 函    数：空调开启
  */
void KT_ON_Func(void)
{
	GPIO_SetBits(KT_PORT, KT_PIN);
}

/**
  * 函    数：空调关闭
  */
void KT_OFF_Func(void)
{
	GPIO_ResetBits(KT_PORT, KT_PIN);
}


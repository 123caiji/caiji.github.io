#ifndef __AS608_USART_H
#define __AS608_USART_H

#include "stm32f10x.h"

// 外部变量声明
extern uint8_t aRxBuffer[200];
extern uint8_t RX_len;

// 函数声明
void AS608_USART_Init(void);

#endif

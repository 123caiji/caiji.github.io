#ifndef __KEY_H
#define __KEY_H

// 按键定义
#define KEY_BACK    1    // 返回键 (PA0)
#define KEY_OK      2    // 确定键 (PB1)
#define KEY_UP      3    // 上翻键 (PA4)
#define KEY_DOWN    4    // 下翻键 (PB11)

// 函数声明
void Key_Init(void);
uint8_t Key_GetNum(void);

#endif

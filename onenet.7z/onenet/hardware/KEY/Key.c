#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "pin_config.h"

/**
  * 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = KEY1_PIN | KEY2_PIN;		// PA4, PA5
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PA4、PA5引脚初始化为上拉输入
	
	GPIO_InitStructure.GPIO_Pin = KEY3_PIN | KEY4_PIN;		// PB0, PB11
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB0、PB11引脚初始化为上拉输入
}

// 按键状态机变量
static uint8_t Key1_LastState = 1;  // 按键1上一次状态（1=释放，0=按下）
static uint8_t Key2_LastState = 1;  // 按键2上一次状态
static uint8_t Key3_LastState = 1;  // 按键3上一次状态
static uint8_t Key4_LastState = 1;  // 按键4上一次状态
static uint8_t Key1_DebounceCnt = 0;  // 按键1防抖计数器
static uint8_t Key2_DebounceCnt = 0;  // 按键2防抖计数器
static uint8_t Key3_DebounceCnt = 0;  // 按键3防抖计数器
static uint8_t Key4_DebounceCnt = 0;  // 按键4防抖计数器

/**
  * 函    数：按键获取键码（改进版，使用状态机防抖）
  * 参    数：无
  * 返 回 值：按下按键的键码值，范围：0~4，返回0代表没有按键按下
  * 按键定义：1-切换界面(PA4), 2-确认/切换(PB1), 3-增加(PA4), 4-减少(PB11)
  * 注意事项：此函数使用状态机，每个按键按下后必须释放才能再次触发，避免重复触发
  */
uint8_t Key_GetNum(void)
{
	uint8_t KeyNum = 0;		//定义变量，默认键码值为0
	uint8_t Key1_CurState, Key2_CurState, Key3_CurState, Key4_CurState;
	
	// 读取当前按键状态（0=按下，1=释放，因为是上拉输入）
	Key1_CurState = GPIO_ReadInputDataBit(KEY1_PORT, KEY1_PIN);
	Key2_CurState = GPIO_ReadInputDataBit(KEY2_PORT, KEY2_PIN);
	Key3_CurState = GPIO_ReadInputDataBit(KEY3_PORT, KEY3_PIN);
	Key4_CurState = GPIO_ReadInputDataBit(KEY4_PORT, KEY4_PIN);
	
	// 按键1检测 - 检测下降沿（从释放到按下）
	if(Key1_CurState == 0)  // 当前按下
	{
		if(Key1_LastState == 1)  // 上一次是释放状态（检测下降沿）
		{
			Key1_DebounceCnt++;  // 防抖计数器递增
			if(Key1_DebounceCnt >= 5)  // 连续5次检测到按下（约5ms防抖，降低要求）
			{
				KeyNum = 1;  // 确认按键按下
				Key1_DebounceCnt = 0;
				Key1_LastState = 0;  // 更新状态为按下
			}
		}
		else  // 上一次已经是按下状态，保持按下状态，计数器清零
		{
			Key1_DebounceCnt = 0;
		}
	}
	else  // 当前释放
	{
		if(Key1_LastState == 0)  // 上一次是按下状态（检测上升沿）
		{
			Key1_DebounceCnt++;
			if(Key1_DebounceCnt >= 5)  // 连续5次检测到释放（约5ms）
			{
				Key1_DebounceCnt = 0;
				Key1_LastState = 1;  // 更新状态为释放，可以再次触发
			}
		}
		else  // 上一次已经是释放状态，保持释放状态
		{
			Key1_DebounceCnt = 0;
		}
	}
	
	// 按键2检测
	if(Key2_CurState == 0)
	{
		if(Key2_LastState == 1)
		{
			Key2_DebounceCnt++;
			if(Key2_DebounceCnt >= 5)
			{
				KeyNum = 2;
				Key2_DebounceCnt = 0;
				Key2_LastState = 0;
			}
		}
		else
		{
			Key2_DebounceCnt = 0;
		}
	}
	else
	{
		if(Key2_LastState == 0)
		{
			Key2_DebounceCnt++;
			if(Key2_DebounceCnt >= 5)
			{
				Key2_DebounceCnt = 0;
				Key2_LastState = 1;
			}
		}
		else
		{
			Key2_DebounceCnt = 0;
		}
	}
	
	// 按键3检测
	if(Key3_CurState == 0)
	{
		if(Key3_LastState == 1)
		{
			Key3_DebounceCnt++;
			if(Key3_DebounceCnt >= 5)
			{
				KeyNum = 3;
				Key3_DebounceCnt = 0;
				Key3_LastState = 0;
			}
		}
		else
		{
			Key3_DebounceCnt = 0;
		}
	}
	else
	{
		if(Key3_LastState == 0)
		{
			Key3_DebounceCnt++;
			if(Key3_DebounceCnt >= 5)
			{
				Key3_DebounceCnt = 0;
				Key3_LastState = 1;
			}
		}
		else
		{
			Key3_DebounceCnt = 0;
		}
	}
	
	// 按键4检测
	if(Key4_CurState == 0)
	{
		if(Key4_LastState == 1)
		{
			Key4_DebounceCnt++;
			if(Key4_DebounceCnt >= 5)
			{
				KeyNum = 4;
				Key4_DebounceCnt = 0;
				Key4_LastState = 0;
			}
		}
		else
		{
			Key4_DebounceCnt = 0;
		}
	}
	else
	{
		if(Key4_LastState == 0)
		{
			Key4_DebounceCnt++;
			if(Key4_DebounceCnt >= 5)
			{
				Key4_DebounceCnt = 0;
				Key4_LastState = 1;
			}
		}
		else
		{
			Key4_DebounceCnt = 0;
		}
	}
	
	return KeyNum;			//返回键码值，如果没有按键按下，所有if都不成立，则键码为默认值0
}

/**
  * 函    数：按键诊断函数 - 用于调试检查按键状态
  * 参    数：无
  * 返 回 值：无
  * 说明：通过串口打印所有按键的当前状态和状态机信息
  */
void Key_Debug(void)
{
	uint8_t Key1_State, Key2_State, Key3_State, Key4_State;
	
	// 读取按键原始状态
	Key1_State = GPIO_ReadInputDataBit(KEY1_PORT, KEY1_PIN);
	Key2_State = GPIO_ReadInputDataBit(KEY2_PORT, KEY2_PIN);
	Key3_State = GPIO_ReadInputDataBit(KEY3_PORT, KEY3_PIN);
	Key4_State = GPIO_ReadInputDataBit(KEY4_PORT, KEY4_PIN);
	
	// 打印到串口（需要通过外部函数，这里只是示例结构）
	// 实际使用时需要通过extern声明UsartPrintf函数
}

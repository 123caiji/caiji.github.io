#include "stm32f10x.h"
#include "delay.h"
#include <string.h>
#include "pin_config.h"

// 全局变量声明
unsigned char Data[5];

uint16_t dhti;

char DHT11_GetData(void)
{
	char i, j;
	GPIO_InitTypeDef GPIO_InitStructure;
	
	memset(Data, 0, 5);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = DHT11_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_PORT, &GPIO_InitStructure);
	
	GPIO_ResetBits(DHT11_PORT, DHT11_PIN);
	delay_ms(20);
	GPIO_SetBits(DHT11_PORT, DHT11_PIN);
	delay_us(25);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(DHT11_PORT, &GPIO_InitStructure);
	
	dhti = 0;
	while(GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) == 0)
	{
		dhti++;
		if(dhti > 10000)
		{
			break;
		}
	}
	
	dhti = 0;
	while(GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) == 1)
	{
		dhti++;
		if(dhti > 10000)
		{
			break;
		}
	}
	
	for(j = 0; j < 5; j++)
	{
		for(i = 0; i < 8; i++)
		{
			dhti = 0;
			while(GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) == 0)
			{
				dhti++;
				if(dhti > 10000)
				{
					break;
				}
			}
			delay_us(30);
			Data[j] <<= 1;
			Data[j] |= (unsigned char)GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN);
			dhti = 0;
			while(GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) == 1)
			{
				dhti++;
				if(dhti > 10000)
				{
					break;
				}
			}
		}
	}
	
	if(Data[4] == (char)(Data[0] + Data[1] + Data[2] + Data[3]))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

#ifndef __PIN_CONFIG_H
#define __PIN_CONFIG_H

#include "sys.h"

// ============= 引脚分配表 =============
// OLED显示模块
#define OLED_DC_PIN      GPIO_Pin_8
#define OLED_DC_PORT     GPIOB
#define OLED_RST_PIN     GPIO_Pin_7
#define OLED_RST_PORT    GPIOA
#define OLED_DC2_PIN     GPIO_Pin_6
#define OLED_DC2_PORT    GPIOA
#define OLED_DIN_PIN     GPIO_Pin_9    // PB9
#define OLED_DIN_PORT    GPIOB
#define OLED_CLK_PIN     GPIO_Pin_10   // PB10
#define OLED_CLK_PORT    GPIOB

// 按键模块
#define KEY1_PIN         GPIO_Pin_4    // PA4 - 返回键
#define KEY1_PORT        GPIOA
#define KEY2_PIN         GPIO_Pin_5   // PA5 - 确定键
#define KEY2_PORT        GPIOA
#define KEY3_PIN         GPIO_Pin_0   // PB0 - 上翻键
#define KEY3_PORT        GPIOB
#define KEY4_PIN         GPIO_Pin_11  // PB11 - 下翻键
#define KEY4_PORT        GPIOB

// DHT11温湿度传感器
#define DHT11_PIN        GPIO_Pin_0    // PA0
#define DHT11_PORT       GPIOA

// ESP8266 WiFi模块
#define ESP8266_RST_PIN  GPIO_Pin_8    // PA8
#define ESP8266_RST_PORT GPIOA

// LED指示灯
#define LED1_PIN         GPIO_Pin_1    // LED1 (红色LED) - PA1
#define LED1_PORT        GPIOA
#define LED2_PIN         GPIO_Pin_12   // LED2 (状态LED) - PB12
#define LED2_PORT        GPIOB

// 蜂鸣器
#define BUZZER_PIN       GPIO_Pin_15   // PB15
#define BUZZER_PORT      GPIOB

// 继电器/执行器
#define FS_PIN           GPIO_Pin_13   // 风扇 (FS) - PB13
#define FS_PORT          GPIOB
#define KT_PIN           GPIO_Pin_14   // 空调 (KT) - PB14
#define KT_PORT          GPIOB

// ADC模拟输入
#define ADC_PIN          GPIO_Pin_1    // PB1 - ADC_IN9
#define ADC_PORT         GPIOB

// USART串口（固定功能，不可修改）
// USART1: PA9(TX), PA10(RX)
// USART2: PA2(TX), PA3(RX) - 用于ESP8266通信

// ============= GPIO引脚操作宏定义 =============
// OLED操作宏（在oled.h中定义，这里不重复定义）

// LED操作宏（注意：LED.c中使用函数实现，这里不定义宏避免冲突）

// 执行器操作宏
#define FS_ON()          GPIO_SetBits(FS_PORT, FS_PIN)
#define FS_OFF()         GPIO_ResetBits(FS_PORT, FS_PIN)
#define KT_ON()          GPIO_SetBits(KT_PORT, KT_PIN)
#define KT_OFF()         GPIO_ResetBits(KT_PORT, KT_PIN)

// 蜂鸣器操作宏
#define BEEP_ON()        GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN)
#define BEEP_OFF()       GPIO_SetBits(BUZZER_PORT, BUZZER_PIN)

// 兼容性宏定义（用于main.c和onenet.c）
extern u8 FS_state;
extern u8 KT_state;
extern u8 RED_state;
extern u8 BEEP_state;
extern u8 LED0_state;

#define FS              FS_state
#define KT              KT_state
#define RED             RED_state
#define BEEP            BEEP_state
#define LED0            LED0_state

// 更新GPIO物理引脚状态
void Update_GPIO_States(void);

#endif


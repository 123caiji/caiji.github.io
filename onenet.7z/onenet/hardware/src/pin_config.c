#include "pin_config.h"

// GPIO状态变量定义
u8 FS_state = 0;
u8 KT_state = 0;
u8 RED_state = 1;  // 默认高电平（LED熄灭）
u8 BEEP_state = 0;
u8 LED0_state = 0;

// 更新GPIO物理引脚状态
void Update_GPIO_States(void)
{
	// 根据状态变量更新物理引脚
	if(FS_state)
		GPIO_SetBits(FS_PORT, FS_PIN);
	else
		GPIO_ResetBits(FS_PORT, FS_PIN);
		
	if(KT_state)
		GPIO_SetBits(KT_PORT, KT_PIN);
	else
		GPIO_ResetBits(KT_PORT, KT_PIN);
		
	if(RED_state)
		GPIO_SetBits(LED1_PORT, LED1_PIN);  // LED熄灭（高电平）
	else
		GPIO_ResetBits(LED1_PORT, LED1_PIN); // LED点亮（低电平）
		
	if(BEEP_state)
		GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN); // 蜂鸣器响
	else
		GPIO_SetBits(BUZZER_PORT, BUZZER_PIN);   // 蜂鸣器静音
		
	if(LED0_state)
		GPIO_ResetBits(LED2_PORT, LED2_PIN); // LED点亮
	else
		GPIO_SetBits(LED2_PORT, LED2_PIN);   // LED熄灭
}


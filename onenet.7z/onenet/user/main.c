//单片机头文件
#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

//硬件驱动
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "dht11.h"
#include "oled.h"
#include "led.h"
#include "key.h"
#include "adc.h"
#include "pin_config.h"
#include "actuator.h"
//C库
#include <string.h>

// DHT11数据数组声明
extern unsigned char Data[5];


#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

extern unsigned int Usart1_RxCounter;      //定义一个变量，记录串口1总共接收了多少字节的数据
extern char Usart1_RxBuff[USART1_RXBUFF_SIZE]; //定义一个数组，用于保存串口1接收到的数据 


u8 temperature=0,humidity=0,gadc=0;

u8 temp = 0;
u8 humi = 0;
u8 mq2 = 0;
u8 mq135 = 0;
u8 car_state = 0;

// DHT11传感器相关变量
u8 dht11_temp = 0;
u8 dht11_humi = 0;
u8 use_dht11_data = 1;  // 1:使用DHT11数据, 0:使用串口数据
u16 dht11_read_counter = 0;  // DHT11读取计数器

u8 temph = 40;
u8 humih = 70;
u8 mq2h = 40;
u8 mq135h = 40;

u8 bufang = 0;

u32 alarm_cnt = 0;

/*
************************************************************
*	函数名称：	Print_AllDeviceStatus
*
*	函数功能：	打印所有设备状态到串口
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		打印传感器数据和设备状态
************************************************************
*/
void Print_AllDeviceStatus(void)
{
	UsartPrintf(USART_DEBUG, "\r\n========== Device Status ==========\r\n");
	UsartPrintf(USART_DEBUG, "Sensors:\r\n");
	UsartPrintf(USART_DEBUG, "  Temperature: %d C\r\n", temp);
	UsartPrintf(USART_DEBUG, "  Humidity: %d %%\r\n", humi);
	UsartPrintf(USART_DEBUG, "  MQ2: %d\r\n", mq2);
	UsartPrintf(USART_DEBUG, "  MQ135: %d\r\n", mq135);
	UsartPrintf(USART_DEBUG, "  Car State: %s\r\n", car_state? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "  Switchs (Bufang): %s\r\n", bufang? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "\r\nActuators:\r\n");
	UsartPrintf(USART_DEBUG, "  FS (Fan): %s\r\n", FS? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "  KT (AC): %s\r\n", KT? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "\r\nIndicators:\r\n");
	UsartPrintf(USART_DEBUG, "  RED LED: %s\r\n", RED? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "  LED0: %s\r\n", LED0? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "  BEEP: %s\r\n", BEEP? "ON" : "OFF");
	UsartPrintf(USART_DEBUG, "\r\nThresholds:\r\n");
	UsartPrintf(USART_DEBUG, "  Temp: %d C, Humi: %d %%, MQ2: %d, MQ135: %d\r\n", temph, humih, mq2h, mq135h);
	UsartPrintf(USART_DEBUG, "=====================================\r\n\r\n");
}

/*
************************************************************
*	函数名称：	OLED_ShowMainPanel
*
*	函数功能：	显示主界面面板（参照引脚连接图设备模块）
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		按照引脚连接图的设备分类显示
************************************************************
*/
void OLED_ShowMainPanel(void)
{
	// 第0行：标题 - 温度监控系统 (字符编号0-7对应：温、度、监、控、系、统、湿、度)
	OLED_ShowCHinese(0,0,0);   // 温
	OLED_ShowCHinese(16,0,1);  // 度
	OLED_ShowCHinese(32,0,2);  // 监
	OLED_ShowCHinese(48,0,3);  // 控
	OLED_ShowCHinese(64,0,4);  // 系
	OLED_ShowCHinese(80,0,5);  // 统
	
	// 第2行：传感器模块 - DHT11温湿度传感器
	OLED_ShowCHinese(0,2,8);   // 温
	OLED_ShowCHinese(16,2,9);  // 度
	OLED_ShowString(32,2,":"); 
	OLED_ShowChar(40,2,temp/10+0x30);
	OLED_ShowChar(48,2,temp%10+0x30);
	OLED_ShowString(56,2,"C");
	
	OLED_ShowCHinese(64,2,10); // 湿
	OLED_ShowCHinese(80,2,11); // 度
	OLED_ShowString(96,2,":");
	OLED_ShowChar(104,2,humi/10+0x30);
	OLED_ShowChar(112,2,humi%10+0x30);
	OLED_ShowString(120,2,"%");
	
	// 第4行：传感器模块 - MQ2烟雾、MQ135有害气体
	OLED_ShowCHinese(0,4,12);  // 烟
	OLED_ShowCHinese(16,4,13); // 雾
	OLED_ShowString(32,4,":");
	OLED_ShowChar(40,4,mq2/10+0x30);
	OLED_ShowChar(48,4,mq2%10+0x30);
	OLED_ShowString(56,4,"%");
	
	OLED_ShowCHinese(64,4,16); // 有
	OLED_ShowCHinese(80,4,17); // 害
	OLED_ShowCHinese(96,4,18);  // 气
	OLED_ShowCHinese(112,4,19);// 体
	OLED_ShowString(120,4,":"); 
	OLED_ShowChar(0,6,mq135/10+0x30);
	OLED_ShowChar(8,6,mq135%10+0x30);
	OLED_ShowString(16,6,"%");
	
	// 汽车状态显示（如果有，显示在第4行右侧）
	if(car_state == 1)
	{
		OLED_ShowCHinese(100,4,20); // 有
		OLED_ShowCHinese(112,4,21); // 人
	}
	else
	{
		OLED_ShowString(100,4,"    ");
	}
	
	// 第6行：执行器状态显示（风扇FS、空调KT、有害气体值）
	OLED_ShowString(32,6,"FS:");
	OLED_ShowString(56,6,FS? "ON " : "OFF");
	OLED_ShowString(80,6,"KT:");
	OLED_ShowString(104,6,KT? "ON " : "OFF");
}

/*
************************************************************
*	函数名称：	OLED_ShowSensorPanel
*
*	函数功能：	显示传感器详细界面
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		显示所有传感器数据和阈值对比
************************************************************
*/
void OLED_ShowSensorPanel(void)
{
	// 第0行：标题
	OLED_ShowCHinese(0,0,8);   // 温
	OLED_ShowCHinese(16,0,9);  // 度
	OLED_ShowCHinese(32,0,10); // 湿
	OLED_ShowCHinese(48,0,11); // 度
	OLED_ShowCHinese(64,0,2);  // 监
	OLED_ShowCHinese(80,0,3);  // 控
	
	// 第2行：温度数据
	OLED_ShowCHinese(0,2,8);   // 温
	OLED_ShowCHinese(16,2,9);  // 度
	OLED_ShowString(32,2,":");
	OLED_ShowChar(40,2,temp/10+0x30);
	OLED_ShowChar(48,2,temp%10+0x30);
	OLED_ShowString(56,2,"C/");
	OLED_ShowChar(72,2,temph/10+0x30);
	OLED_ShowChar(80,2,temph%10+0x30);
	OLED_ShowString(88,2,"C");
	
	// 第4行：湿度数据
	OLED_ShowCHinese(0,4,10);  // 湿
	OLED_ShowCHinese(16,4,11); // 度
	OLED_ShowString(32,4,":");
	OLED_ShowChar(40,4,humi/10+0x30);
	OLED_ShowChar(48,4,humi%10+0x30);
	OLED_ShowString(56,4,"%/");
	OLED_ShowChar(72,4,humih/10+0x30);
	OLED_ShowChar(80,4,humih%10+0x30);
	OLED_ShowString(88,4,"%");
	
	// 第6行：烟雾和有害气体
	OLED_ShowCHinese(0,6,12);  // 烟
	OLED_ShowCHinese(16,6,13); // 雾
	OLED_ShowString(32,6,":");
	OLED_ShowChar(40,6,mq2/10+0x30);
	OLED_ShowChar(48,6,mq2%10+0x30);
	OLED_ShowCHinese(64,6,16); // 有
	OLED_ShowCHinese(80,6,17); // 害
	OLED_ShowString(96,6,":");
	OLED_ShowChar(104,6,mq135/10+0x30);
	OLED_ShowChar(112,6,mq135%10+0x30);
}

/*
************************************************************
*	函数名称：	OLED_ShowActuatorPanel
*
*	函数功能：	显示执行器界面
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		显示执行器状态和控制信息
************************************************************
*/
void OLED_ShowActuatorPanel(void)
{
	// 第0行：标题
	OLED_ShowCHinese(0,0,2);   // 监
	OLED_ShowCHinese(16,0,3);  // 控
	OLED_ShowCHinese(32,0,4);  // 系
	OLED_ShowCHinese(48,0,5);  // 统
	
	// 第2行：风扇状态
	OLED_ShowString(0,2,"FS:");
	OLED_ShowString(32,2,FS? "ON " : "OFF");
	if(mq2 > mq2h || mq135 > mq135h)
	{
		OLED_ShowCHinese(64,2,12);  // 烟
		OLED_ShowCHinese(80,2,13);   // 雾
		OLED_ShowCHinese(96,2,17);   // 害
		OLED_ShowCHinese(112,2,19);  // 体
	}
	
	// 第4行：空调状态
	OLED_ShowString(0,4,"KT:");
	OLED_ShowString(32,4,KT? "ON " : "OFF");
	if(temp > temph || humi > humih)
	{
		OLED_ShowCHinese(64,4,8);   // 温
		OLED_ShowCHinese(80,4,9);   // 度
		OLED_ShowCHinese(96,4,10);  // 湿
		OLED_ShowCHinese(112,4,11); // 度
	}
	
	// 第6行：汽车状态和布防状态
	if(car_state == 1)
	{
		OLED_ShowCHinese(0,6,20);  // 有
		OLED_ShowCHinese(16,6,21);  // 人
	}
	else
	{
		OLED_ShowString(0,6,"No");
	}
	OLED_ShowString(48,6,"Buf:");
	OLED_ShowString(80,6,bufang? "ON" : "OFF");
}

/*
************************************************************
*	函数名称：	OLED_ShowDeviceStatusPanel
*
*	函数功能：	显示设备状态界面
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		显示所有设备状态：传感器+执行器+指示灯
************************************************************
*/
void OLED_ShowDeviceStatusPanel(void)
{
	// 第0行：标题
	OLED_ShowString(0,0,"Device Status");
	
	// 第2行：传感器状态
	OLED_ShowCHinese(0,2,8);   // 温
	OLED_ShowChar(16,2,temp/10+0x30);
	OLED_ShowChar(24,2,temp%10+0x30);
	OLED_ShowCHinese(32,2,10); // 湿
	OLED_ShowChar(48,2,humi/10+0x30);
	OLED_ShowChar(56,2,humi%10+0x30);
	OLED_ShowCHinese(64,2,12);  // 烟
	OLED_ShowChar(80,2,mq2/10+0x30);
	OLED_ShowChar(88,2,mq2%10+0x30);
	
	// 第4行：执行器状态
	OLED_ShowString(0,4,"FS:");
	OLED_ShowString(24,4,FS? "ON " : "OFF");
	OLED_ShowString(48,4,"KT:");
	OLED_ShowString(72,4,KT? "ON " : "OFF");
	OLED_ShowString(96,4,"RED:");
	OLED_ShowString(120,4,RED? "ON" : "OF");
	
	// 第6行：指示灯状态
	OLED_ShowString(0,6,"LED:");
	OLED_ShowString(32,6,LED0? "ON " : "OFF");
	OLED_ShowString(56,6,"BEEP:");
	OLED_ShowString(96,6,BEEP? "ON" : "OFF");
}

/*
************************************************************
*	函数名称：	OLED_ShowSettingPanel
*
*	函数功能：	显示设置界面面板（阈值设置）
*
*	入口参数：	set_type - 当前选中的设置项（0-3）
*
*	返回参数：	无
*
*	说明：		显示温度、湿度、烟雾、有害气体的阈值设置
************************************************************
*/
void OLED_ShowSettingPanel(u8 set_type)
{
	// 第0行：温度阈值设置
	OLED_ShowCHinese(0,0,8);   // 温
	OLED_ShowCHinese(16,0,9);  // 度
	OLED_ShowCHinese(32,0,24); // 阈
	OLED_ShowCHinese(48,0,26); // 值
	OLED_ShowString(64,0,":");
	OLED_ShowChar(72,0,temph/10+0x30);
	OLED_ShowChar(80,0,temph%10+0x30);
	OLED_ShowString(88,0,"C");
	if(set_type == 0)
		OLED_ShowString(120,0,"<");  // 选中标记
	else
		OLED_ShowString(120,0," ");
		
	// 第2行：湿度阈值设置
	OLED_ShowCHinese(0,2,10);  // 湿
	OLED_ShowCHinese(16,2,11); // 度
	OLED_ShowCHinese(32,2,24); // 阈
	OLED_ShowCHinese(48,2,26); // 值
	OLED_ShowString(64,2,":");
	OLED_ShowChar(72,2,humih/10+0x30);
	OLED_ShowChar(80,2,humih%10+0x30);
	OLED_ShowString(88,2,"%");
	if(set_type == 1)
		OLED_ShowString(120,2,"<");
	else
		OLED_ShowString(120,2," ");
		
	// 第4行：烟雾阈值设置
	OLED_ShowCHinese(0,4,12);  // 烟
	OLED_ShowCHinese(16,4,13); // 雾
	OLED_ShowCHinese(32,4,24); // 阈
	OLED_ShowCHinese(48,4,26); // 值
	OLED_ShowString(64,4,":");
	OLED_ShowChar(72,4,mq2h/10+0x30);
	OLED_ShowChar(80,4,mq2h%10+0x30);
	OLED_ShowString(88,4,"%");
	if(set_type == 2)
		OLED_ShowString(120,4,"<");
	else
		OLED_ShowString(120,4," ");
		
	// 第6行：有害气体阈值设置（简化显示，节省空间）
	OLED_ShowCHinese(0,6,16);  // 有
	OLED_ShowCHinese(16,6,17); // 害
	OLED_ShowCHinese(32,6,24);  // 阈
	OLED_ShowCHinese(48,6,26);  // 值
	OLED_ShowString(64,6,":");
	OLED_ShowChar(72,6,mq135h/10+0x30);
	OLED_ShowChar(80,6,mq135h%10+0x30);
	OLED_ShowString(88,6,"%");
	if(set_type == 3)
		OLED_ShowString(120,6,"<");
	else
		OLED_ShowString(120,6," ");
}

/*
************************************************************
*	函数名称：	Hardware_Init
*
*	函数功能：	硬件初始化
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		初始化单片机功能以及外接设备
************************************************************
*/
void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置
	Delay_Init();									//systick初始化
	Usart1_Init(9600);							//串口1，打印信息用
	Usart2_Init(115200);							//串口2，驱动ESP8266用
	OLED_Init();
	LED_Init();
	Key_Init();
	Adc_Init();
	Actuator_Init();								//初始化执行器(FS/KT)
	// DHT11_Init();								//DHT11初始化在读取时进行
	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	
}

/*
************************************************************
*	函数名称：	main
*
*	函数功能：	
*
*	入口参数：	无
*
*	返回参数：	0
*
*	说明：		
************************************************************
*/
int main(void)
{
	u8 current_page = 0;  // 当前界面：0-主界面, 1-传感器界面, 2-执行器界面, 3-设备状态界面, 4-设置界面
	u8 set_type = 0;      // 设置界面当前选中的设置项（0-3）
	 
	u8 key_val = 0;

	
	unsigned short timeCount = 0;	//发送间隔变量
	
	unsigned char *dataPtr = NULL;
	
	Hardware_Init();				//初始化外围硬件
	#if 1
	OLED_ShowString(20,3,"Networking");
	ESP8266_Init();					//初始化ESP8266
	OLED_ShowString(0,3,"                ");
	OLED_ShowString(0,3," Connected to");
	OLED_ShowString(30,6,"ONENET");
	UsartPrintf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		delay_ms(500);
	UsartPrintf(USART_DEBUG, "NET_OK\r\n");
	
	while(OneNet_DevLink())			//接入OneNET
	FS = 1;
	KT = 1;
	Update_GPIO_States();
	delay_ms(500);
	FS = 0;
	KT = 0;
	Update_GPIO_States();
	OneNET_Subscribe();
	#endif
	OLED_Clear();
	OLED_ShowMainPanel();  // 显示主界面（界面0）
	

	// 按键诊断模式开关（设为1启用诊断模式，会持续打印按键状态）
	u8 key_debug_mode = 1;  // 0-正常模式, 1-诊断模式（建议先设为1检查按键）
	u16 key_check_counter = 0;  // 按键检查计数器（用于诊断模式）
	
	while(1)
	{
		// 按键诊断模式（每500ms打印一次按键状态）
		if(key_debug_mode == 1)
		{
			key_check_counter++;
			if(key_check_counter >= 500)  // 每500ms检查一次
			{
				key_check_counter = 0;
				UsartPrintf(USART_DEBUG, "\r\n=== Key Status ===\r\n");
				UsartPrintf(USART_DEBUG, "KEY1(PA4): %d\r\n", GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4));
				UsartPrintf(USART_DEBUG, "KEY2(PA5): %d\r\n", GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5));
				UsartPrintf(USART_DEBUG, "KEY3(PB0): %d\r\n", GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0));
				UsartPrintf(USART_DEBUG, "KEY4(PB11): %d\r\n", GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11));
				UsartPrintf(USART_DEBUG, "Note: 0=Pressed, 1=Released\r\n");
			}
		}
		
		// 读取DHT11传感器数据 我在这加了一个判断的，看看成不成功
		if(use_dht11_data)
		{
			dht11_read_counter++;
			if(dht11_read_counter >= 100)  
			{
				dht11_read_counter = 0;
				if(DHT11_GetData() == 1)  // DHT11_GetData返回1表示成功
				{
					dht11_temp = Data[2];  // 温度整数部分
					dht11_humi = Data[0];  // 湿度整数部分
					temp = dht11_temp;
					humi = dht11_humi;
					UsartPrintf(USART_DEBUG, "DHT11 - Temp:%dC, Humi:%d%%\r\n", temp, humi);
				}
				else
				{
					UsartPrintf(USART_DEBUG, "DHT11 read failed\r\n");
				}
			}
		}
		
		/*
		0x9a temp mq2 water_level car_state 0xff
		*/
		if(Usart1_RxCounter&0x8000)//判断是否收到NBIOT的下发数据
		{
			// 只有在不使用DHT11数据时才更新温湿度
			if(!use_dht11_data)
			{
				temp = Usart1_RxBuff[1];
				humi = Usart1_RxBuff[2];
			}
			mq135 = Usart1_RxBuff[3];
			car_state = Usart1_RxBuff[4];
			mq2 = Usart1_RxBuff[5];
			
			// 根据不同界面更新显示
			if(current_page == 0)  // 主界面
			{
				// 更新主界面显示（只更新数据部分，不重绘标题）
				OLED_ShowChar(40,2,temp/10+0x30);
				OLED_ShowChar(48,2,temp%10+0x30);
				OLED_ShowChar(104,2,humi/10+0x30);
				OLED_ShowChar(112,2,humi%10+0x30);
				OLED_ShowChar(40,4,mq2/10+0x30);
				OLED_ShowChar(48,4,mq2%10+0x30);
				OLED_ShowChar(0,6,mq135/10+0x30);
				OLED_ShowChar(8,6,mq135%10+0x30);
				
				// 更新执行器状态
				OLED_ShowString(56,6,FS? "ON " : "OFF");
				OLED_ShowString(104,6,KT? "ON " : "OFF");
				
				// 更新汽车状态显示
				if(car_state == 1)
				{
					OLED_ShowCHinese(100,4,20); // 有
					OLED_ShowCHinese(112,4,21); // 人
				}
				else
				{
					OLED_ShowString(100,4,"    ");
				}
			}
			else if(current_page == 1)  // 传感器界面
			{
				// 更新传感器界面数据
				OLED_ShowChar(40,2,temp/10+0x30);
				OLED_ShowChar(48,2,temp%10+0x30);
				OLED_ShowChar(40,4,humi/10+0x30);
				OLED_ShowChar(48,4,humi%10+0x30);
				OLED_ShowChar(40,6,mq2/10+0x30);
				OLED_ShowChar(48,6,mq2%10+0x30);
				OLED_ShowChar(104,6,mq135/10+0x30);
				OLED_ShowChar(112,6,mq135%10+0x30);
			}
			else if(current_page == 2)  // 执行器界面
			{
				// 重绘执行器界面以更新所有状态
				OLED_ShowActuatorPanel();
			}
			else if(current_page == 3)  // 设备状态界面
			{
				// 重绘设备状态界面以更新所有状态
				OLED_ShowDeviceStatusPanel();
			}

			
			Usart1_RxCounter = 0;//串口接收计数清零
		}
		key_val = Key_GetNum();
		
		// 诊断模式：每次检测到按键值都打印
		if(key_debug_mode == 1 && key_val != 0)
		{
			UsartPrintf(USART_DEBUG, "Key pressed: KEY%d\r\n", key_val);
		}
		
		if(key_val != 0)
		{
			// 添加小延时，确保按键处理稳定
			delay_ms(10);
			
			// 串口打印按键操作
			UsartPrintf(USART_DEBUG, "Processing KEY%d on page %d\r\n", key_val, current_page);
			
			switch(key_val)
			{
				case 1:  // KEY1: 切换界面（循环切换 0->1->2->3->4->0）
					OLED_Clear();
					current_page = (current_page + 1) % 5;  // 循环切换0-4
					set_type = 0;  // 进入设置界面时重置选中项
					
					// 根据界面编号显示相应界面
					switch(current_page)
					{
						case 0:
							OLED_ShowMainPanel();  // 主界面
							break;
						case 1:
							OLED_ShowSensorPanel();  // 传感器界面
							break;
						case 2:
							OLED_ShowActuatorPanel();  // 执行器界面
							break;
						case 3:
							OLED_ShowDeviceStatusPanel();  // 设备状态界面
							break;
						case 4:
							OLED_ShowSettingPanel(set_type);  // 设置界面
							break;
					}
					UsartPrintf(USART_DEBUG, "Switch to page %d\r\n", current_page);
				break;
				case 2:  // KEY2: 在设置界面切换设置项，在其他界面切换数据源
					if(current_page == 4)  // 设置界面
					{
						// 切换设置项
						set_type = (set_type + 1) % 4;
						OLED_ShowSettingPanel(set_type);  // 重新显示设置界面，更新选中标记
						UsartPrintf(USART_DEBUG, "Select setting item %d\r\n", set_type);
					}
					else  // 其他界面
					{
						// 切换数据源
						use_dht11_data = !use_dht11_data;
						if(use_dht11_data)
						{
							UsartPrintf(USART_DEBUG, "Switch to DHT11 data source\r\n");
						}
						else
						{
							UsartPrintf(USART_DEBUG, "Switch to serial data source\r\n");
						}
					}
				break;
				case 3:  // KEY3: 在设置界面增加阈值，在其他界面无操作
					if(current_page == 4)  // 设置界面
					{
						// 增加当前选中项的阈值
						if(set_type == 0 && temph < 99)
						{
							temph++;
							UsartPrintf(USART_DEBUG, "Temp threshold: %d\r\n", temph);
						}
						else if(set_type == 1 && humih < 99)
						{
							humih++;
							UsartPrintf(USART_DEBUG, "Humi threshold: %d\r\n", humih);
						}
						else if(set_type == 2 && mq2h < 99)
						{
							mq2h++;
							UsartPrintf(USART_DEBUG, "MQ2 threshold: %d\r\n", mq2h);
						}
						else if(set_type == 3 && mq135h < 99)
						{
							mq135h++;
							UsartPrintf(USART_DEBUG, "MQ135 threshold: %d\r\n", mq135h);
						}
						// 更新显示
						OLED_ShowSettingPanel(set_type);
					}
				break;
				case 4:  // KEY4: 在设置界面减少阈值，在其他界面无操作
					if(current_page == 4)  // 设置界面
					{
						// 减少当前选中项的阈值
						if(set_type == 0 && temph > 0)
						{
							temph--;
							UsartPrintf(USART_DEBUG, "Temp threshold: %d\r\n", temph);
						}
						else if(set_type == 1 && humih > 0)
						{
							humih--;
							UsartPrintf(USART_DEBUG, "Humi threshold: %d\r\n", humih);
						}
						else if(set_type == 2 && mq2h > 0)
						{
							mq2h--;
							UsartPrintf(USART_DEBUG, "MQ2 threshold: %d\r\n", mq2h);
						}
						else if(set_type == 3 && mq135h > 0)
						{
							mq135h--;
							UsartPrintf(USART_DEBUG, "MQ135 threshold: %d\r\n", mq135h);
						}
						// 更新显示
						OLED_ShowSettingPanel(set_type);
					}
				break;
				default:
				break;
			}
		}
		// 报警和控制逻辑（在所有界面都执行）
		if(current_page != 4)  // 不在设置界面时执行报警逻辑
		{
			if((bufang == 1 && car_state == 1) || temp > temph || humi > humih || mq135 > mq135h || mq2 > mq2h)
			{
				if(alarm_cnt++ >= 20)
				{
					BEEP = !BEEP;
					RED = !RED;
					alarm_cnt = 0;
					Update_GPIO_States();  // 更新GPIO物理引脚状态
				}
				// 根据阈值控制执行器
				if(temp > temph || humi > humih)
				{
					KT = 1;
				}
				else
				{
					KT = 0;
				}
				if(mq2 > mq2h || mq135 > mq135h)
				{
					FS = 1;
				}
				else
				{
					FS = 0;
				}
				Update_GPIO_States();  // 更新GPIO物理引脚状态
				
				// 根据当前界面更新显示
				if(current_page == 0)  // 主界面
				{
					// 更新汽车状态显示（在第4行右侧）
					if(car_state == 1)
					{
						OLED_ShowCHinese(100,4,20); // 有
						OLED_ShowCHinese(112,4,21); // 人
					}
					else
					{
						OLED_ShowString(100,4,"    ");
					}
					// 更新执行器状态显示
					OLED_ShowString(56,6,FS? "ON " : "OFF");
					OLED_ShowString(104,6,KT? "ON " : "OFF");
				}
				else if(current_page == 2)  // 执行器界面
				{
					OLED_ShowActuatorPanel();  // 重绘执行器界面
				}
				else if(current_page == 3)  // 设备状态界面
				{
					OLED_ShowDeviceStatusPanel();  // 重绘设备状态界面
				}
			}
			else 
			{
				RED = 1;
				BEEP = 0;
				alarm_cnt = 0;
				FS = 0;
				KT = 0;
				Update_GPIO_States();  // 更新GPIO物理引脚状态
				
				// 根据当前界面更新显示
				if(current_page == 0)  // 主界面
				{
					// 更新汽车状态显示
					if(car_state == 0)
						OLED_ShowString(100,4,"    ");
					// 更新执行器状态显示
					OLED_ShowString(56,6,FS? "ON " : "OFF");
					OLED_ShowString(104,6,KT? "ON " : "OFF");
				}
				else if(current_page == 2)  // 执行器界面
				{
					OLED_ShowActuatorPanel();  // 重绘执行器界面
				}
				else if(current_page == 3)  // 设备状态界面
				{
					OLED_ShowDeviceStatusPanel();  // 重绘设备状态界面
				}
			}
		}
		if(++timeCount >= 500)									//发送间隔5s
		{


			//UsartPrintf(USART_DEBUG,"TEMP:%d HUMI:%d MQ2:%d\r\n",temperature,humidity,adc);
			UsartPrintf(USART_DEBUG, "OneNet_SendData\r\n");
			
			// 打印所有设备状态到串口
			Print_AllDeviceStatus();
			
			OneNet_SendData();									//发送数据到云平台
			
			timeCount = 0;
			ESP8266_Clear();
			
			LED0 = !LED0;
			Update_GPIO_States();  // 更新GPIO物理引脚状态
		}
		
		dataPtr = ESP8266_GetIPD(0);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		
		delay_ms(1);
	
	}

}

#include "delay.h"
#include "led.h"
#include "key.h"
#include "usart.h"

int main(void)
{
    delay_init();
    LED_Init();
    key_init();
    uart_init(115200);  // 初始化串口，波特率115200

    LED0 = 1;
    LED1 = 1;

    while (1)
    {	
        uint8_t k = key_scan(0);

        if (k == KEY0_PRES)
        {
            /* 按 KEY0：LED0 反转 */
            LED0 = !LED0;
            printf("KEY0 pressed, LED0 = %d\r\n", LED0);
        }
        else if (k == KEY1_PRES)
        {
            /* 按 KEY1：LED1 反转 */
            LED1 = !LED1;
            printf("KEY1 pressed, LED1 = %d\r\n", LED1);
        }
        else if (k == KEY2_PRES)
        {
            /* 按 KEY2：同时反转 LED0 与 LED1 */
            LED0 = !LED0;
            LED1 = !LED1;
            printf("KEY2 pressed, LED0=%d, LED1=%d\r\n", LED0, LED1);
        }

        /* 串口通信协议处理：接收 #字符串* 格式，只显示中间的数据 */
        if (USART_RX_STA & 0x8000)  /* 一帧完成：格式 #payload* */
        {
            u16 len = (USART_RX_STA & 0x3FFF); /* payload长度（不含#和*） */

            /* 只显示接收到的数据内容，不显示#和*，不换行 */
            for (u16 i = 0; i < len; i++) 
            {
                printf("%c", USART_RX_BUF[i]);
            }

            /* 清状态，准备下一帧 */
            USART_RX_STA = 0;
        }

        delay_ms(10);
    }
}
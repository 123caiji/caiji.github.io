
#include "key.h"

/* mode=0: 不支持连按; mode=1: 支持连按 */
void key_init(void)
{
	GPIO_InitTypeDef gpio;

	/* 使能GPIO时钟 */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOA, ENABLE);

	/* KEY0~KEY2: 上拉输入（按下为低） */
	gpio.GPIO_Pin   = KEY0_GPIO_PIN | KEY1_GPIO_PIN | KEY2_GPIO_PIN;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	gpio.GPIO_Mode  = GPIO_Mode_IPU;
	GPIO_Init(GPIOE, &gpio);

	/* WK_UP: 下拉输入（按下为高） */
	gpio.GPIO_Pin   = WKUP_GPIO_PIN;
	gpio.GPIO_Mode  = GPIO_Mode_IPD;
	GPIO_Init(GPIOA, &gpio);
}

uint8_t key_scan(uint8_t mode)
{
	static uint8_t key_up = 1; /* 按键松开标志 */
	uint8_t key = 0;

	if (mode) key_up = 1;      /* 支持连按 */

	if (key_up && (KEY0 == 0 || KEY1 == 0 || KEY2 == 0 || WK_UP == 1))
	{
		/* 消抖 */
		for (volatile int i = 0; i < 50000; i++);
		key_up = 0;

		if (KEY0 == 0) key = KEY0_PRES;
		else if (KEY1 == 0) key = KEY1_PRES;
		else if (KEY2 == 0) key = KEY2_PRES;
		else if (WK_UP == 1) key = WKUP_PRES;
	}
	else if (KEY0 == 1 && KEY1 == 1 && KEY2 == 1 && WK_UP == 0)
	{
		key_up = 1;
	}

	return key;
}





















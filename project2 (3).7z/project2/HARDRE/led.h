

#ifndef __LED_H
#define __LED_H

#include "sys.h"

/* 位带操作：可直接使用 LED	0 = 0/1, LED1 = 0/1 */
#define LED0  PBout(5)   /* LED0 -> PB5 */
#define LED1  PEout(5)   /* LED1 -> PE5 */

void LED_Init(void);
#endif


















#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include "Key.h"
#include "Buzzer.h"
#include "DHT11.h"
#include "LightSensor.h"
#include "Servo.h"
#include "AS608.h"
#include "AS608_USART.h"
#include "Menu.h"
#include "SystemDemo.h"


// 全局变量
uint32_t system_tick = 0;  // 系统时间计数器

int main(void)
{
    /*系统初始化*/
    OLED_Init();        // OLED初始化
    LED_Init();         // LED初始化
    Key_Init();         // 按键初始化
    Buzzer_Init();      // 蜂鸣器初始化
    LightSensor_Init(); // 光敏传感器初始化
    Servo_Init();       // 舵机初始化
    AS608_USART_Init(); // AS608串口初始化
    GZ_StaGPIO_Init();  // AS608状态引脚初始化
    Menu_Init();        // 菜单系统初始化
    
    /*系统启动动画 - 智能家居主题*/
    OLED_Clear();
    OLED_ShowString(1, 1, "SmartHome");
    OLED_ShowString(2, 1, "Access Control");
    OLED_ShowString(3, 1, "System V1.0");
    
    // 启动动画
    for (uint8_t i = 0; i < 16; i++) {
        OLED_ShowString(4, 1, "Loading");
        for (uint8_t j = 0; j < (i % 4); j++) {
            OLED_ShowString(4, 8 + j, ".");
        }
        Delay_ms(200);
    }
    
    OLED_Clear();
    OLED_ShowString(1, 1, "System Ready");
    OLED_ShowString(2, 1, "Welcome Home!");
    OLED_ShowString(3, 1, "Press Key to Start");
    
    // 启动提示音
    Buzzer_ON();
    Delay_ms(300);
    Buzzer_OFF();
    Delay_ms(200);
    Buzzer_ON();
    Delay_ms(300);
    Buzzer_OFF();
    
    Delay_ms(2000);
    
    /*主循环*/
    while (1)
    {
        uint8_t key = Key_GetNum();
        
        // 按键处理
        if (key == KEY_BACK) {
            Menu_Back();  // 返回键
        } else if (key == KEY_OK) {
            if (current_menu == MENU_MAIN) {
                Menu_Select();  // 主菜单中选择
            } else {
                // 在子菜单中执行相应功能
                switch (current_menu) {
                    case MENU_FINGERPRINT:
                        if (system_status.fingerprint_connected) {
                            // 执行当前选中的指纹功能
                            if (fingerprint_func_mode == 0) {
                                // 1. 扫描指纹 - 门禁识别
                                OLED_Clear();
                                OLED_ShowString(1, 1, "Access Control");
                                OLED_ShowString(2, 1, "Scan Finger");
                                
                                uint8_t result = GZ_GetImage();
                                if (result == 0x00) {
                                    result = GZ_GenChar(CharBuffer1);
                                    if (result == 0x00) {
                                        SearchResult search_result;
                                        result = GZ_Search(CharBuffer1, 1, 160, &search_result);
                                        if (result == 0x00) {
                                            // 检查匹配度
                                            if (search_result.mathscore > 100) {
                                                OLED_Clear();
                                                OLED_ShowString(1, 1, "Access Granted");
                                                OLED_ShowString(2, 1, "User ID:");
                                                OLED_ShowNum(2, 9, search_result.pageID, 3);
                                                OLED_ShowString(3, 1, "Opening Door");
                                                
                                                LED1_ON();
                                                Buzzer_ON();
                                                Delay_ms(500);
                                                Buzzer_OFF();
                                                
                                                // 门禁识别成功后开门
                                                Servo_SetAngle(0);  // 开门
                                                Delay_ms(2000);
                                                Servo_SetAngle(90); // 关门
                                                
                                                Delay_ms(1500);
                                                LED1_OFF();
                                            } else {
                                                OLED_Clear();
                                                OLED_ShowString(1, 1, "Access Denied");
                                                OLED_ShowString(2, 1, "Low Confidence");
                                                LED2_ON();
                                                Delay_ms(2000);
                                                LED2_OFF();
                                            }
                                        } else {
                                            OLED_Clear();
                                            OLED_ShowString(1, 1, "Access Denied");
                                            OLED_ShowString(2, 1, "Unknown User");
                                            OLED_ShowString(3, 1, "Try Again");
                                            LED2_ON();
                                            Buzzer_ON();
                                            Delay_ms(200);
                                            Buzzer_OFF();
                                            Delay_ms(1800);
                                            LED2_OFF();
                                        }
                                    } else {
                                        OLED_Clear();
                                        OLED_ShowString(1, 1, "System Error");
                                        OLED_ShowString(2, 1, "Processing Failed");
                                        Delay_ms(2000);
                                    }
                                } else {
                                    OLED_Clear();
                                    OLED_ShowString(1, 1, "No Finger");
                                    OLED_ShowString(2, 1, "Place Finger");
                                    Delay_ms(2000);
                                }
                            } 
                            else if (fingerprint_func_mode == 1) {
                                // 2. 添加指纹 - 优化的录入流程
                                static uint16_t new_id = 1;
                                uint8_t i = 0, ensure, processnum = 0;
                                
                                OLED_Clear();
                                OLED_ShowString(1, 1, "Add Fingerprint");
                                OLED_ShowString(2, 1, "ID: ");
                                OLED_ShowNum(2, 4, new_id, 3);
                                
                                while(1)
                                {
                                    switch (processnum)
                                    {
                                        case 0:
                                            i++;
                                            OLED_ShowString(3, 1, "Press 1st time");
                                            OLED_ShowString(4, 1, "Wait...");
                                            ensure = GZ_GetImage();
                                            if(ensure == 0x00) 
                                            {
                                                ensure = GZ_GenChar(CharBuffer1);
                                                if(ensure == 0x00)
                                                {
                                                    i = 0;
                                                    processnum = 1;
                                                }			
                                            }						
                                            break;
                                        
                                        case 1:
                                            i++;
                                            OLED_ShowString(3, 1, "Press 2nd time");
                                            OLED_ShowString(4, 1, "Wait...");
                                            ensure = GZ_GetImage();
                                            if(ensure == 0x00) 
                                            {
                                                ensure = GZ_GenChar(CharBuffer2);			
                                                if(ensure == 0x00)
                                                {
                                                    i = 0;
                                                    processnum = 2;
                                                }
                                            }	
                                            break;
        
                                        case 2:
                                            OLED_ShowString(3, 1, "Matching...");
                                            OLED_ShowString(4, 1, "Please wait");
                                            ensure = GZ_Match();
                                            if(ensure == 0x00) 
                                            {
                                                processnum = 3;
                                            }
                                            else 
                                            {
                                                i = 0;
                                                processnum = 0; // 返回第一步		
                                            }
                                            Delay_ms(1000);
                                            break;
        
                                        case 3:
                                            OLED_ShowString(3, 1, "Creating Model");
                                            OLED_ShowString(4, 1, "Please wait");
                                            ensure = GZ_RegModel();
                                            if(ensure == 0x00) 
                                            {
                                                processnum = 4;
                                            }else {processnum = 0;}
                                            Delay_ms(1000);
                                            break;
                                            
                                        case 4:	
                                            OLED_ShowString(3, 1, "Storing...");
                                            OLED_ShowString(4, 1, "Please wait");
                                            ensure = GZ_StoreChar(CharBuffer2, new_id);
                                            if(ensure == 0x00) 
                                            {
                                                OLED_Clear();
                                                OLED_ShowString(1, 1, "Enroll Success");
                                                OLED_ShowString(2, 1, "ID: ");
                                                OLED_ShowNum(2, 4, new_id, 3);
                                                OLED_ShowString(3, 1, "Saved!");
                                                LED1_ON();
                                                Buzzer_ON();
                                                Delay_ms(500);
                                                Buzzer_OFF();
                                                Delay_ms(1000);
                                                LED1_OFF();
                                                new_id++;
                                                break; // 退出录入循环
                                            }else {
                                                OLED_Clear();
                                                OLED_ShowString(1, 1, "Store Error");
                                                OLED_ShowString(2, 1, "Code: ");
                                                OLED_ShowNum(2, 7, ensure, 2);
                                                Delay_ms(2000);
                                                processnum = 0;
                                            }					
                                            break;				
                                    }
                                    Delay_ms(800);
                                    if(i == 10) // 超时10秒没有放指纹就退出
                                    {
                                        OLED_Clear();
                                        OLED_ShowString(1, 1, "Timeout");
                                        OLED_ShowString(2, 1, "Cancelled");
                                        Delay_ms(1000);
                                        break;	
                                    }
                                    
                                    // 如果成功了，跳出外层循环
                                    if(ensure == 0x00 && processnum == 4)
                                    {
                                        break;
                                    }
                                }
                            }
                            else if (fingerprint_func_mode == 2) {
                                // 3. 删除指纹 - 参考标准库显示
                                OLED_Clear();
                                OLED_ShowString(1, 1, "Delete Finger");
                                OLED_ShowString(2, 1, "Scan to delete");
                                
                                uint8_t result = GZ_GetImage();
                                if (result == 0x00) {
                                    result = GZ_GenChar(CharBuffer1);
                                    if (result == 0x00) {
                                        SearchResult search_result;
                                        result = GZ_Search(CharBuffer1, 1, 160, &search_result);
                                        if (result == 0x00) {
                                            OLED_Clear();
                                            OLED_ShowString(1, 1, "Found ID: ");
                                            OLED_ShowNum(1, 10, search_result.pageID, 3);
                                            OLED_ShowString(2, 1, "Deleting...");
                                            Delay_ms(500);
                                            
                                            result = GZ_DeletChar(search_result.pageID, 1);
                                            if (result == 0x00) {
                                                OLED_ShowString(2, 1, "Deleted!");
                                                LED2_ON();
                                                Buzzer_ON();
                                                Delay_ms(200);
                                                Buzzer_OFF();
                                                Delay_ms(200);
                                                Buzzer_ON();
                                                Delay_ms(200);
                                                Buzzer_OFF();
                                                Delay_ms(2000);
                                                LED2_OFF();
                                            } else {
                                                OLED_ShowString(2, 1, "Delete Failed!");
                                                Delay_ms(2000);
                                            }
                                        } else {
                                            OLED_Clear();
                                            OLED_ShowString(1, 1, "Not Found!");
                                            Delay_ms(2000);
                                        }
                                    } else {
                                        OLED_Clear();
                                        OLED_ShowString(1, 1, "GenChar Failed!");
                                        Delay_ms(2000);
                                    }
                                } else {
                                    OLED_Clear();
                                    OLED_ShowString(1, 1, "GetImage Failed!");
                                    Delay_ms(2000);
                                }
                            }
                            
                            // 功能执行完后，循环切换下一个功能
                            fingerprint_func_mode = (fingerprint_func_mode + 1) % 3;
                            
                            // 回到指纹菜单，等待下次按键
                            // Menu_Display() 会在主循环中自动调用
                        }
                        break;
                        
                    case MENU_ENVIRONMENT:
                        // 环境监测菜单中的按键功能
                        Menu_UpdateStatus();
                        break;
                        
                    case MENU_SERVO:
                        // 舵机控制菜单：改变角度
                        current_servo_angle = (current_servo_angle + 30) % 180;
                        if (current_servo_angle == 0) current_servo_angle = 30;
                        Servo_SetAngle(current_servo_angle);
                        Buzzer_ON();
                        Delay_ms(50);
                        Buzzer_OFF();
                        break;
                        
                    case MENU_SYSTEM_INFO:
                        // 系统信息菜单中的按键功能
                        break;
                        
                    case MENU_SETTINGS:
                        // 设置菜单：运行系统演示
                        SystemDemo_AllModules();
                        break;
                        
                    default:
                        break;
                }
            }
        } else if (key == KEY_UP) {
            Menu_Previous();  // 上翻键
        } else if (key == KEY_DOWN) {
            Menu_Next();  // 下翻键
        }
        
        
        // 更新系统时间计数器（每个主循环周期200ms）
        system_tick++;
        
        // 显示菜单（只在菜单切换或按键时刷新）
        Menu_Display();
        
        Delay_ms(200);  // 主循环延时，控制刷新频率
    }
}

# OLED显示DHT11数据实现说明

## 功能说明

在onnnet项目中添加了OLED显示DHT11温湿度数据的功能。

## 实现内容

### 1. 初始化部分

在`main.c`的`Hardware_Init()`之后添加了：
```c
DHT11_Init();  // 初始化DHT11传感器
```

### 2. 启动显示

添加了启动画面：
```c
OLED_Clear();
OLED_ShowString(20,2,"DHT11");
OLED_ShowString(20,4,"Testing...");
delay_ms(1000);
OLED_Clear();
```

### 3. 主循环中的数据显示

在`while(1)`循环中添加了DHT11数据读取和显示：

```c
// 读取DHT11数据（每秒读取一次）
static u32 dht11_delay = 0;
dht11_delay++;
if(dht11_delay >= 1000)  // 大约1秒读取一次
{
    dht11_delay = 0;
    u8 dht11_temp = 0, dht11_humi = 0;
    if(DHT11_Read_Data(&dht11_temp, &dht11_humi) == 0)  // 读取成功
    {
        temperature = dht11_temp;
        humidity = dht11_humi;
        
        // 在OLED上显示DHT11数据
        // 第1行显示温度
        OLED_ShowString(0,0,"Temp: ");
        OLED_ShowChar(48,0,temperature/10+0x30);
        OLED_ShowChar(56,0,temperature%10+0x30);
        OLED_ShowString(64,0," C");
        
        // 第2行显示湿度  
        OLED_ShowString(0,2,"Humi: ");
        OLED_ShowChar(48,2,humidity/10+0x30);
        OLED_ShowChar(56,2,humidity%10+0x30);
        OLED_ShowString(64,2," %");
    }
}
```

## 显示格式

OLED显示屏上会显示：

```
Temp: XX C      (第1行，温度)
Humi: XX %      (第2行，湿度)
```

## 硬件连接

### DHT11连接
- **VCC**: 3.3V
- **GND**: GND  
- **DATA**: PA11

### OLED连接（7引脚SPI）
- **VCC**: 3.3V
- **GND**: GND
- **SCL (时钟)**: PB1
- **SDA (数据)**: PB0
- **RES (复位)**: PA7
- **DC (数据/命令)**: PA6
- **CS (片选)**: 未使用

## 功能特点

1. **自动读取**: 每秒自动读取一次DHT11数据
2. **实时显示**: 温度湿度实时显示在OLED上
3. **错误处理**: 读取失败不会影响系统运行
4. **数据存储**: 读取成功后存储到`temperature`和`humidity`全局变量

## 使用说明

1. 确保DHT11正确连接到PA11引脚
2. 编译并下载程序
3. 上电后OLED会显示"DHT11 Testing..."
4. 1秒后开始显示温度湿度数据
5. 数据每秒更新一次

## 注意事项

1. DHT11需要2秒左右的稳定时间
2. 读取间隔建议不少于1秒
3. DHT11对电源要求较高，建议使用稳定电源
4. 如果显示异常，检查硬件连接和DHT11初始化

## 与主项目的对比

主项目(`/d:/32/sheji`)使用的OLED是I2C接口(4引脚)，而onnnet项目使用的是SPI接口(7引脚)，两者的显示函数接口相同，但底层驱动不同。

## 扩展功能

可以根据需要添加：
- 温湿度报警功能
- 历史数据记录
- 最大最小值显示
- 数据上传到云平台

---

**更新日期**: 2024年  
**版本**: V1.0


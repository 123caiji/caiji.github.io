//单片机头文件
#include "stm32f10x.h"

//网络协议层
#include "onenet.h"

//网络设备
#include "esp8266.h"

//硬件驱动
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "dht11.h"
#include "oled.h"
#include "led.h"
#include "key.h"
#include "adc.h"
//C库
#include <string.h>


#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"

extern unsigned int Usart1_RxCounter;      //定义一个变量，记录串口1总共接收了多少字节的数据
extern char Usart1_RxBuff[USART1_RXBUFF_SIZE]; //定义一个数组，用于保存串口1接收到的数据 


u8 temperature=0,humidity=0,gadc=0;

u8 temp = 0;
u8 humi = 0;
u8 mq2 = 0;
u8 mq135 = 0;
u8 car_state = 0;

u8 temph = 40;
u8 humih = 70;
u8 mq2h = 40;
u8 mq135h = 40;

u8 bufang = 0;

u32 alarm_cnt = 0;
/*
************************************************************
*	函数名称：	Hardware_Init
*
*	函数功能：	硬件初始化
*
*	入口参数：	无
*
*	返回参数：	无
*
*	说明：		初始化单片机功能以及外接设备
************************************************************
*/
void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//中断控制器分组设置
	Delay_Init();									//systick初始化
	Usart1_Init(9600);							//串口1，打印信息用
	Usart2_Init(115200);							//串口2，驱动ESP8266用
	OLED_Init();
	LED_Init();
	KEY_Init();
	Adc_Init();
	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	
}

/*
************************************************************
*	函数名称：	main
*
*	函数功能：	
*
*	入口参数：	无
*
*	返回参数：	0
*
*	说明：		
************************************************************
*/
int main(void)
{
	u8 set_flag = 0;
	u8 set_type = 0;
	 
	u8 key_val = 0;

	
	unsigned short timeCount = 0;	//发送间隔变量
	
	unsigned char *dataPtr = NULL;
	
	Hardware_Init();				//初始化外围硬件
	DHT11_Init();					//初始化DHT11
	
	// 启动显示
	OLED_Clear();
	OLED_ShowString(20,2,"DHT11");
	OLED_ShowString(20,4,"Testing...");
	delay_ms(1000);
	OLED_Clear();
	
	#if 1
	OLED_ShowString(20,3,"Networking");
	ESP8266_Init();					//初始化ESP8266
	OLED_ShowString(0,3,"                ");
	OLED_ShowString(0,3," Connected to");
	OLED_ShowString(30,6,"ONENET");
	UsartPrintf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		delay_ms(500);
	UsartPrintf(USART_DEBUG, "NET_OK\r\n");
	
	while(OneNet_DevLink())			//接入OneNET
	FS = 1;
	KT = 1;
	delay_ms(500);
	FS = 0;
	KT = 0;
	OneNET_Subscribe();
	#endif
	OLED_Clear();

	OLED_ShowCHinese(0,0,0);
	OLED_ShowCHinese(16,0,1);
	OLED_ShowCHinese(32,0,2);
	OLED_ShowCHinese(48,0,3);
	OLED_ShowCHinese(64,0,4);
	OLED_ShowCHinese(80,0,5);
	OLED_ShowCHinese(96,0,6);
	OLED_ShowCHinese(112,0,7);
	
	OLED_ShowCHinese(0,2,8);
	OLED_ShowCHinese(16,2,9);
	
	OLED_ShowCHinese(64,2,10);
	OLED_ShowCHinese(80,2,11);
	
	OLED_ShowCHinese(0,4,12);
	OLED_ShowCHinese(16,4,13);
	
	
	OLED_ShowString(32,2,":00C");
	OLED_ShowString(96,2,":00%");
	OLED_ShowString(32,4,":00%");
	
//	OLED_ShowCHinese(64,4,20);
//	OLED_ShowCHinese(80,4,21);
//	OLED_ShowCHinese(96,4,22);
//	OLED_ShowCHinese(112,4,23);
	
	OLED_ShowCHinese(0,6,16);
	OLED_ShowCHinese(16,6,17);
	OLED_ShowCHinese(32,6,18);
	OLED_ShowCHinese(48,6,19);
	
	OLED_ShowString(64,6,":00%");
	

	while(1)
	{
		// 读取DHT11数据（每秒读取一次）
		static u32 dht11_delay = 0;
		dht11_delay++;
		if(dht11_delay >= 1000)  // 大约1秒读取一次
		{
			dht11_delay = 0;
			u8 dht11_temp = 0, dht11_humi = 0;
			if(DHT11_Read_Data(&dht11_temp, &dht11_humi) == 0)  // 读取成功
			{
				temperature = dht11_temp;
				humidity = dht11_humi;
				
				// 在OLED上显示DHT11数据
				// 第1行显示温度
				OLED_ShowString(0,0,"Temp: ");
				OLED_ShowChar(48,0,temperature/10+0x30);
				OLED_ShowChar(56,0,temperature%10+0x30);
				OLED_ShowString(64,0," C");
				
				// 第2行显示湿度  
				OLED_ShowString(0,2,"Humi: ");
				OLED_ShowChar(48,2,humidity/10+0x30);
				OLED_ShowChar(56,2,humidity%10+0x30);
				OLED_ShowString(64,2," %");
			}
		}
		
		/*
		0x9a temp mq2 water_level car_state 0xff
		*/
		if(Usart1_RxCounter&0x8000)//判断是否收到NBIOT的下发数据
		{

			temp = Usart1_RxBuff[1];
			humi = Usart1_RxBuff[2];
			mq135 = Usart1_RxBuff[3];
			car_state = Usart1_RxBuff[4];
			mq2 = Usart1_RxBuff[5];
			
			if(set_flag == 0)
			{
					if(car_state == 1)
					{
						OLED_ShowCHinese(64,4,20);
						OLED_ShowCHinese(80,4,21);
						OLED_ShowCHinese(96,4,22);
						OLED_ShowCHinese(112,4,23);
					}
					else
					{
						OLED_ShowString(64,4,"        ");
					}
					
					OLED_ShowChar(40,2,temp/10+0x30);
					OLED_ShowChar(48,2,temp%10+0x30);
					OLED_ShowChar(104,2,humi/10+0x30);
					OLED_ShowChar(112,2,humi%10+0x30);
					OLED_ShowChar(40,4,mq2/10+0x30);
					OLED_ShowChar(48,4,mq2%10+0x30);
					OLED_ShowChar(72,6,mq135/10+0x30);
					OLED_ShowChar(80,6,mq135%10+0x30);
			}

			
			Usart1_RxCounter = 0;//串口接收计数清零
		}
		key_val = KEY_Scan(0);
		if(key_val != 0)
		{
			switch(key_val)
			{
				case 1:
					OLED_Clear();
					OLED_Set_Pos(0,0); 
					if(set_flag == 0)
					{
						set_flag = 1;

						OLED_ShowCHinese(0,0,8);
						OLED_ShowCHinese(16,0,9);
						OLED_ShowCHinese(32,0,24);
						OLED_ShowCHinese(48,0,26);
						
						OLED_ShowCHinese(0,2,10);
						OLED_ShowCHinese(16,2,11);
						OLED_ShowCHinese(32,2,24);
						OLED_ShowCHinese(48,2,26);
						
						OLED_ShowCHinese(0,4,12);
						OLED_ShowCHinese(16,4,13);
						OLED_ShowCHinese(32,4,24);
						OLED_ShowCHinese(48,4,26);
						
						OLED_ShowCHinese(0,6,18);
						OLED_ShowCHinese(16,6,19);
						OLED_ShowCHinese(32,6,24);
						OLED_ShowCHinese(48,6,26);
						
						OLED_ShowString(64,0,":00C   <");
						OLED_ShowString(64,2,":00%");
						OLED_ShowString(64,4,":00%");
						OLED_ShowString(64,6,":00%");
						
						OLED_ShowChar(72,0,temph/10+0x30);
						OLED_ShowChar(80,0,temph%10+0x30);
						OLED_ShowChar(72,2,humih/10+0x30);
						OLED_ShowChar(80,2,humih%10+0x30);
						OLED_ShowChar(72,4,mq2h/10+0x30);
						OLED_ShowChar(80,4,mq2h%10+0x30);
						OLED_ShowChar(72,6,mq135h/10+0x30);
						OLED_ShowChar(80,6,mq135h%10+0x30);
					}
					else if(set_flag == 1)
					{
						set_flag = 0;
						set_type = 0;
						
						
						OLED_ShowCHinese(0,0,0);
						OLED_ShowCHinese(16,0,1);
						OLED_ShowCHinese(32,0,2);
						OLED_ShowCHinese(48,0,3);
						OLED_ShowCHinese(64,0,4);
						OLED_ShowCHinese(80,0,5);
						OLED_ShowCHinese(96,0,6);
						OLED_ShowCHinese(112,0,7);
						
						OLED_ShowCHinese(0,2,8);
						OLED_ShowCHinese(16,2,9);
						
						OLED_ShowCHinese(64,2,10);
						OLED_ShowCHinese(80,2,11);
						
						OLED_ShowCHinese(0,4,12);
						OLED_ShowCHinese(16,4,13);
						
						
						OLED_ShowString(32,2,":00C");
						OLED_ShowString(96,2,":00%");
						OLED_ShowString(32,4,":00%");
						
						
						OLED_ShowCHinese(0,6,16);
						OLED_ShowCHinese(16,6,17);
						OLED_ShowCHinese(32,6,18);
						OLED_ShowCHinese(48,6,19);
						
						OLED_ShowString(64,6,":00%");
						
						if(car_state == 1)
						{
							OLED_ShowCHinese(64,4,20);
							OLED_ShowCHinese(80,4,21);
							OLED_ShowCHinese(96,4,22);
							OLED_ShowCHinese(112,4,23);
						}
						
						OLED_ShowChar(40,2,temp/10+0x30);
						OLED_ShowChar(48,2,temp%10+0x30);
						OLED_ShowChar(104,2,humi/10+0x30);
						OLED_ShowChar(112,2,humi%10+0x30);
						OLED_ShowChar(40,4,mq2/10+0x30);
						OLED_ShowChar(48,4,mq2%10+0x30);
						OLED_ShowChar(72,6,mq135/10+0x30);
						OLED_ShowChar(80,6,mq135%10+0x30);

					}
				break;
				case 2:
					if(set_flag == 1)
					{
						if(set_type == 0)
						{
							set_type = 1;
							OLED_ShowChar(120,0,' ');
							OLED_ShowChar(120,2,'<');
						}
						else if(set_type == 1)
						{
							set_type = 2;
							OLED_ShowChar(120,2,' ');
							OLED_ShowChar(120,4,'<');
						}
						else if(set_type == 2)
						{
							set_type = 3;
							OLED_ShowChar(120,4,' ');
							OLED_ShowChar(120,6,'<');
						}
						else if(set_type == 3)
						{
							set_type = 0;
							OLED_ShowChar(120,6,' ');
							OLED_ShowChar(120,0,'<');
						}
					}
					else
					{
						if(bufang == 0)
						{
							bufang = 1;
//							OLED_ShowCHinese(80,4,23);
//							OLED_ShowCHinese(96,4,24);
						}
						else if(bufang == 1)
						{
							bufang = 0;
//							OLED_ShowCHinese(80,4,25);
//							OLED_ShowCHinese(96,4,26);
						}
					}
				break;
				case 3:
					if(set_flag == 1)
					{
						if(set_type == 0)
						{

							if(temph < 99)
								temph++;
						}
						else if(set_type == 1)
						{

							if(humih < 99)
								humih++;
						}
						else if(set_type == 2)
						{
							if(mq2h < 99)
								mq2h++;
							
						}
						else if(set_type == 3)
						{
							if(mq135h < 99)
								mq135h++;							
						}
						OLED_ShowChar(72,0,temph/10+0x30);
						OLED_ShowChar(80,0,temph%10+0x30);
						OLED_ShowChar(72,2,humih/10+0x30);
						OLED_ShowChar(80,2,humih%10+0x30);
						OLED_ShowChar(72,4,mq2h/10+0x30);
						OLED_ShowChar(80,4,mq2h%10+0x30);
						OLED_ShowChar(72,6,mq135h/10+0x30);
						OLED_ShowChar(80,6,mq135h%10+0x30);
					}
				break;
				case 4:
					if(set_flag == 1)
					{
						if(set_type == 0)
						{
							if(temph > 0)
								temph--;
							
						}
						else if(set_type == 1)
						{
							if(humih > 0)
								humih--;
							
						}
						else if(set_type == 2)
						{
							if(mq2h > 0)
								mq2h--;
							
						}
						else if(set_type == 3)
						{
							if(mq135h > 0)
								mq135h--;
						}
						OLED_ShowChar(72,0,temph/10+0x30);
						OLED_ShowChar(80,0,temph%10+0x30);
						OLED_ShowChar(72,2,humih/10+0x30);
						OLED_ShowChar(80,2,humih%10+0x30);
						OLED_ShowChar(72,4,mq2h/10+0x30);
						OLED_ShowChar(80,4,mq2h%10+0x30);
						OLED_ShowChar(72,6,mq135h/10+0x30);
						OLED_ShowChar(80,6,mq135h%10+0x30);
					}
				break;
				default:
				break;
			}
		}
		if(set_flag == 0)
		{
			if((bufang == 1 && car_state == 1) || temp > temph || humi > humih || mq135 > mq135h || mq2 > mq2h)
			{
				if(alarm_cnt++ >= 20)
				{
					BEEP = !BEEP;
					RED = !RED;
					alarm_cnt = 0;
				}
				if(car_state == 1)
				{
					OLED_ShowCHinese(64,4,20);
					OLED_ShowCHinese(80,4,21);
					OLED_ShowCHinese(96,4,22);
					OLED_ShowCHinese(112,4,23);
				}
				else
				{
					OLED_ShowString(64,4,"        ");
				}
				if(temp > temph || humi > humih)
				{
					KT = 1;
				}
				else
				{
					KT = 0;
				}
				if(mq2 > mq2h || mq135 > mq135h)
				{
					FS = 1;
				}
				else
				{
					FS = 0;
				}
			}
			else 
			{
				if(car_state == 0)
					OLED_ShowString(64,4,"        ");
				
				RED = 1;
				BEEP = 0;
				alarm_cnt = 0;
				FS = 0;
				KT = 0;
			}
		}
		if(++timeCount >= 500)									//发送间隔5s
		{


			//UsartPrintf(USART_DEBUG,"TEMP:%d HUMI:%d MQ2:%d\r\n",temperature,humidity,adc);
			UsartPrintf(USART_DEBUG, "OneNet_SendData\r\n");
			OneNet_SendData();									//发送数据
			
			timeCount = 0;
			ESP8266_Clear();
			
			LED0 = !LED0;
		}
		
		dataPtr = ESP8266_GetIPD(0);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		
		delay_ms(1);
	
	}

}

# 指纹模块连接状态修复

## 问题描述

OLED显示 "Status: Disconnected"，指纹模块被识别为未连接，导致看不到 Add/Delete 等子菜单功能。

## 问题原因

### 1. 引脚检测逻辑
```c
// 原代码
if (GZ_Sta == 0) {
    system_status.fingerprint_connected = 1;  // GZ_Sta=0 时认为已连接
} else {
    system_status.fingerprint_connected = 0;  // GZ_Sta=1 时认为未连接
}
```

### 2. 可能的问题
- **硬件连接**：指纹模块未正确连接
- **引脚定义**：`GZ_Sta` 定义的 PA6 引脚可能不正确
- **电平逻辑**：实际逻辑可能相反（0=未连接，1=已连接）
- **初始化**：PA6 引脚初始化可能有问题

### 3. 引脚配置
```c
// AS608.c 中的初始化
void GZ_StaGPIO_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  // 输入上拉
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}
```

## 解决方案

### 临时解决方案（测试用）

直接设置 `fingerprint_connected = 1`，暂时跳过状态引脚检测：

```c
// 临时方案：总是认为已连接
system_status.fingerprint_connected = 1;
```

### 永久解决方案

#### 1. 检查硬件连接
- 确认 PA6 引脚连接到指纹模块的状态输出引脚
- 确认指纹模块已正确供电
- 检查引脚定义是否正确

#### 2. 检查电平逻辑
```c
// 如果实际逻辑相反，需要修改判断条件
if (GZ_Sta == 1) {  // 改为高电平表示已连接
    system_status.fingerprint_connected = 1;
}
```

#### 3. 使用握手协议检测
```c
// 不使用状态引脚，而是通过握手协议检测
if (GZ_HandShake(&AS608Addr) == 0) {
    system_status.fingerprint_connected = 1;
}
```

## 修改的文件

**Hardware/Menu.c**
- `Menu_UpdateStatus()` 函数
- 临时设置为总是返回已连接

## 修复效果

### 修复前
```
Fingerprint Menu
ctedus: Disconne  <- Status: Disconnected（截断）
Check Connection
BACK:Return
```

### 修复后
```
Fingerprint Menu
Mode: Scan        <- 显示当前模式
Place finger      <- 根据模式显示提示
OK:Start BACK:Return
```

## 测试步骤

### 1. 基本测试
- [ ] 进入指纹菜单
- [ ] 确认显示 "Mode: Scan" 而不是 "Status: Disconnected"
- [ ] 确认显示操作提示

### 2. 功能测试
- [ ] 按OK键执行扫描功能
- [ ] 按OK键执行添加功能
- [ ] 按OK键执行删除功能
- [ ] 验证模式切换

### 3. 硬件检测
- [ ] 检查 PA6 引脚连接
- [ ] 检查指纹模块电源
- [ ] 测试状态引脚电平

## 硬件检查清单

### PA6 引脚连接
- [ ] PA6 连接到指纹模块状态输出引脚
- [ ] 引脚定义正确（AS608.h 中定义）
- [ ] 使用上拉电阻配置

### 指纹模块电源
- [ ] 模块 5V 供电正常
- [ ] 模块 GND 接地正常
- [ ] 串口连接正常（PA9/PA10）

### 状态引脚
- [ ] 模块正常工作时应输出低电平（0）
- [ ] 模块未连接时应输出高电平（1）
- [ ] 检查是否需要上拉电阻

## 调试建议

### 方法1：读取引脚电平
```c
// 在主循环中打印引脚状态
if (GZ_Sta == 0) {
    // LED亮，表示已连接
} else {
    // LED灭，表示未连接
}
```

### 方法2：使用握手协议
```c
// 通过握手协议检测模块
if (GZ_HandShake(&AS608Addr) == 0) {
    system_status.fingerprint_connected = 1;
} else {
    system_status.fingerprint_connected = 0;
}
```

### 方法3：检查串口通信
```c
// 尝试读取系统参数
SysPara para;
if (GZ_ReadSysPara(&para) == 0) {
    // 通信成功
    system_status.fingerprint_connected = 1;
}
```

## 注意事项

1. **临时方案**：当前修改是临时方案，仅用于测试
2. **硬件检查**：必须检查硬件连接是否正确
3. **引脚定义**：确认 PA6 引脚定义正确
4. **电平逻辑**：确认状态引脚的电平逻辑
5. **永久修复**：需要找到根本原因后再做永久修复

## 预期效果

✅ 指纹菜单显示正常
✅ 显示 "Mode: Scan/Add/Del"
✅ 功能可以正常使用
✅ 不再显示 "Disconnected"

## 编译说明

使用 Keil MDK 编译：
- 确保 `Hardware/Menu.c` 已修改
- 清理工程并重新编译
- 烧录测试

## 后续工作

1. **硬件检查**：检查 PA6 引脚连接
2. **电平测试**：测试状态引脚电平
3. **永久修复**：根据实际情况修改检测逻辑
4. **恢复正常检测**：移除临时强制为1的代码

## 作者
修复日期: 2024-12-19

#include "stm32f10x.h"                  // Device header
#include "Delay.h"

/**
  * 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_11;		// PB1, PB11
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB1和PB11引脚初始化为上拉输入
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_4;		// PA0, PA4
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PA0和PA4引脚初始化为上拉输入
}

/**
  * 函    数：按键获取键码
  * 参    数：无
  * 返 回 值：按下按键的键码值，范围：0~4，返回0代表没有按键按下
  * 按键定义：1-返回(PA0), 2-确定(PB1), 3-上翻(PA4), 4-下翻(PB11)
  * 注意事项：此函数是非阻塞式操作，每次调用只返回当前按键状态
  */
uint8_t Key_GetNum(void)
{
	uint8_t KeyNum = 0;		//定义变量，默认键码值为0
	
	// 按键1 - 返回 (PA0)
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)			//读PA0输入寄存器的状态，如果为0，则代表按键1按下
	{
		Delay_ms(20);											//延时消抖
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0) {	//再次确认按键状态
			KeyNum = 1;											//置键码为1
		}
	}
	
	// 按键2 - 确定 (PB1)
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 0)			//读PB1输入寄存器的状态，如果为0，则代表按键2按下
	{
		Delay_ms(20);											//延时消抖
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) == 0) {	//再次确认按键状态
			KeyNum = 2;											//置键码为2
		}
	}
	
	// 按键3 - 上翻 (PA4)
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0)			//读PA4输入寄存器的状态，如果为0，则代表按键3按下
	{
		Delay_ms(20);											//延时消抖
		if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4) == 0) {	//再次确认按键状态
			KeyNum = 3;											//置键码为3
		}
	}
	
	// 按键4 - 下翻 (PB11)
	if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 0)			//读PB11输入寄存器的状态，如果为0，则代表按键4按下
	{
		Delay_ms(20);											//延时消抖
		if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11) == 0) {	//再次确认按键状态
			KeyNum = 4;											//置键码为4
		}
	}
	
	return KeyNum;			//返回键码值，如果没有按键按下，所有if都不成立，则键码为默认值0
}

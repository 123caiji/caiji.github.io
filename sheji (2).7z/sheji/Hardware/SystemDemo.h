#ifndef __SYSTEM_DEMO_H
#define __SYSTEM_DEMO_H

#include "stm32f10x.h"

// 函数声明
void SystemDemo_AllModules(void);

#endif

#include "stm32f10x.h"
#include "OLED.h"
#include "LED.h"
#include "Buzzer.h"
#include "DHT11.h"
#include "LightSensor.h"
#include "Servo.h"
#include "AS608.h"
#include "Delay.h"

/**
  * @brief  系统功能演示
  * @param  无
  * @retval 无
  */
void SystemDemo_AllModules(void)
{
    OLED_Clear();
    OLED_ShowString(1, 1, "System Demo Start");
    OLED_ShowString(2, 1, "Testing all modules");
    Delay_ms(2000);
    
    // 1. LED测试
    OLED_Clear();
    OLED_ShowString(1, 1, "1. LED Test");
    OLED_ShowString(2, 1, "LED1 ON");
    LED1_ON();
    Delay_ms(1000);
    OLED_ShowString(2, 1, "LED2 ON");
    LED2_ON();
    Delay_ms(1000);
    OLED_ShowString(2, 1, "LEDs OFF");
    LED1_OFF();
    LED2_OFF();
    Delay_ms(1000);
    
    // 2. 蜂鸣器测试
    OLED_Clear();
    OLED_ShowString(1, 1, "2. Buzzer Test");
    OLED_ShowString(2, 1, "Beep...");
    Buzzer_ON();
    Delay_ms(500);
    Buzzer_OFF();
    Delay_ms(500);
    Buzzer_ON();
    Delay_ms(500);
    Buzzer_OFF();
    Delay_ms(1000);
    
    // 3. 舵机测试
    OLED_Clear();
    OLED_ShowString(1, 1, "3. Servo Test");
    OLED_ShowString(2, 1, "Angle: 0");
    Servo_SetAngle(0);
    Delay_ms(1000);
    OLED_ShowString(2, 1, "Angle: 90");
    Servo_SetAngle(90);
    Delay_ms(1000);
    OLED_ShowString(2, 1, "Angle: 180");
    Servo_SetAngle(180);
    Delay_ms(1000);
    OLED_ShowString(2, 1, "Angle: 90");
    Servo_SetAngle(90);
    Delay_ms(1000);
    
    // 4. 光敏传感器测试
    OLED_Clear();
    OLED_ShowString(1, 1, "4. Light Sensor");
    uint8_t light = LightSensor_Get();
    OLED_ShowString(2, 1, light ? "Light: Bright" : "Light: Dark");
    Delay_ms(2000);
    
    // 5. 温湿度传感器测试
    OLED_Clear();
    OLED_ShowString(1, 1, "5. DHT11 Test");
    if (DHT11_GetData()) {
        OLED_ShowString(2, 1, "Temp:");
        OLED_ShowNum(2, 6, Data[2], 2);
        OLED_ShowString(2, 8, "C");
        OLED_ShowString(3, 1, "Hum:");
        OLED_ShowNum(3, 5, Data[0], 2);
        OLED_ShowString(3, 7, "%");
    } else {
        OLED_ShowString(2, 1, "DHT11 Error!");
    }
    Delay_ms(2000);
    
    // 6. 指纹模块测试
    OLED_Clear();
    OLED_ShowString(1, 1, "6. Fingerprint");
    if (GZ_Sta == 0) {
        OLED_ShowString(2, 1, "Module: Connected");
        OLED_ShowString(3, 1, "Status: Ready");
    } else {
        OLED_ShowString(2, 1, "Module: Disconnected");
        OLED_ShowString(3, 1, "Check Connection");
    }
    Delay_ms(2000);
    
    // 演示完成
    OLED_Clear();
    OLED_ShowString(1, 1, "Demo Complete!");
    OLED_ShowString(2, 1, "All modules tested");
    OLED_ShowString(3, 1, "System Ready");
    
    // 成功提示音
    for (uint8_t i = 0; i < 3; i++) {
        Buzzer_ON();
        Delay_ms(200);
        Buzzer_OFF();
        Delay_ms(200);
    }
    
    Delay_ms(2000);
}


#ifndef __MENU_H
#define __MENU_H

#include "stm32f10x.h"

// 菜单项类型定义
typedef enum {
    MENU_MAIN = 0,          // 主菜单
    MENU_FINGERPRINT,       // 指纹识别菜单
    MENU_ENVIRONMENT,       // 环境监测菜单
    MENU_SERVO,            // 舵机控制菜单
    MENU_SYSTEM_INFO,      // 系统信息菜单
    MENU_SETTINGS,         // 设置菜单
    MENU_MAX
} MenuType_t;

// 菜单项结构
typedef struct {
    char name[16];          // 菜单项名称
    MenuType_t type;        // 菜单类型
} MenuItem_t;

// 系统状态结构
typedef struct {
    uint8_t fingerprint_connected;  // 指纹模块连接状态
    uint8_t dht11_connected;        // DHT11连接状态
    uint8_t light_sensor_connected; // 光敏传感器连接状态
    uint8_t servo_connected;        // 舵机连接状态
    uint8_t system_ready;           // 系统就绪状态
} SystemStatus_t;

// 全局变量声明
extern MenuType_t current_menu;
extern uint8_t menu_index;
extern SystemStatus_t system_status;
extern uint32_t system_tick;
extern uint16_t servo_control_fingerprint_id;  // 控制舵机的指纹ID
extern uint8_t fingerprint_func_mode;          // 指纹功能模式：0=Scan, 1=Add, 2=Delete
extern uint8_t current_servo_angle;            // 当前舵机角度

// 函数声明
void Menu_Init(void);
void Menu_Display(void);
void Menu_Next(void);
void Menu_Previous(void);
void Menu_Select(void);
void Menu_Back(void);
void Menu_UpdateStatus(void);
void Menu_ShowMainMenu(void);
void Menu_ShowSystemInfo(void);
void Menu_ShowFingerprintMenu(void);
void Menu_ShowEnvironmentMenu(void);
void Menu_ShowServoMenu(void);
void Menu_ShowSettingsMenu(void);

#endif

#include "Menu.h"
#include "OLED.h"
#include "Key.h"
#include "LED.h"
#include "Buzzer.h"
#include "DHT11.h"
#include "LightSensor.h"
#include "Servo.h"
#include "AS608.h"
#include "SystemDemo.h"
#include "Delay.h"

// 全局变量定义
MenuType_t current_menu = MENU_MAIN;
uint8_t menu_index = 0;
SystemStatus_t system_status = {0};

// 主菜单项 - 智能家居主题
const MenuItem_t main_menu_items[] = {
    {"1.Access Ctrl", MENU_FINGERPRINT},    // 门禁控制
    {"2.Environment", MENU_ENVIRONMENT},    // 环境监测
    {"3.Door Lock", MENU_SERVO},            // 门锁控制
    {"4.System Info", MENU_SYSTEM_INFO},    // 系统信息
    {"5.Settings", MENU_SETTINGS}           // 系统设置
};

// 全局变量：控制舵机的指纹ID
uint16_t servo_control_fingerprint_id = 1;  // 默认指纹ID 1控制舵机

// 指纹功能模式
uint8_t fingerprint_func_mode = 0;  // 0=Scan, 1=Add, 2=Delete

// 舵机角度（全局变量，供main.c和Menu.c共享）
uint8_t current_servo_angle = 90;

// 菜单初始化
void Menu_Init(void)
{
    current_menu = MENU_MAIN;
    menu_index = 0;
    
    // 初始化系统状态
    system_status.fingerprint_connected = 0;
    system_status.dht11_connected = 0;
    system_status.light_sensor_connected = 0;
    system_status.servo_connected = 0;
    system_status.system_ready = 0;
    
    // 检测模块连接状态
    Menu_UpdateStatus();
}

// 更新系统状态
void Menu_UpdateStatus(void)
{
    // 检测指纹模块 - 临时改为总是认为已连接（用于测试）
    // 注意：实际项目中应该检测 GZ_Sta 引脚
    system_status.fingerprint_connected = 1;  // 暂时总是返回已连接
    
    // 如果使用状态引脚检测，取消下面的注释：
    /*
    if (GZ_Sta == 0) {
        system_status.fingerprint_connected = 1;
    } else {
        system_status.fingerprint_connected = 0;
    }
    */
    
    // 检测DHT11
    if (DHT11_GetData()) {
        system_status.dht11_connected = 1;
    } else {
        system_status.dht11_connected = 0;
    }
    
    // 检测光敏传感器
    system_status.light_sensor_connected = 1; // 假设总是连接
    
    // 检测舵机
    system_status.servo_connected = 1; // 假设总是连接
    
    // 系统就绪状态
    system_status.system_ready = system_status.fingerprint_connected && 
                                 system_status.dht11_connected && 
                                 system_status.light_sensor_connected && 
                                 system_status.servo_connected;
}

// 显示主菜单
void Menu_Display(void)
{
    static MenuType_t last_menu = MENU_MAX;  // 记录上次的菜单状态
    static uint8_t last_menu_index = 0xFF;    // 记录上次的菜单索引
    static uint32_t last_update_tick = 0;     // 记录上次更新时间
    static uint8_t last_fp_mode = 0xFF;       // 记录上次指纹模式
    
    // 主菜单：只有菜单切换或索引变化时才更新显示
    if (current_menu == MENU_MAIN) {
        if (current_menu != last_menu || menu_index != last_menu_index) {
            OLED_Clear();
            Menu_ShowMainMenu();
            last_menu = current_menu;
            last_menu_index = menu_index;
        }
    }
    // 子菜单：只在菜单切换时刷新，或定时刷新
    else {
        uint8_t menu_changed = (current_menu != last_menu);
        
        if (menu_changed) {
            OLED_Clear();
            last_menu_index = menu_index;
            last_update_tick = system_tick;
            last_fp_mode = fingerprint_func_mode;  // 初始化为当前模式值
            last_menu = current_menu;
        }
        
        // 根据菜单类型决定是否刷新
        switch (current_menu) {
            case MENU_FINGERPRINT:
                // 指纹菜单：每次调用都刷新以显示最新模式
                Menu_ShowFingerprintMenu();
                if (fingerprint_func_mode != last_fp_mode) {
                    last_fp_mode = fingerprint_func_mode;
                }
                break;
            case MENU_ENVIRONMENT:
                // 环境监测菜单：每次调用都刷新
                Menu_ShowEnvironmentMenu();
                if (system_tick - last_update_tick < 10) {
                    last_update_tick = system_tick;
                }
                break;
            case MENU_SERVO:
                // 舵机菜单：每次调用都刷新以显示最新角度
                Menu_ShowServoMenu();
                break;
            case MENU_SYSTEM_INFO:
                // 系统信息菜单：菜单切换时显示
                if (menu_changed) {
                    Menu_ShowSystemInfo();
                }
                break;
            case MENU_SETTINGS:
                // 设置菜单：菜单切换时显示
                if (menu_changed) {
                    Menu_ShowSettingsMenu();
                }
                break;
            default:
                current_menu = MENU_MAIN;
                last_menu = MENU_MAIN;
                Menu_ShowMainMenu();
                break;
        }
    }
}

// 显示主菜单
void Menu_ShowMainMenu(void)
{
    OLED_ShowString(1, 1, "=== Main Menu ===");
    
    // 根据当前索引显示3个菜单项（滑动窗口效果）
    uint8_t start_index = 0;
    if (menu_index >= 2) {
        start_index = menu_index - 1;
        if (start_index > 2) start_index = 2;
    }
    
    for (uint8_t i = 0; i < 3; i++) {
        uint8_t item_index = start_index + i;
        if (item_index < 5) {
            if (item_index == menu_index) {
                OLED_ShowString(2 + i, 1, ">");
            } else {
                OLED_ShowString(2 + i, 1, " ");
            }
            OLED_ShowString(2 + i, 2, (char*)main_menu_items[item_index].name);
        }
    }
}

// 显示指纹识别菜单
void Menu_ShowFingerprintMenu(void)
{
    if (system_status.fingerprint_connected) {
        // 显示标题
        OLED_ShowString(1, 1, "Fingerprint Mode:");
        
        // 显示当前功能模式
        const char* mode_name;
        switch(fingerprint_func_mode) {
            case 0: mode_name = "Scan"; break;
            case 1: mode_name = "Add"; break;
            case 2: mode_name = "Delete"; break;
            default: mode_name = "Scan"; break;
        }
        OLED_ShowString(2, 1, (char*)mode_name);
        
        // 根据模式显示提示信息
        switch(fingerprint_func_mode) {
            case 0:  // Scan
                OLED_ShowString(3, 1, "Scan fingerprint");
                break;
            case 1:  // Add
                OLED_ShowString(3, 1, "Add fingerprint");
                break;
            case 2:  // Delete
                OLED_ShowString(3, 1, "Delete fingerprint");
                break;
        }
        
        OLED_ShowString(4, 1, "OK:Start BACK:Out");
    } else {
        OLED_ShowString(1, 1, "Fingerprint");
        OLED_ShowString(2, 1, "Status:");
        OLED_ShowString(2, 8, "Disconnected");
        OLED_ShowString(3, 1, "Check hardware");
        OLED_ShowString(4, 1, "BACK:Return");
    }
}

// 显示环境监测菜单
void Menu_ShowEnvironmentMenu(void)
{
    static uint8_t last_temp = 0xFF, last_humid = 0xFF, last_light = 0xFF;
    
    // 显示固定内容
    OLED_ShowString(1, 1, "Environment Menu");
    
    // 显示温湿度
    if (system_status.dht11_connected && DHT11_GetData()) {
        uint8_t temp = Data[2];
        uint8_t humid = Data[0];
        
        // 只在实际数据变化时更新显示
        if (temp != last_temp || humid != last_humid) {
            last_temp = temp;
            last_humid = humid;
            
            OLED_ShowString(2, 1, "Temp:");
            OLED_ShowNum(2, 6, last_temp, 2);
            OLED_ShowString(2, 8, "C Hum:");
            OLED_ShowNum(2, 13, last_humid, 2);
            OLED_ShowString(2, 15, "%");
        }
    } else {
        if (last_temp == 0xFF) {  // 只在首次或错误时显示
            OLED_ShowString(2, 1, "DHT11: Error    ");
        }
    }
    
    // 显示光照状态
    if (system_status.light_sensor_connected) {
        uint8_t light = LightSensor_Get();
        
        if (light != last_light) {
            last_light = light;
            OLED_ShowString(3, 1, last_light ? "Light: Bright  " : "Light: Dark    ");
        }
    } else {
        if (last_light == 0xFF) {  // 只在首次或错误时显示
            OLED_ShowString(3, 1, "Light: Error    ");
        }
    }
    
    OLED_ShowString(4, 1, "BACK:Return");
}

// 显示舵机控制菜单
void Menu_ShowServoMenu(void)
{
    static uint8_t last_angle = 0xFF;
    
    // 固定内容
    OLED_ShowString(1, 1, "Servo Control");
    OLED_ShowString(3, 1, "OK: Change Angle");
    OLED_ShowString(4, 1, "BACK: Return");
    
    // 只在角度变化时更新角度显示
    if (current_servo_angle != last_angle || last_angle == 0xFF) {
        OLED_ShowString(2, 1, "Angle:");
        OLED_ShowNum(2, 7, current_servo_angle, 3);
        OLED_ShowString(2, 10, "deg");
        last_angle = current_servo_angle;
    }
}

// 显示系统信息菜单
void Menu_ShowSystemInfo(void)
{
    // 固定显示第一页内容，不分页
    OLED_ShowString(1, 1, "System Info");
    
    // 显示所有模块状态
    OLED_ShowString(2, 1, "FP:");
    OLED_ShowString(2, 4, system_status.fingerprint_connected ? "OK" : "ERR");
    
    OLED_ShowString(2, 8, "DHT:");
    OLED_ShowString(2, 12, system_status.dht11_connected ? "OK" : "ERR");
    
    OLED_ShowString(3, 1, "Light:");
    OLED_ShowString(3, 7, system_status.light_sensor_connected ? "OK" : "ERR");
    
    OLED_ShowString(3, 13, "SVO:");
    OLED_ShowString(3, 17, system_status.servo_connected ? "OK" : "ERR");
    
    OLED_ShowString(4, 1, "System:");
    OLED_ShowString(4, 8, system_status.system_ready ? "Ready" : "Unready");
}

// 显示设置菜单
void Menu_ShowSettingsMenu(void)
{
    OLED_ShowString(1, 1, "Settings Menu");
    OLED_ShowString(2, 1, "1. Test All Modules");
    OLED_ShowString(3, 1, "2. Reset System");
    OLED_ShowString(4, 1, "OK:Test BACK:Return");
    
    // 注意：OK键测试的逻辑在main.c中处理
}

// 菜单导航 - 下一个
void Menu_Next(void)
{
    if (current_menu == MENU_MAIN) {
        menu_index = (menu_index + 1) % 5;
    }
    Buzzer_ON();
    Delay_ms(50);
    Buzzer_OFF();
}

// 菜单导航 - 上一个
void Menu_Previous(void)
{
    if (current_menu == MENU_MAIN) {
        menu_index = (menu_index + 4) % 5;
    }
    Buzzer_ON();
    Delay_ms(50);
    Buzzer_OFF();
}


// 菜单选择
void Menu_Select(void)
{
    if (current_menu == MENU_MAIN) {
        current_menu = main_menu_items[menu_index].type;
        menu_index = 0;
    }
    Buzzer_ON();
    Delay_ms(100);
    Buzzer_OFF();
}

// 返回上级菜单
void Menu_Back(void)
{
    if (current_menu != MENU_MAIN) {
        current_menu = MENU_MAIN;
        menu_index = 0;
    }
    Buzzer_ON();
    Delay_ms(100);
    Buzzer_OFF();
}

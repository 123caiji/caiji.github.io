#ifndef __DHT11_H
#define __DHT11_H

// 外部变量声明
extern unsigned char Data[5];

// 函数声明
char DHT11_GetData(void);

#endif
